const path = require("path");

/** PM2 配置：pm2 start ecosystem.config.cjs */
module.exports = {
  apps: [
    {
      name: "ip-card-ai",
      cwd: __dirname,
      script: path.join(__dirname, "node_modules/next/dist/bin/next"),
      args: "start",
      interpreter: "node",
      env: {
        NODE_ENV: "production",
        PORT: 3002,
      },
      max_restarts: 15,
      min_uptime: "5s",
    },
  ],
};
