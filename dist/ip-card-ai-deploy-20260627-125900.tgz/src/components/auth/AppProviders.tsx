import { AuthProvider } from "@/components/auth/AuthProvider";
import Script from "next/script";

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Script src="/suat_auth_redirect.js?v=1" strategy="beforeInteractive" />
      <AuthProvider>{children}</AuthProvider>
    </>
  );
}
