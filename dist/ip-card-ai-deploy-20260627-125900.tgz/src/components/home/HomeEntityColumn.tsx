import Link from "next/link";
import type { LucideIcon } from "lucide-react";

type EntityItem = {
  id: string;
  name: string;
  slug: string;
  profile?: { slogan?: string | null; summary?: string | null } | null;
};

export function HomeEntityColumn({
  title,
  icon: Icon,
  iconColor,
  hrefPrefix,
  libraryHref,
  entities,
  highlightIds,
  emptyHint,
}: {
  title: string;
  icon: LucideIcon;
  iconColor: string;
  hrefPrefix: string;
  libraryHref?: string;
  entities: EntityItem[];
  highlightIds: Set<string>;
  emptyHint: string;
}) {
  return (
    <div className="flex min-h-[420px] flex-col rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
        <h2 className={`flex items-center gap-2 text-base font-bold text-slate-900`}>
          <Icon className={`h-4 w-4 ${iconColor}`} />
          {title}
        </h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">{entities.length} 推荐</span>
          {libraryHref && (
            <Link href={libraryHref} className="text-xs font-medium text-orange-600 hover:underline">
              查看全部 →
            </Link>
          )}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        {entities.length === 0 ? (
          <p className="px-2 py-8 text-center text-sm text-slate-400">{emptyHint}</p>
        ) : (
          <ul className="space-y-2">
            {entities.map((e) => {
              const isNew = highlightIds.has(e.id);
              return (
                <li key={e.id}>
                  <Link
                    href={`${hrefPrefix}/${e.slug}`}
                    className={`block rounded-xl border px-3 py-2.5 transition hover:shadow-sm ${
                      isNew
                        ? "border-orange-300 bg-orange-50 ring-1 ring-orange-200"
                        : "border-slate-100 bg-slate-50/50 hover:border-slate-200 hover:bg-white"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-slate-900">{e.name}</p>
                      {isNew && (
                        <span className="rounded-full bg-orange-500 px-1.5 py-0.5 text-[10px] font-semibold text-white">
                          新
                        </span>
                      )}
                    </div>
                    <p className="mt-0.5 line-clamp-2 text-xs leading-relaxed text-slate-500">
                      {e.profile?.slogan || e.profile?.summary || "—"}
                    </p>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
