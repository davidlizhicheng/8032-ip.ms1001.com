"use client";

import { useState } from "react";
import {
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  Bookmark,
  Navigation,
  X,
  Building2,
  Sparkles,
} from "lucide-react";
import { VideoPreviewCard } from "@/components/ui/VideoPreviewCard";
import { BrandMediaTools } from "@/components/brand/BrandMediaTools";
import { getTheme } from "@/lib/themes";
import { resolveAssetUrl } from "@/lib/storage/public-url";

type CardData = {
  id: string;
  slug: string;
  name: string;
  title?: string | null;
  company?: string | null;
  avatarUrl?: string | null;
  coverUrl?: string | null;
  brandSlogan?: string | null;
  bio?: string | null;
  phone?: string | null;
  email?: string | null;
  wechat?: string | null;
  address?: string | null;
  theme: string;
  sections: Array<{
    id: string;
    type: string;
    title: string;
    content: string;
  }>;
  mediaAssets: Array<{
    id: string;
    url: string;
    type: string;
    title?: string | null;
  }>;
  videoLinks: Array<{
    id: string;
    platform: string;
    url: string;
    title?: string | null;
    coverUrl?: string | null;
    embedUrl?: string | null;
    canEmbed: boolean;
  }>;
};

const SECTION_ORDER = ["story", "business", "service", "experience", "honor", "case"];

function sortSections(sections: CardData["sections"]) {
  return [...sections].sort((a, b) => {
    const ai = SECTION_ORDER.indexOf(a.type);
    const bi = SECTION_ORDER.indexOf(b.type);
    return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
  });
}

export function PublicCardView({ card }: { card: CardData }) {
  const theme = getTheme(card.theme);
  const [showLeadModal, setShowLeadModal] = useState(false);
  const [leadForm, setLeadForm] = useState({
    visitorName: "",
    visitorPhone: "",
    visitorWechat: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showMediaTools, setShowMediaTools] = useState(false);
  const [extraImages, setExtraImages] = useState(card.mediaAssets);

  const galleryImages = extraImages.filter((m) =>
    ["poster", "case", "honor", "gallery"].includes(m.type),
  );

  const contentSections = sortSections(
    card.sections.filter((s) => !["avatar", "cover"].includes(s.type)),
  );

  async function submitLead(source: string) {
    setSubmitting(true);
    try {
      await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cardId: card.id, ...leadForm, source }),
      });
      setSubmitted(true);
      setTimeout(() => {
        setShowLeadModal(false);
        setSubmitted(false);
      }, 1500);
    } finally {
      setSubmitting(false);
    }
  }

  const contactBar = (
    <div className={`grid grid-cols-2 gap-2 rounded-2xl border bg-white p-3 shadow-sm sm:grid-cols-4 ${theme.border}`}>
      {card.phone && (
        <a
          href={`tel:${card.phone}`}
          className={`flex flex-col items-center gap-1 rounded-xl py-2.5 text-xs ${theme.hoverBg}`}
        >
          <Phone className={`h-5 w-5 ${theme.accent}`} />
          <span>电话</span>
        </a>
      )}
      {card.email && (
        <a
          href={`mailto:${card.email}`}
          className={`flex flex-col items-center gap-1 rounded-xl py-2.5 text-xs ${theme.hoverBg}`}
        >
          <Mail className={`h-5 w-5 ${theme.accent}`} />
          <span>邮件</span>
        </a>
      )}
      {card.address && (
        <a
          href={`https://maps.google.com/?q=${encodeURIComponent(card.address)}`}
          target="_blank"
          rel="noopener noreferrer"
          className={`flex flex-col items-center gap-1 rounded-xl py-2.5 text-xs ${theme.hoverBg}`}
        >
          <Navigation className={`h-5 w-5 ${theme.accent}`} />
          <span>拜访</span>
        </a>
      )}
      {(card.wechat || true) && (
        <button
          type="button"
          onClick={() => setShowLeadModal(true)}
          className={`flex flex-col items-center gap-1 rounded-xl py-2.5 text-xs ${theme.hoverBg}`}
        >
          <MessageCircle className={`h-5 w-5 ${theme.accent}`} />
          <span>{card.wechat ? "微信" : "咨询"}</span>
        </button>
      )}
    </div>
  );

  return (
    <div className={`min-h-screen ${theme.card} ${theme.text}`}>
      <div className="mx-auto max-w-6xl px-4 pb-32 pt-0 sm:px-6 lg:pb-20 lg:pt-6">
        {/* Hero — full width on mobile, sidebar on desktop */}
        <div className="lg:grid lg:grid-cols-[340px_1fr] lg:gap-8 lg:items-start">
          <aside className="lg:sticky lg:top-6">
            <div className={`relative overflow-hidden rounded-b-3xl lg:rounded-2xl ${theme.cover}`}>
              {card.coverUrl && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={resolveAssetUrl(card.coverUrl)}
                  alt="封面"
                  className="absolute inset-0 h-full w-full object-cover opacity-20"
                />
              )}
              <div className="relative z-10 px-5 pb-8 pt-10 lg:p-6">
                <div className="flex items-start gap-4 lg:flex-col lg:items-center lg:text-center">
                  <div className="h-24 w-24 shrink-0 overflow-hidden rounded-2xl border-2 border-white/60 bg-white shadow-lg lg:h-28 lg:w-28">
                    {card.avatarUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={resolveAssetUrl(card.avatarUrl)}
                        alt={card.name}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className={`flex h-full w-full items-center justify-center text-3xl font-bold ${theme.accent}`}>
                        {card.name.slice(0, 1)}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 lg:mt-4">
                    <h1 className="text-2xl font-bold text-slate-900 lg:text-3xl">{card.name}</h1>
                    {card.title && (
                      <p className={`mt-1 text-sm font-medium ${theme.accentText}`}>{card.title}</p>
                    )}
                    {card.company && (
                      <p className="mt-1 flex items-center gap-1 text-sm text-slate-600 lg:justify-center">
                        <Building2 className="h-3.5 w-3.5 shrink-0" />
                        {card.company}
                      </p>
                    )}
                  </div>
                </div>

                {card.brandSlogan && (
                  <p className={`mt-5 text-sm leading-relaxed lg:text-center ${theme.accentText}`}>
                    「{card.brandSlogan}」
                  </p>
                )}

                <div className="mt-4 space-y-1.5 text-sm text-slate-600 lg:text-center">
                  {card.phone && <p className="flex items-center gap-2 lg:justify-center"><Phone className="h-3.5 w-3.5" />{card.phone}</p>}
                  {card.email && <p className="flex items-center gap-2 lg:justify-center"><Mail className="h-3.5 w-3.5" />{card.email}</p>}
                  {card.address && <p className="flex items-center gap-2 lg:justify-center"><MapPin className="h-3.5 w-3.5" />{card.address}</p>}
                </div>
              </div>
            </div>

            <div className="mt-4 hidden lg:block">{contactBar}</div>
          </aside>

          <main className="mt-4 space-y-5 lg:mt-0">
            <div className="lg:hidden">{contactBar}</div>

            {card.bio && (
              <section className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}>
                <h2 className={`mb-3 flex items-center gap-2 text-lg font-bold ${theme.accent}`}>
                  <Sparkles className="h-5 w-5" />
                  个人简介
                </h2>
                <p className={`text-sm leading-8 ${theme.muted} sm:text-base`}>{card.bio}</p>
              </section>
            )}

            {contentSections
              .filter((section) => {
                if (section.type === "business" && card.bio && section.content === card.bio) {
                  return false;
                }
                return true;
              })
              .map((section) => (
              <section
                key={section.id}
                className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}
              >
                <h2 className={`mb-3 text-lg font-bold ${theme.accent}`}>{section.title}</h2>
                <div className={`whitespace-pre-line text-sm leading-8 ${theme.muted} sm:text-base`}>
                  {section.content}
                </div>
              </section>
            ))}

            {galleryImages.length > 0 && (
              <section className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}>
                <h2 className={`mb-4 text-lg font-bold ${theme.accent}`}>图片展示</h2>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                  {galleryImages.map((img) => (
                    <div key={img.id} className="overflow-hidden rounded-xl">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={resolveAssetUrl(img.url)}
                        alt={img.title || "展示图"}
                        className="aspect-[4/3] w-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </section>
            )}

            {card.videoLinks.length > 0 && (
              <section className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}>
                <h2 className={`mb-4 text-lg font-bold ${theme.accent}`}>视频介绍</h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  {card.videoLinks.map((video) => (
                    <VideoPreviewCard
                      key={video.id}
                      platform={video.platform}
                      url={video.url}
                      title={video.title || "视频内容"}
                      coverUrl={video.coverUrl}
                      embedUrl={video.embedUrl}
                      canEmbed={video.canEmbed}
                    />
                  ))}
                </div>
              </section>
            )}
          </main>
        </div>
      </div>

      {/* Bottom bar — mobile */}
      <div className={`fixed bottom-0 left-0 right-0 z-50 border-t bg-white/95 backdrop-blur-lg lg:hidden ${theme.border}`}>
        <div className="mx-auto flex max-w-6xl items-center gap-2 px-4 py-3">
          {card.phone && (
            <a href={`tel:${card.phone}`} className={`flex flex-1 flex-col items-center gap-0.5 py-1 text-xs ${theme.muted}`}>
              <Phone className={`h-5 w-5 ${theme.accent}`} />
              电话
            </a>
          )}
          {card.email && (
            <a href={`mailto:${card.email}`} className={`flex flex-1 flex-col items-center gap-0.5 py-1 text-xs ${theme.muted}`}>
              <Mail className={`h-5 w-5 ${theme.accent}`} />
              邮件
            </a>
          )}
          <button
            type="button"
            onClick={() => setShowMediaTools(true)}
            className={`flex flex-1 flex-col items-center gap-0.5 py-1 text-xs ${theme.muted}`}
          >
            <Sparkles className={`h-5 w-5 ${theme.accent}`} />
            品牌素材
          </button>
          <button
            type="button"
            onClick={() => setShowLeadModal(true)}
            className={`flex flex-[2] items-center justify-center gap-2 rounded-full px-4 py-3 text-sm font-semibold ${theme.button} ${theme.buttonText}`}
          >
            <Bookmark className="h-4 w-4" />
            收下名片
          </button>
        </div>
      </div>

      {/* Desktop floating CTA */}
      <div className="pointer-events-none fixed bottom-8 right-8 z-40 hidden lg:block">
        <button
          type="button"
          onClick={() => setShowLeadModal(true)}
          className={`pointer-events-auto flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold shadow-xl ${theme.button} ${theme.buttonText}`}
        >
          <Bookmark className="h-4 w-4" />
          收下名片
        </button>
      </div>

      {showMediaTools && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/40 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 text-slate-900 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold">品牌 IP 图 / 上传素材</h3>
              <button type="button" onClick={() => setShowMediaTools(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <BrandMediaTools
              slug={card.slug}
              kind="card"
              targetId={card.id}
              themeButtonClass={theme.button}
              onImageAdded={(asset) => setExtraImages((prev) => [...prev, asset])}
            />
          </div>
        </div>
      )}

      {showLeadModal && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/40 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 text-slate-900 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold">收下名片 / 留资咨询</h3>
              <button type="button" onClick={() => setShowLeadModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            {submitted ? (
              <p className="py-8 text-center text-green-600">提交成功，感谢关注！</p>
            ) : (
              <div className="space-y-3">
                <input placeholder="您的姓名" className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" value={leadForm.visitorName} onChange={(e) => setLeadForm({ ...leadForm, visitorName: e.target.value })} />
                <input placeholder="您的手机号" className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" value={leadForm.visitorPhone} onChange={(e) => setLeadForm({ ...leadForm, visitorPhone: e.target.value })} />
                <input placeholder="您的微信号" className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" value={leadForm.visitorWechat} onChange={(e) => setLeadForm({ ...leadForm, visitorWechat: e.target.value })} />
                <textarea placeholder="留言（选填）" rows={3} className="w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm" value={leadForm.message} onChange={(e) => setLeadForm({ ...leadForm, message: e.target.value })} />
                <button type="button" disabled={submitting} onClick={() => submitLead("save_card")} className="w-full rounded-xl bg-orange-500 py-3 text-sm font-semibold text-white disabled:opacity-50">
                  {submitting ? "提交中..." : "确认收下名片"}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
