"use client";

import { useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  Bookmark,
  Building2,
  ChevronRight,
  ExternalLink,
  FileText,
  Globe2,
  Landmark,
  MapPin,
  Newspaper,
  Shield,
  Sparkles,
  TrendingUp,
  Users,
  Image,
  Loader2,
  Upload,
  Video,
} from "lucide-react";
import { getTheme, getDefaultEntityTheme } from "@/lib/themes";
import { resolveAssetUrl } from "@/lib/storage/public-url";
import { ImageUploader } from "@/components/ui/ImageUploader";
import { VideoPreviewCard } from "@/components/ui/VideoPreviewCard";
import {
  getDisclaimer,
  AI_DISCLAIMER,
} from "@/lib/compliance/risk-check";
import {
  ENTITY_TYPE_LABELS,
  PERSON_SUBTYPE_LABELS,
  type EntityProfileContent,
  type EntityReportContent,
  type EntityReportScores,
} from "@/lib/schemas/entity";
import { entityPath, reportPath } from "@/lib/utils/entity-paths";
import { sanitizeSections } from "@/lib/content/sanitize-placeholder";
import { dedupeSources, formatSourceLabel } from "@/lib/search/source-dedupe";
import { filterRealNews, isPlaceholderNewsItem } from "@/lib/news/filter-news";
import { useAuth } from "@/components/auth/AuthProvider";
import { authFetch } from "@/lib/auth/client";

type EntityPageData = {
  id: string;
  type: string;
  name: string;
  slug: string;
  subtype?: string | null;
  status: string;
  isVerified: boolean;
  profile: {
    title?: string | null;
    subtitle?: string | null;
    summary?: string | null;
    slogan?: string | null;
    coverUrl?: string | null;
    avatarUrl?: string | null;
    contentJson: string;
    theme: string;
    seoTitle?: string | null;
  } | null;
  reports: Array<{
    id: string;
    reportType: string;
    title: string;
    summary?: string | null;
    contentJson: string;
    scoreJson?: string | null;
  }>;
  sources: Array<{
    id: string;
    title: string;
    url?: string | null;
    sourceType: string;
    excerpt?: string | null;
    confidenceScore: number;
  }>;
  newsArticles: Array<{
    id: string;
    title: string;
    url: string;
    source?: string | null;
    publishedAt?: string | null;
    excerpt?: string | null;
  }>;
  relationsFrom: Array<{
    relationType: string;
    label?: string | null;
    toEntity: { id: string; type: string; name: string; slug: string; profile?: { slogan?: string | null } | null };
  }>;
  relationsTo: Array<{
    relationType: string;
    label?: string | null;
    fromEntity: { id: string; type: string; name: string; slug: string; profile?: { slogan?: string | null } | null };
  }>;
  mediaAssets?: Array<{ id: string; url: string; type: string; title?: string | null }>;
  videoLinks?: Array<{
    id: string;
    platform: string;
    url: string;
    title?: string | null;
    coverUrl?: string | null;
    embedUrl?: string | null;
    canEmbed: boolean;
  }>;
};

const SECTION_ICONS: Record<string, typeof Building2> = {
  positioning: MapPin,
  industry: TrendingUp,
  companies: Building2,
  education: Landmark,
  tourism: Globe2,
  business: Sparkles,
  slogan: Sparkles,
  investment: TrendingUp,
  intro: Building2,
  products: Sparkles,
  leadership: Users,
  model: TrendingUp,
  growth: TrendingUp,
  advantage: Sparkles,
  competitors: TrendingUp,
  bio: Users,
  identity: Users,
  company: Building2,
  brand: Sparkles,
  experience: TrendingUp,
  influence: Globe2,
  cooperation: Users,
  story: Sparkles,
  overview: Users,
  skills: Sparkles,
  scenarios: Globe2,
};

function parseProfile(json: string): EntityProfileContent {
  try {
    const parsed = JSON.parse(json) as EntityProfileContent;
    return {
      ...parsed,
      sections: sanitizeSections(parsed.sections || []),
    };
  } catch {
    return { sections: [], tags: [], keywords: [] };
  }
}

function ScoreRing({ score, accentClass }: { score: number; accentClass: string }) {
  const pct = Math.min(100, Math.max(0, score * 10));
  const r = 42;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;

  return (
    <div className="relative flex h-28 w-28 items-center justify-center">
      <svg className="-rotate-90" width="112" height="112" viewBox="0 0 112 112">
        <circle cx="56" cy="56" r={r} fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-200" />
        <circle
          cx="56"
          cy="56"
          r={r}
          fill="none"
          stroke="url(#scoreGradient)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
        <defs>
          <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#fbbf24" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute text-center">
        <p className={`text-3xl font-bold ${accentClass}`}>{score}</p>
        <p className="text-[10px] uppercase tracking-wider text-slate-400">综合分</p>
      </div>
    </div>
  );
}

function ScoreGrid({ scores, accentClass }: { scores: EntityReportScores; accentClass: string }) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
      {Object.entries(scores).map(([label, value]) => (
        <div
          key={label}
          className="rounded-xl border border-slate-100 bg-white/80 px-3 py-2.5"
        >
          <p className="text-[11px] leading-tight text-slate-500">{label}</p>
          <p className={`mt-1 text-lg font-bold ${accentClass}`}>{value}</p>
        </div>
      ))}
    </div>
  );
}

export function EntityPageView({ entity }: { entity: EntityPageData }) {
  const { user, brandUpgrade, login, openBilling } = useAuth();
  const theme = getTheme(getDefaultEntityTheme(entity.type, entity.slug, entity.name));
  const content = parseProfile(entity.profile?.contentJson || "{}");
  const displayNews = entity.newsArticles.filter(
    (a) => a.title?.trim() && a.url?.trim() && !isPlaceholderNewsItem(a),
  );
  const displaySources = dedupeSources(entity.sources);
  const displaySections = content.sections.filter((section, index, arr) => {
    const key = section.content.trim().slice(0, 120);
    if (!key || key.length < 40) return false;
    return arr.findIndex((s) => s.content.trim().slice(0, 120) === key) === index;
  });
  const disclaimer = getDisclaimer(
    entity.type as "city",
    entity.subtype,
    entity.isVerified,
  );
  const typeLabel = ENTITY_TYPE_LABELS[entity.type as keyof typeof ENTITY_TYPE_LABELS] || entity.type;
  const subtypeLabel = entity.subtype ? PERSON_SUBTYPE_LABELS[entity.subtype] : null;
  const isCity = entity.type === "city";

  const latestReport = entity.reports[0];
  let reportScores: EntityReportScores = {};
  let overallScore = 0;

  if (latestReport?.scoreJson) {
    try {
      const parsed = JSON.parse(latestReport.scoreJson);
      reportScores = parsed.scores || {};
      overallScore = parsed.overall || 0;
    } catch { /* ignore */ }
  }

  const related = [
    ...entity.relationsFrom.map((r) => ({ ...r.toEntity, rel: r.label || r.relationType })),
    ...entity.relationsTo.map((r) => ({ ...r.fromEntity, rel: r.label || r.relationType })),
  ];

  const [showClaim, setShowClaim] = useState(false);
  const [claimForm, setClaimForm] = useState({ proofText: "", contactName: "", contactPhone: "" });
  const [claimMsg, setClaimMsg] = useState("");
  const [mediaImages, setMediaImages] = useState(entity.mediaAssets || []);
  const [mediaVideos, setMediaVideos] = useState(entity.videoLinks || []);
  const [videoUrl, setVideoUrl] = useState("");
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [generatingIpImage, setGeneratingIpImage] = useState(false);
  const [uploadMsg, setUploadMsg] = useState("");

  async function handleUploadError(data: { error?: string; code?: string }) {
    if (data.code === "LOGIN_REQUIRED") {
      setUploadMsg("请先登录后再上传更多图片");
      login("login");
      return;
    }
    if (data.code === "UPGRADE_REQUIRED") {
      setUploadMsg("多图上传需开通品牌升级（500元）");
      try {
        await openBilling({ entityId: entity.id });
      } catch {
        /* ignore redirect errors */
      }
      return;
    }
    setUploadMsg(data.error || "操作失败");
  }

  async function attachImageUrl(url: string) {
    if (!url) return;
    setUploadMsg("保存中…");
    const res = await authFetch(`/api/entities/${entity.slug}/media`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageUrl: url, type: "gallery" }),
    });
    const data = await res.json();
    if (data.asset) {
      setMediaImages((prev) => [...prev, data.asset]);
      setUploadMsg("图片已上传");
    } else {
      await handleUploadError(data);
    }
  }

  async function generateIpImage() {
    if (!user) {
      login("login");
      return;
    }
    if (!brandUpgrade) {
      setUploadMsg("AI 生成 IP 图需开通品牌升级（500元）");
      try {
        await openBilling({ entityId: entity.id });
      } catch {
        /* ignore */
      }
      return;
    }
    setGeneratingIpImage(true);
    setUploadMsg("AI 正在生成品牌 IP 图…");
    try {
      const res = await authFetch(`/api/entities/${entity.slug}/generate-ip-image`, {
        method: "POST",
        body: JSON.stringify({ target: "cover" }),
      });
      const data = await res.json();
      if (data.asset) {
        setMediaImages((prev) => [...prev, data.asset]);
        setUploadMsg("品牌 IP 图已生成");
      } else {
        await handleUploadError(data);
      }
    } catch {
      setUploadMsg("生成失败，请稍后重试");
    } finally {
      setGeneratingIpImage(false);
    }
  }

  async function addVideo() {
    if (!videoUrl.trim()) return;
    setUploadingVideo(true);
    setUploadMsg("");
    const res = await authFetch(`/api/entities/${entity.slug}/media`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ videoUrl: videoUrl.trim() }),
    });
    const data = await res.json();
    setUploadingVideo(false);
    if (data.video) {
      setMediaVideos((prev) => [...prev, data.video]);
      setVideoUrl("");
      setUploadMsg("视频已添加");
    } else {
      await handleUploadError(data);
    }
  }

  async function submitClaim() {
    const res = await fetch("/api/claim", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        entityId: entity.id,
        claimType: entity.type === "city" ? "city" : entity.type === "person" ? "person" : "company",
        ...claimForm,
      }),
    });
    const data = await res.json();
    setClaimMsg(data.success ? "认领申请已提交，我们将尽快审核。" : data.error || "提交失败");
  }

  return (
    <div className={`min-h-screen ${theme.card} ${theme.text}`}>
      {/* Hero */}
      <header className={`relative overflow-hidden ${theme.cover}`}>
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute -bottom-16 right-0 h-72 w-72 rounded-full bg-cyan-300/20 blur-3xl" />
          {isCity && (
            <div
              className="absolute inset-0 opacity-[0.07]"
              style={{
                backgroundImage:
                  "linear-gradient(rgba(255,255,255,.8) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.8) 1px, transparent 1px)",
                backgroundSize: "48px 48px",
              }}
            />
          )}
        </div>

        <div className="relative mx-auto max-w-5xl px-5 pb-16 pt-6 sm:px-8 sm:pb-20 sm:pt-10">
          {(entity.profile?.coverUrl || mediaImages.find((m) => m.type === "cover")?.url) && (
            <div className="mb-6 overflow-hidden rounded-2xl border border-white/20 shadow-2xl">
              <img
                src={resolveAssetUrl(entity.profile?.coverUrl || mediaImages.find((m) => m.type === "cover")?.url || "")}
                alt={entity.name}
                className="aspect-[21/9] w-full object-cover"
              />
            </div>
          )}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs text-white/90 backdrop-blur-sm">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber-200" />
            <span className="line-clamp-1">{disclaimer}</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
              {typeLabel}
            </span>
            {subtypeLabel && (
              <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-white/80">{subtypeLabel}</span>
            )}
            {entity.isVerified && (
              <span className="flex items-center gap-1 rounded-full bg-emerald-500/25 px-3 py-1 text-xs text-emerald-100">
                <Shield className="h-3 w-3" /> 已认证
              </span>
            )}
          </div>

          <h1 className="mt-5 max-w-3xl text-4xl font-bold tracking-tight text-white sm:text-5xl">
            {entity.profile?.title || entity.name}
          </h1>
          {entity.profile?.subtitle && (
            <p className="mt-2 text-base text-white/75">{entity.profile.subtitle}</p>
          )}
          {entity.profile?.slogan && (
            <p className={`mt-6 max-w-2xl border-l-2 pl-4 text-lg font-medium leading-relaxed ${theme.heroBorder} ${theme.accentText}`}>
              {entity.profile.slogan}
            </p>
          )}
          {entity.profile?.summary && (
            <p className="mt-4 max-w-3xl text-sm leading-7 text-white/70 sm:text-base">
              {entity.profile.summary}
            </p>
          )}

          {content.tags.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-2">
              {content.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-white/15 bg-black/10 px-3 py-1 text-xs text-white/85 backdrop-blur-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-6 px-4 pb-36 pt-6 sm:px-6">
        {/* Score dashboard */}
        {latestReport && Object.keys(reportScores).length > 0 && (
          <section className={`-mt-12 rounded-2xl border bg-white p-5 shadow-xl sm:p-6 ${theme.border}`}>
            <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className={`text-xs font-semibold uppercase tracking-widest ${theme.scoreAccent}`}>Brand Score</p>
                <h2 className="mt-1 text-xl font-bold text-slate-900">品牌与传播评分</h2>
                <p className="mt-1 text-sm text-slate-500">基于公开资料与品牌复盘模型综合评估</p>
              </div>
              <ScoreRing score={overallScore} accentClass={theme.scoreAccent} />
            </div>
            <div className="mt-6">
              <ScoreGrid scores={reportScores} accentClass={theme.scoreAccent} />
            </div>
            <Link
              href={reportPath(entity.type, entity.slug)}
              className={`mt-5 inline-flex items-center gap-1 text-sm font-medium ${theme.link} ${theme.linkHover}`}
            >
              查看完整 18 步品牌复盘报告
              <ChevronRight className="h-4 w-4" />
            </Link>
          </section>
        )}

        {/* Sections grid */}
        {displaySections.length > 0 && (
          <section>
            <div className="mb-4 flex items-end justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">Profile</p>
                <h2 className="text-xl font-bold text-slate-900">核心档案</h2>
              </div>
              <span className="text-xs text-slate-400">{displaySections.length} 个模块</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {displaySections.map((section, i) => {
                const Icon = SECTION_ICONS[section.type] || Sparkles;
                return (
                  <article
                    key={i}
                    className={`group rounded-2xl border bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${theme.border}`}
                  >
                    <div className="mb-3 flex items-center gap-3">
                      <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${theme.iconBg} ${theme.iconText}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <h3 className="font-semibold text-slate-900">{section.title}</h3>
                    </div>
                    <p className="text-sm leading-7 text-slate-600">{section.content}</p>
                  </article>
                );
              })}
            </div>
          </section>
        )}

        {/* 图片视频 */}
        {(mediaImages.length > 0 || mediaVideos.length > 0) && (
          <section className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}>
            <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-slate-900">
              <Image className={`h-5 w-5 ${theme.iconText}`} />
              图片与视频
            </h2>
            {mediaImages.length > 0 && (
              <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                {mediaImages.filter((m) => m.type !== "cover").map((img) => (
                  <img
                    key={img.id}
                    src={resolveAssetUrl(img.url)}
                    alt={img.title || entity.name}
                    className="aspect-[4/3] w-full rounded-xl object-cover"
                  />
                ))}
              </div>
            )}
            {mediaVideos.length > 0 && (
              <div className="grid gap-4 sm:grid-cols-2">
                {mediaVideos.map((video) => (
                  <VideoPreviewCard
                    key={video.id}
                    platform={video.platform}
                    url={video.url}
                    title={video.title || "视频"}
                    coverUrl={video.coverUrl}
                    embedUrl={video.embedUrl}
                    canEmbed={video.canEmbed}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {/* News + Related row */}
        <div className="grid gap-6 lg:grid-cols-2">
          {displayNews.length > 0 && (
            <section className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}>
              <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-slate-900">
                <Newspaper className={`h-5 w-5 ${theme.iconText}`} />
                相关报道
              </h2>
              <div className="space-y-3">
                {displayNews.slice(0, 5).map((article) => (
                  <a
                    key={article.id}
                    href={article.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`group block rounded-xl border border-slate-100 bg-white/60 p-3 transition ${theme.hoverBorder} ${theme.hoverBg}`}
                  >
                    <p className={`text-sm font-medium text-slate-800 ${theme.linkHover}`}>
                      {article.title}
                    </p>
                    <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-400">
                      <span>{article.source || "新闻"}</span>
                      <ExternalLink className="h-3 w-3" />
                    </div>
                  </a>
                ))}
              </div>
            </section>
          )}

          {related.length > 0 && (
            <section className={`rounded-2xl border bg-white p-5 shadow-sm ${theme.border}`}>
              <h2 className="mb-4 text-lg font-bold text-slate-900">关联图谱</h2>
              <div className="grid gap-2 sm:grid-cols-2">
                {related.map((rel) => (
                  <Link
                    key={rel.id}
                    href={entityPath(rel.type, rel.slug)}
                    className={`rounded-xl border border-slate-100 bg-white/60 p-3 transition ${theme.hoverBorder} ${theme.hoverBg}`}
                  >
                    <p className="text-[11px] font-medium uppercase tracking-wide text-slate-400">{rel.rel}</p>
                    <p className="mt-1 font-semibold text-slate-800">{rel.name}</p>
                    {rel.profile?.slogan && (
                      <p className="mt-1 line-clamp-1 text-xs text-slate-500">{rel.profile.slogan}</p>
                    )}
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Sources */}
        {displaySources.length > 0 && (
          <section className={`rounded-2xl border border-dashed bg-white/60 p-5 ${theme.border}`}>
            <h2 className="mb-3 text-sm font-semibold text-slate-500">
              权威资料来源 · {displaySources.length}
            </h2>
            <ul className="space-y-2">
              {displaySources.slice(0, 5).map((src) => (
                <li key={src.id}>
                  {src.url ? (
                    <a
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-center justify-between gap-3 rounded-xl border border-slate-100 bg-white px-3 py-2 text-sm text-slate-700 transition ${theme.hoverBorder} ${theme.linkHover}`}
                    >
                      <span className="truncate">{formatSourceLabel(src.title, 36)}</span>
                      <span className="shrink-0 text-[11px] text-slate-400">
                        {src.sourceType === "wiki" ? "百科" : src.sourceType === "official" ? "官网" : "网页"}
                      </span>
                    </a>
                  ) : (
                    <span className="block rounded-xl border border-slate-100 bg-white px-3 py-2 text-sm text-slate-600">
                      {formatSourceLabel(src.title, 36)}
                    </span>
                  )}
                </li>
              ))}
            </ul>
          </section>
        )}
      </main>

      {/* Bottom bar */}
      <div className={`fixed bottom-0 left-0 right-0 z-50 border-t bg-white/90 backdrop-blur-xl ${theme.border}`}>
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3 sm:px-6">
          <button
            type="button"
            onClick={() => setShowClaim(true)}
            className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-semibold shadow-lg ${theme.button} ${theme.buttonText}`}
          >
            <Upload className="h-4 w-4" />
            认领 / 上传
          </button>
          <Link
            href={reportPath(entity.type, entity.slug)}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white py-3.5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
          >
            <FileText className="h-4 w-4" />
            品牌报告
          </Link>
        </div>
      </div>

      {showClaim && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/50 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 text-slate-900 shadow-2xl">
            <h3 className="text-lg font-semibold">认领 / 补充资料</h3>
            <p className="mt-1 text-xs text-slate-500">
              可上传图片、添加视频链接（B站/YouTube/腾讯视频等），认领后管理员审核可见
            </p>

            <div className="mt-4 space-y-4 rounded-xl border border-slate-100 bg-slate-50 p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm font-medium text-slate-700">品牌 IP 图（Fenno AI）</p>
                <button
                  type="button"
                  onClick={generateIpImage}
                  disabled={generatingIpImage}
                  className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-white ${theme.button}`}
                >
                  {generatingIpImage ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="h-3.5 w-3.5" />
                  )}
                  {brandUpgrade ? "生成 IP 图" : "升级后生成"}
                </button>
              </div>
              <p className="text-xs text-slate-500">
                首张图片免费上传；多图上传与 AI 生图需登录并开通品牌升级（¥500）。
              </p>
              <p className="text-sm font-medium text-slate-700">上传图片</p>
              <ImageUploader
                label="相册图片"
                aspect="wide"
                onChange={(url) => attachImageUrl(url)}
                hint="jpg/png/webp，单张 ≤5MB"
              />
              <div>
                <p className="mb-2 text-sm font-medium text-slate-700">添加视频链接</p>
                <div className="flex gap-2">
                  <input
                    placeholder="粘贴 B站 / YouTube / 腾讯视频链接"
                    className="flex-1 rounded-xl border border-slate-200 px-3 py-2.5 text-sm"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={addVideo}
                    disabled={uploadingVideo}
                    className={`rounded-xl px-4 py-2.5 text-sm font-medium text-white ${theme.button}`}
                  >
                    {uploadingVideo ? <Loader2 className="h-4 w-4 animate-spin" /> : "添加"}
                  </button>
                </div>
              </div>
              {uploadMsg && (
                <p className={`text-xs ${uploadMsg.includes("失败") || uploadMsg.includes("需") ? "text-amber-600" : "text-green-600"}`}>
                  {uploadMsg}
                </p>
              )}
            </div>

            {claimMsg ? (
              <p className="py-6 text-center text-green-600">{claimMsg}</p>
            ) : (
              <div className="mt-4 space-y-3">
                <p className="text-xs font-medium text-slate-500">认领申请（可选）</p>
                <p className="text-xs text-slate-400">{AI_DISCLAIMER}</p>
                <input
                  placeholder="您的姓名"
                  className={`w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:ring-2 ${theme.border}`}
                  value={claimForm.contactName}
                  onChange={(e) => setClaimForm({ ...claimForm, contactName: e.target.value })}
                />
                <input
                  placeholder="联系电话"
                  className={`w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:ring-2 ${theme.border}`}
                  value={claimForm.contactPhone}
                  onChange={(e) => setClaimForm({ ...claimForm, contactPhone: e.target.value })}
                />
                <textarea
                  placeholder="请说明认领理由或纠错内容"
                  rows={4}
                  className={`w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none focus:ring-2 ${theme.border}`}
                  value={claimForm.proofText}
                  onChange={(e) => setClaimForm({ ...claimForm, proofText: e.target.value })}
                />
                <button
                  type="button"
                  onClick={submitClaim}
                  className={`w-full rounded-xl py-3 text-sm font-semibold ${theme.button} ${theme.buttonText}`}
                >
                  提交申请
                </button>
              </div>
            )}
            <button
              type="button"
              onClick={() => { setShowClaim(false); setClaimMsg(""); }}
              className="mt-3 w-full text-sm text-slate-400"
            >
              关闭
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
