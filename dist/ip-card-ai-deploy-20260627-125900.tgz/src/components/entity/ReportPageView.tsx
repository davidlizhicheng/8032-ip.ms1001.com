import Link from "next/link";
import { ArrowLeft, ChevronRight, BookOpen } from "lucide-react";
import { getTheme, getDefaultEntityTheme } from "@/lib/themes";
import { getDisclaimer } from "@/lib/compliance/risk-check";
import type { EntityReportContent, ReportStep } from "@/lib/schemas/entity";
import { entityPath } from "@/lib/utils/entity-paths";
import {
  BRAND_REVIEW_PHASES,
  STEP_SECTION_KEYS,
} from "@/lib/ai/brand-report-template";
import { isPlaceholderContent, sanitizeText } from "@/lib/content/sanitize-placeholder";

type ReportPageData = {
  entity: {
    id: string;
    type: string;
    name: string;
    slug: string;
    subtype?: string | null;
    isVerified: boolean;
    profile?: { theme?: string; title?: string | null } | null;
  };
  report: {
    title: string;
    summary?: string | null;
    contentJson: string;
    scoreJson?: string | null;
  };
};

function StepCard({
  step,
  theme,
}: {
  step: ReportStep;
  theme: ReturnType<typeof getTheme>;
}) {
  const sections = STEP_SECTION_KEYS.map(({ key, label }) => ({
    label,
    content: sanitizeText(step[key as keyof ReportStep] as string),
  })).filter((s) => s.content.length > 0);

  if (sections.length === 0) return null;

  return (
    <section id={`step-${step.step}`} className={`rounded-2xl border ${theme.border} overflow-hidden`}>
      <div className="bg-gradient-to-r from-orange-500/15 via-purple-500/10 to-transparent px-4 py-3">
        <p className={`text-xs font-medium ${theme.scoreAccent}`}>第 {step.step} 步</p>
        <h2 className="text-lg font-bold">{step.title}</h2>
        {step.subtitle && (
          <p className="text-sm opacity-70">——{step.subtitle}</p>
        )}
      </div>
      <div className="space-y-4 p-4">
        {sections.map(({ label, content }) => (
          <div key={label}>
            <h3 className={`mb-1.5 text-sm font-semibold ${theme.accent}`}>{label}</h3>
            <p className={`text-sm leading-relaxed ${theme.muted}`}>{content}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ReportPageView({ data }: { data: ReportPageData }) {
  const theme = getTheme(getDefaultEntityTheme(data.entity.type, data.entity.slug, data.entity.name));
  const disclaimer = getDisclaimer(
    data.entity.type as "city",
    data.entity.subtype,
    data.entity.isVerified,
  );

  let scores: Record<string, number> = {};
  let overall = 0;
  let content: EntityReportContent = { recommendations: [] };

  if (data.report.scoreJson) {
    try {
      const p = JSON.parse(data.report.scoreJson);
      scores = p.scores || {};
      overall = p.overall || 0;
    } catch { /* */ }
  }
  try {
    content = JSON.parse(data.report.contentJson);
  } catch { /* */ }

  const steps = content.steps || [];
  const has18Steps = steps.length > 0;

  return (
    <div className={`min-h-screen ${theme.card} ${theme.text}`}>
      <div className="mx-auto max-w-[800px] px-4 py-8 pb-20">
        <Link
          href={entityPath(data.entity.type, data.entity.slug)}
          className="mb-6 inline-flex items-center gap-1 text-sm opacity-60 hover:opacity-100"
        >
          <ArrowLeft className="h-4 w-4" />
          返回主页
        </Link>

        <div className={`flex items-center gap-2 text-xs ${theme.scoreAccent}`}>
          <BookOpen className="h-4 w-4" />
          品牌复盘18步 · 决胜终端
        </div>
        <p className="mt-2 text-xs text-amber-300/70">{disclaimer}</p>
        <h1 className="mt-4 text-2xl font-bold leading-snug">{data.report.title}</h1>
        {data.report.summary && (
          <p className="mt-4 text-sm leading-relaxed opacity-80">{data.report.summary}</p>
        )}

        {content.one_line_positioning && (
          <div className={`mt-4 rounded-xl border ${theme.border} bg-white/5 p-4`}>
            <p className="text-xs opacity-60">一句话定位</p>
            <p className={`mt-1 text-lg font-semibold ${theme.accentText}`}>「{content.one_line_positioning}」</p>
          </div>
        )}

        {overall > 0 && (
          <div className={`mt-6 grid gap-4 sm:grid-cols-[1fr_2fr]`}>
            <div className={`rounded-2xl border ${theme.border} p-6 text-center`}>
              <p className="text-sm opacity-60">综合评分</p>
              <p className={`text-5xl font-bold ${theme.scoreAccent}`}>{overall}</p>
              <p className="text-xs opacity-40">满分 10 分</p>
            </div>
            {Object.keys(scores).length > 0 && (
              <div className={`rounded-2xl border ${theme.border} p-4`}>
                <h2 className={`mb-3 text-sm font-semibold ${theme.accent}`}>10维品牌评分</h2>
                <div className="grid gap-2 sm:grid-cols-2">
                  {Object.entries(scores).map(([k, v]) => (
                    <div key={k} className="flex items-center justify-between text-xs">
                      <span className="opacity-70">{k}</span>
                      <span className={`font-bold ${theme.scoreAccent}`}>{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* 18步目录导航 */}
        {has18Steps && (
          <nav className={`mt-8 rounded-2xl border ${theme.border} p-4`}>
            <h2 className={`mb-3 font-semibold ${theme.accent}`}>18步全景导航</h2>
            {BRAND_REVIEW_PHASES.map((phase) => {
              const phaseSteps = steps.filter(
                (s) => s.step >= phase.stepRange[0] && s.step <= phase.stepRange[1],
              );
              if (!phaseSteps.length) return null;
              return (
                <div key={phase.id} className="mb-4 last:mb-0">
                  <p className="text-xs font-medium text-amber-400/80">
                    {phase.title}（{phase.steps}）· {phase.subtitle}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {phaseSteps.map((s) => (
                      <a
                        key={s.step}
                        href={`#step-${s.step}`}
                        className="rounded-lg bg-white/5 px-2.5 py-1 text-xs hover:bg-white/10"
                      >
                        {s.step}. {s.title}
                      </a>
                    ))}
                  </div>
                </div>
              );
            })}
          </nav>
        )}

        {/* 18步正文 */}
        {has18Steps ? (
          <div className="mt-6 space-y-6">
            {BRAND_REVIEW_PHASES.map((phase) => {
              const phaseSteps = steps.filter(
                (s) => s.step >= phase.stepRange[0] && s.step <= phase.stepRange[1],
              );
              if (!phaseSteps.length) return null;
              return (
                <div key={phase.id}>
                  <div className="mb-4 border-l-4 border-amber-500 pl-3">
                    <h2 className="text-lg font-bold">{phase.title}</h2>
                    <p className="text-sm opacity-60">{phase.subtitle}</p>
                  </div>
                  <div className="space-y-4">
                    {phaseSteps.map((step) => (
                      <StepCard key={step.step} step={step} theme={theme} />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          content.sections?.map((s, i) => (
            <section key={i} className={`mt-4 rounded-2xl border ${theme.border} p-4`}>
              <h2 className={`mb-2 font-semibold ${theme.accent}`}>{s.title}</h2>
              <p className={`text-sm leading-relaxed ${theme.muted}`}>{s.content}</p>
            </section>
          ))
        )}

        {content.recommendations && content.recommendations.length > 0 && (
          <section className={`mt-6 rounded-2xl border p-4 ${theme.border} bg-white/50`}>
            <h2 className={`mb-3 font-semibold ${theme.scoreAccent}`}>改进建议</h2>
            <ul className="space-y-2">
              {content.recommendations.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <ChevronRight className={`mt-0.5 h-4 w-4 shrink-0 ${theme.scoreAccent}`} />
                  {r}
                </li>
              ))}
            </ul>
          </section>
        )}

        {content.training_points && content.training_points.length > 0 && (
          <section className={`mt-4 rounded-2xl border ${theme.border} p-4`}>
            <h2 className={`mb-3 font-semibold ${theme.iconText}`}>案例学习要点</h2>
            <ul className="space-y-2">
              {content.training_points.map((r, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-xs ${theme.iconBg} ${theme.iconText}`}>
                    {i + 1}
                  </span>
                  {r}
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </div>
  );
}
