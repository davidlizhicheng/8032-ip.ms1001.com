import Link from "next/link";
import type { LucideIcon } from "lucide-react";

type Item = {
  id: string;
  name: string;
  slug: string;
  href: string;
  subtitle?: string | null;
  badge?: string;
};

export function LibraryListPage({
  title,
  description,
  icon: Icon,
  iconColor,
  viewAllHref,
  items,
  emptyHint,
}: {
  title: string;
  description: string;
  icon: LucideIcon;
  iconColor: string;
  viewAllHref?: string;
  items: Item[];
  emptyHint: string;
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50">
      <header className="border-b border-slate-200/80 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-4xl items-center gap-3 px-6 py-4">
          <Link href="/" className="text-sm text-slate-500 hover:text-orange-600">
            ← 首页
          </Link>
          <div className="flex-1">
            <h1 className={`flex items-center gap-2 text-xl font-bold text-slate-900`}>
              <Icon className={`h-5 w-5 ${iconColor}`} />
              {title}
            </h1>
            <p className="text-sm text-slate-500">{description}</p>
          </div>
          <span className="text-xs text-slate-400">{items.length} 个公开</span>
        </div>
      </header>
      <main className="mx-auto max-w-4xl px-6 py-8">
        {items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-slate-200 bg-white py-16 text-center text-slate-500">
            {emptyHint}
          </p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2">
            {items.map((item) => (
              <li key={item.id}>
                <Link
                  href={item.href}
                  className="block rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:border-orange-200 hover:shadow-md"
                >
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-slate-900">{item.name}</p>
                    {item.badge && (
                      <span className="rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-semibold text-orange-700">
                        {item.badge}
                      </span>
                    )}
                  </div>
                  {item.subtitle && (
                    <p className="mt-1 line-clamp-2 text-sm text-slate-500">{item.subtitle}</p>
                  )}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
