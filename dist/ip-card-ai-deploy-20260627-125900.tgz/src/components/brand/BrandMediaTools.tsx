"use client";

import { useState } from "react";
import { Crown, Loader2, Sparkles, Upload } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { authFetch } from "@/lib/auth/client";
import { ImageUploader } from "@/components/ui/ImageUploader";

type Props = {
  slug: string;
  kind: "entity" | "card";
  targetId: string;
  themeButtonClass?: string;
  onImageAdded?: (asset: { id: string; url: string; type: string; title?: string | null }) => void;
};

export function BrandMediaTools({
  slug,
  kind,
  targetId,
  themeButtonClass = "bg-orange-500",
  onImageAdded,
}: Props) {
  const { user, brandUpgrade, login, openBilling } = useAuth();
  const [msg, setMsg] = useState("");
  const [generating, setGenerating] = useState(false);

  const mediaBase = kind === "entity" ? `/api/entities/${slug}/media` : `/api/cards/${slug}/media`;
  const ipBase =
    kind === "entity"
      ? `/api/entities/${slug}/generate-ip-image`
      : `/api/cards/${slug}/generate-ip-image`;

  async function handleError(data: { error?: string; code?: string }) {
    if (data.code === "LOGIN_REQUIRED") {
      setMsg("请先登录");
      login("login");
      return;
    }
    if (data.code === "UPGRADE_REQUIRED") {
      setMsg("需开通品牌升级（¥500）");
      const opts = kind === "entity" ? { entityId: targetId } : { cardId: targetId };
      await openBilling(opts).catch(() => {});
      return;
    }
    setMsg(data.error || "操作失败");
  }

  async function attachImage(url: string) {
    if (!url) return;
    setMsg("保存中…");
    const res = await authFetch(mediaBase, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageUrl: url, type: "gallery" }),
    });
    const data = await res.json();
    if (data.asset) {
      onImageAdded?.(data.asset);
      setMsg("图片已添加");
    } else {
      await handleError(data);
    }
  }

  async function generateIp() {
    if (!user) {
      login("login");
      return;
    }
    if (!brandUpgrade) {
      setMsg("AI 生 IP 图需开通品牌升级（¥500）");
      const opts = kind === "entity" ? { entityId: targetId } : { cardId: targetId };
      await openBilling(opts).catch(() => {});
      return;
    }
    setGenerating(true);
    setMsg("AI 正在生成品牌 IP 图…");
    try {
      const res = await authFetch(ipBase, {
        method: "POST",
        body: JSON.stringify({ target: "cover" }),
      });
      const data = await res.json();
      if (data.asset) {
        onImageAdded?.(data.asset);
        setMsg("品牌 IP 图已生成");
      } else {
        await handleError(data);
      }
    } catch {
      setMsg("生成失败，请稍后重试");
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="space-y-4 rounded-xl border border-slate-100 bg-slate-50 p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-slate-800">品牌 IP 图（Fenno AI）</p>
          <p className="mt-0.5 text-xs text-slate-500">首张免费；多图上传与 AI 生图需登录并升级（¥500）</p>
        </div>
        <button
          type="button"
          onClick={generateIp}
          disabled={generating}
          className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-white ${themeButtonClass}`}
        >
          {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
          {brandUpgrade ? "生成 IP 图" : "升级后生图"}
        </button>
      </div>

      {!brandUpgrade && (
        <button
          type="button"
          onClick={() =>
            openBilling(kind === "entity" ? { entityId: targetId } : { cardId: targetId })
          }
          className="inline-flex items-center gap-1.5 rounded-lg border border-purple-200 bg-purple-50 px-3 py-1.5 text-xs font-medium text-purple-700"
        >
          <Crown className="h-3.5 w-3.5" />
          品牌升级 ¥500
        </button>
      )}

      <div>
        <p className="mb-2 flex items-center gap-1.5 text-sm font-medium text-slate-700">
          <Upload className="h-4 w-4" />
          上传更多图片
        </p>
        <ImageUploader label="相册图片" aspect="wide" onChange={attachImage} hint="jpg/png/webp" />
      </div>

      {msg && (
        <p
          className={`text-xs ${msg.includes("失败") || msg.includes("需") || msg.includes("登录") ? "text-amber-600" : "text-green-600"}`}
        >
          {msg}
        </p>
      )}
    </div>
  );
}
