"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Sparkles, Loader2, Plus, Trash2, Globe, AlertTriangle } from "lucide-react";
import { authFetch } from "@/lib/auth/client";
import { ImageUploader } from "@/components/ui/ImageUploader";
import { VideoPreviewCard } from "@/components/ui/VideoPreviewCard";
import { PersonDisambiguationPanel } from "@/components/person/PersonDisambiguationPanel";
import { THEMES } from "@/lib/themes";
import type { ParsedCardInfo, CardTheme } from "@/lib/schemas/card";
import type { VideoPreview } from "@/lib/schemas/card";

const SAMPLE_TEXT = `我叫何雪可，是深圳市超级品牌顾问有限公司董事长助理，负责品牌战略咨询、品牌营销、爆品打造。电话18820289859，邮箱coco@chaojipinpai.com。长期参与企业品牌咨询与项目管理，服务企业品牌升级与增长转型。`;

type VideoItem = VideoPreview & { id: string };

type PersonCandidate = {
  id: string;
  label: string;
  title?: string;
  company?: string;
  snippet: string;
  url?: string;
  region?: string;
};

type ComparisonResult = {
  title: string;
  summary: string;
  long_content: string;
  sections: Array<{ title: string; content: string }>;
  candidates: Array<{ id: string; label: string; region: string }>;
};

export function CardCreateForm() {
  const router = useRouter();
  const [rawText, setRawText] = useState("");
  const [parsing, setParsing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [parsed, setParsed] = useState(false);
  const [enrichFromWeb, setEnrichFromWeb] = useState(false);
  const [sourcesUsed, setSourcesUsed] = useState(0);
  const [researchSteps, setResearchSteps] = useState<
    Array<{ label: string; url?: string; status: string; detail?: string }>
  >([]);
  const [disambiguation, setDisambiguation] = useState<{
    name: string;
    reason: string;
    candidates: PersonCandidate[];
    allowCompare?: boolean;
  } | null>(null);
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);

  const [form, setForm] = useState({
    name: "",
    title: "",
    company: "",
    brandSlogan: "",
    bio: "",
    longBio: "",
    phone: "",
    email: "",
    wechat: "",
    address: "",
    theme: "brand_orange" as CardTheme,
    avatarUrl: "",
    coverUrl: "",
    services: [] as string[],
    experiences: [] as Array<{ title: string; content: string }>,
    honors: [] as Array<{ title: string; content: string }>,
    cases: [] as Array<{ title: string; content: string }>,
    profileSections: [] as Array<{ type: string; title: string; content: string }>,
  });

  const [galleryImages, setGalleryImages] = useState<
    Array<{ url: string; type: string; title?: string }>
  >([]);
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [videoUrl, setVideoUrl] = useState("");
  const [videoLoading, setVideoLoading] = useState(false);

  const minPasteLength = enrichFromWeb ? 2 : 10;

  async function handleParse(confirmedCandidateId?: string, compareMode = false) {
    const pendingDisambiguation = disambiguation;
    setParsing(true);
    setError("");
    if (!compareMode) setDisambiguation(null);
    setComparison(null);
    setResearchSteps([]);
    try {
      const res = await fetch("/api/ai/parse-card-info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rawText,
          enrichFromWeb,
          confirmedCandidateId,
          compareMode,
          compareCandidateIds: compareMode
            ? pendingDisambiguation?.candidates.slice(0, 2).map((c) => c.id)
            : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "解析失败");

      if (data.status === "needs_confirmation") {
        setDisambiguation({
          name: data.name,
          reason: data.reason,
          candidates: data.candidates,
          allowCompare: data.allowCompare,
        });
        return;
      }

      if (data.status === "comparison") {
        setDisambiguation(null);
        setComparison(data.comparison);
        setParsed(true);
        setForm((prev) => ({
          ...prev,
          name: data.name,
          bio: data.comparison.summary,
          longBio: data.comparison.long_content,
          profileSections: (data.comparison.sections || []).map(
            (s: { title: string; content: string }, i: number) => ({
              type: `compare_${i}`,
              title: s.title,
              content: s.content,
            }),
          ),
        }));
        return;
      }

      applyParsedResult(data);
      setSourcesUsed(data.sourcesUsed || 0);
      setResearchSteps(data.researchSteps || []);
      setParsed(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "解析失败");
    } finally {
      setParsing(false);
    }
  }

  function applyParsedResult(
    result: ParsedCardInfo & {
      sourcesUsed?: number;
      famousMedia?: {
        avatarUrl?: string;
        coverUrl?: string;
        galleryImages?: Array<{ url: string; type: string; title?: string }>;
        videos?: Array<{
          platform: string;
          url: string;
          title?: string;
          coverUrl?: string;
          embedUrl?: string;
          canEmbed: boolean;
        }>;
        source?: string;
      } | null;
    },
  ) {
    setForm({
      name: result.name,
      title: result.title,
      company: result.company,
      brandSlogan: result.brand_slogan,
      bio: result.bio,
      longBio: result.long_bio || "",
      phone: result.phone,
      email: result.email,
      wechat: result.wechat,
      address: result.address,
      theme: result.suggested_theme,
      avatarUrl: result.famousMedia?.avatarUrl || "",
      coverUrl: result.famousMedia?.coverUrl || "",
      services: result.services,
      experiences: result.experiences,
      honors: result.honors,
      cases: result.cases,
      profileSections: result.profile_sections || [],
    });

    if (result.famousMedia?.galleryImages?.length) {
      setGalleryImages(result.famousMedia.galleryImages);
    }
    if (result.famousMedia?.videos?.length) {
      setVideos(
        result.famousMedia.videos.map((v, i) => ({
          platform: v.platform,
          url: v.url,
          title: v.title || "相关视频",
          cover_url: v.coverUrl || "",
          embed_url: v.embedUrl || "",
          can_embed: v.canEmbed,
          id: `famous-${i}-${Date.now()}`,
        })),
      );
    }
  }

  function confirmCandidate(id: string) {
    handleParse(id, false);
  }

  function handleCompare() {
    handleParse(undefined, true);
  }

  async function handleAddVideo() {
    if (!videoUrl.trim()) return;
    setVideoLoading(true);
    try {
      const res = await fetch("/api/video/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: videoUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "视频解析失败");
      setVideos((prev) => [
        ...prev,
        { ...data, id: `${Date.now()}-${prev.length}` },
      ]);
      setVideoUrl("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "视频解析失败");
    } finally {
      setVideoLoading(false);
    }
  }

  async function handleSave() {
    if (!form.name.trim()) {
      setError("请填写姓名");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const res = await authFetch("/api/cards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          galleryImages,
          videos: videos.map((v) => ({
            platform: v.platform,
            url: v.url,
            title: v.title,
            coverUrl: v.cover_url,
            embedUrl: v.embed_url,
            canEmbed: v.can_embed,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "保存失败");
      router.push(`/me?created=${data.slug}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "保存失败");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-8">
      {/* Step 1: Raw text */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">1. 粘贴个人资料</h2>
        <p className="mt-1 text-sm text-slate-500">
          可以粘贴杂乱文字，AI 自动整理并扩写为 1000-2000 字的个人品牌主页内容
        </p>
        <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-xl border border-orange-100 bg-orange-50/50 p-3">
          <input
            type="checkbox"
            className="mt-1"
            checked={enrichFromWeb}
            onChange={(e) => setEnrichFromWeb(e.target.checked)}
          />
          <span className="text-sm text-slate-700">
            <span className="flex items-center gap-1 font-medium text-orange-700">
              <Globe className="h-4 w-4" />
              结合网上信息生成
            </span>
            <span className="mt-0.5 block text-slate-500">
              适用于名人/公众人物：先检索百度百科/维基百科确认身份，再生成详细介绍
            </span>
          </span>
        </label>
        <textarea
          rows={6}
          className="mt-4 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm leading-relaxed focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-100"
          placeholder="粘贴您的个人介绍、简历、业务描述..."
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
        />
        <p className="mt-2 text-xs text-slate-500">
          {enrichFromWeb
            ? "已开启联网：至少 2 个字（如姓名）即可，重名时会要求确认身份；资料越详细效果越好"
            : "未开启联网：请至少粘贴 10 个字的个人资料"}
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setRawText(SAMPLE_TEXT)}
            className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-50"
          >
            填入示例（何雪可）
          </button>
          <button
            type="button"
            onClick={() => handleParse()}
            disabled={parsing || rawText.trim().length < minPasteLength}
            className="inline-flex items-center gap-2 rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-zinc-900 disabled:opacity-50"
          >
            {parsing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4" />
            )}
            AI 生成名片
          </button>
        </div>
        {parsing && enrichFromWeb && (
          <p className="mt-2 text-xs text-orange-600">正在检索百度百科、维基百科、新闻与网页…</p>
        )}
        {researchSteps.length > 0 && (
          <div className="mt-4 rounded-xl border border-slate-100 bg-slate-50 p-3">
            <p className="text-xs font-medium text-slate-600">已检索 {sourcesUsed} 条资料</p>
            <ul className="mt-2 max-h-40 space-y-1 overflow-y-auto text-xs text-slate-600">
              {researchSteps
                .filter((s) => s.status === "done")
                .slice(-12)
                .map((step, i) => (
                  <li key={`${step.label}-${i}`}>
                    {step.label}
                    {step.detail ? ` · ${step.detail}` : ""}
                  </li>
                ))}
            </ul>
          </div>
        )}
      </section>

      {disambiguation && (
        <PersonDisambiguationPanel
          name={disambiguation.name}
          reason={disambiguation.reason}
          candidates={disambiguation.candidates}
          allowCompare={disambiguation.allowCompare}
          loading={parsing}
          onSelect={confirmCandidate}
          onCompare={handleCompare}
        />
      )}

      {comparison && (
        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-900">{comparison.title}</h2>
          <p className="mt-3 text-sm leading-7 text-slate-600">{comparison.summary}</p>
          <div className="mt-4 space-y-4">
            {comparison.sections.map((section) => (
              <div key={section.title}>
                <h3 className="font-medium text-slate-900">{section.title}</h3>
                <p className="mt-2 whitespace-pre-line text-sm leading-7 text-slate-600">
                  {section.content}
                </p>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-slate-400">
            对比 {comparison.candidates.map((c) => c.label).join(" vs ")} · 主体约{" "}
            {comparison.long_content.length} 字
          </p>
        </section>
      )}

      {parsed && (
        <>
          {/* Step 2: Form */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">2. 确认信息</h2>
            {sourcesUsed > 0 && (
              <p className="mt-1 text-xs text-green-600">已整合 {sourcesUsed} 条网上公开资料</p>
            )}
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {(
                [
                  ["name", "姓名", true],
                  ["title", "职位", false],
                  ["company", "公司", false],
                  ["brandSlogan", "品牌定位", false],
                  ["phone", "电话", false],
                  ["email", "邮箱", false],
                  ["wechat", "微信", false],
                  ["address", "地址", false],
                ] as const
              ).map(([key, label, required]) => (
                <div key={key} className={key === "brandSlogan" ? "sm:col-span-2" : ""}>
                  <label className="text-sm font-medium text-slate-700">
                    {label}
                    {required && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm focus:border-amber-400 focus:outline-none"
                    value={form[key]}
                    onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                  />
                </div>
              ))}
              <div className="sm:col-span-2">
                <label className="text-sm font-medium text-slate-700">个人简介（概述）</label>
                <textarea
                  rows={3}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm focus:border-amber-400 focus:outline-none"
                  value={form.bio}
                  onChange={(e) => setForm({ ...form, bio: e.target.value })}
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm font-medium text-slate-700">详细介绍（1000-2000 字主体内容）</label>
                <textarea
                  rows={10}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm leading-relaxed focus:border-amber-400 focus:outline-none"
                  value={form.longBio}
                  onChange={(e) => setForm({ ...form, longBio: e.target.value })}
                />
                <p className="mt-1 text-xs text-slate-400">当前约 {form.longBio.length} 字</p>
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm font-medium text-slate-700">模板主题</label>
                <select
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm"
                  value={form.theme}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      theme: e.target.value as typeof form.theme,
                    })
                  }
                >
                  {Object.values(THEMES).map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </section>

          {/* Step 3: Images */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">3. 上传图片</h2>
            <div className="mt-4 grid gap-6 sm:grid-cols-2">
              <ImageUploader
                label="头像"
                value={form.avatarUrl}
                onChange={(url) => setForm({ ...form, avatarUrl: url })}
                aspect="square"
              />
              <ImageUploader
                label="封面背景图"
                value={form.coverUrl}
                onChange={(url) => setForm({ ...form, coverUrl: url })}
                aspect="cover"
                hint="建议横版图片"
              />
            </div>
            <div className="mt-6">
              <ImageUploader
                label="业务海报 / 案例图片"
                uploadIndex={galleryImages.length}
                onChange={(url) =>
                  setGalleryImages((prev) => [
                    ...prev,
                    { url, type: "gallery" },
                  ])
                }
                aspect="wide"
              />
              {galleryImages.length > 0 && (
                <div className="mt-3 grid grid-cols-3 gap-2">
                  {galleryImages.map((img, i) => (
                    <div key={img.url} className="relative">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={img.url}
                        alt=""
                        className="aspect-square rounded-lg object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setGalleryImages((prev) =>
                            prev.filter((_, idx) => idx !== i),
                          )
                        }
                        className="absolute right-1 top-1 rounded-full bg-black/50 p-1 text-white"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Step 4: Videos */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">4. 视频链接</h2>
            <div className="mt-4 flex gap-2">
              <input
                className="flex-1 rounded-xl border border-slate-200 px-3 py-2.5 text-sm"
                placeholder="粘贴抖音、B站、YouTube 等视频链接"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
              />
              <button
                type="button"
                onClick={handleAddVideo}
                disabled={videoLoading}
                className="inline-flex items-center gap-1 rounded-xl border border-slate-200 px-4 py-2.5 text-sm hover:bg-slate-50"
              >
                {videoLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Plus className="h-4 w-4" />
                )}
                添加
              </button>
            </div>
            {videos.length > 0 && (
              <div className="mt-4 space-y-3">
                {videos.map((video) => (
                  <div key={video.id} className="relative">
                    <VideoPreviewCard
                      platform={video.platform}
                      url={video.url}
                      title={video.title}
                      coverUrl={video.cover_url}
                      embedUrl={video.embed_url}
                      canEmbed={video.can_embed}
                      compact
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setVideos((prev) => prev.filter((v) => v.id !== video.id))
                      }
                      className="absolute right-2 top-2 rounded-full bg-black/50 p-1.5 text-white"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Save */}
          <div className="flex flex-col items-center gap-3 pb-8">
            {error && (
              <p className="text-sm text-red-500">{error}</p>
            )}
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="w-full max-w-md rounded-2xl bg-zinc-900 py-4 text-base font-semibold text-white disabled:opacity-50 sm:w-auto sm:px-12"
            >
              {saving ? "保存中..." : "保存并预览名片"}
            </button>
          </div>
        </>
      )}

      {!parsed && error && (
        <p className="text-center text-sm text-red-500">{error}</p>
      )}
    </div>
  );
}
