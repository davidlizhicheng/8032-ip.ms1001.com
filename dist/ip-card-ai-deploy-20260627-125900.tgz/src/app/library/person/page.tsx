import { User } from "lucide-react";
import { LibraryListPage } from "@/components/library/LibraryListPage";
import { getPublicCards, getPublicEntitiesByType } from "@/lib/services/content-visibility";

export const dynamic = "force-dynamic";

export default async function PersonLibraryPage() {
  const [persons, cards] = await Promise.all([
    getPublicEntitiesByType("person", 300),
    getPublicCards(200),
  ]);

  const items = [
    ...persons.map((e) => ({
      id: e.id,
      name: e.name,
      slug: e.slug,
      href: `/person/${e.slug}`,
      subtitle: e.profile?.slogan || e.profile?.summary,
      badge: e.isFeatured ? "官方推荐" : e.isOfficial ? "官方" : "人物档案",
    })),
    ...cards.map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      href: `/u/${c.slug}`,
      subtitle: c.brandSlogan || c.title || c.bio,
      badge: c.isFeatured ? "官方推荐" : "个人名片",
    })),
  ];

  return (
    <LibraryListPage
      title="人物 IP 库 · 全部公开"
      description="官方人物档案与用户公开的个人品牌页"
      icon={User}
      iconColor="text-purple-600"
      emptyHint="暂无公开人物内容。用户创建名片后设为「公开可见」即可出现在此。"
      items={items}
    />
  );
}
