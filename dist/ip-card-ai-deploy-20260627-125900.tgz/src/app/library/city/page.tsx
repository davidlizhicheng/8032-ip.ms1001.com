import { MapPin } from "lucide-react";
import { LibraryListPage } from "@/components/library/LibraryListPage";
import { getPublicEntitiesByType } from "@/lib/services/content-visibility";

export const dynamic = "force-dynamic";

export default async function CityLibraryPage() {
  const cities = await getPublicEntitiesByType("city", 300);
  return (
    <LibraryListPage
      title="城市品牌库 · 全部公开"
      description="官方推荐与用户公开的城市品牌档案"
      icon={MapPin}
      iconColor="text-sky-600"
      emptyHint="暂无公开城市档案。官方批量生成并公开后，或用户创建并设为公开后，会出现在这里。"
      items={cities.map((e) => ({
        id: e.id,
        name: e.name,
        slug: e.slug,
        href: `/city/${e.slug}`,
        subtitle: e.profile?.slogan || e.profile?.summary,
        badge: e.isFeatured ? "官方推荐" : e.isOfficial ? "官方" : undefined,
      }))}
    />
  );
}
