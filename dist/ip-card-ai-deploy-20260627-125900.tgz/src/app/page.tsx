import Link from "next/link";
import {
  Building2,
  MapPin,
  User,
  Sparkles,
  FileText,
  Newspaper,
  Shield,
  Layers,
} from "lucide-react";
import { AuthBar } from "@/components/auth/AuthBar";
import { HomeEntityColumn } from "@/components/home/HomeEntityColumn";
import {
  getFeaturedByType,
  getNewEntityIdsFromBatchJob,
} from "@/lib/services/entity";

type Props = {
  searchParams: Promise<{ fromBatch?: string }>;
};

export const dynamic = "force-dynamic";

export default async function HomePage({ searchParams }: Props) {
  const params = await searchParams;
  const [cities, companies, persons, highlightIds] = await Promise.all([
    getFeaturedByType("city", 12),
    getFeaturedByType("company", 12),
    getFeaturedByType("person", 12),
    params.fromBatch ? getNewEntityIdsFromBatchJob(params.fromBatch) : Promise.resolve([]),
  ]);

  const highlights = new Set(highlightIds);
  const batchDone = params.fromBatch && highlights.size > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-purple-50 text-slate-900">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-32 top-0 h-96 w-96 rounded-full bg-orange-200/40 blur-3xl" />
        <div className="absolute -right-24 top-1/4 h-80 w-80 rounded-full bg-purple-200/50 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-amber-100/60 blur-3xl" />
      </div>

      <header className="relative mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-purple-600 text-lg font-bold text-white shadow-md">
            IP
          </div>
          <div>
            <span className="font-semibold text-slate-900">AI城市企业人物品牌网</span>
            <p className="text-xs text-slate-500">超级品牌IP网</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/admin/batch" className="hidden text-sm text-slate-600 hover:text-orange-600 sm:block">
            批量生成
          </Link>
          <Link href="/admin/claims" className="hidden text-sm text-slate-600 hover:text-purple-600 sm:block">
            认领审核
          </Link>
          <Link href="/me" className="hidden text-sm text-slate-600 hover:text-purple-600 sm:block">
            我的品牌页
          </Link>
          <Link href="/admin/content" className="hidden text-sm text-slate-600 hover:text-slate-500 sm:block">
            内容管理
          </Link>
          <AuthBar />
          <Link
            href="/create"
            className="rounded-full bg-gradient-to-r from-orange-500 to-orange-600 px-5 py-2 text-sm font-semibold text-white shadow-md hover:from-orange-400 hover:to-orange-500"
          >
            创建名片
          </Link>
        </div>
      </header>

      <main className="relative mx-auto max-w-6xl px-6 pb-20">
        {/* Hero — 保留原上半部分 */}
        <section className="py-10 text-center">
          <p className="text-sm font-medium text-orange-600">四库一网 · AI品牌资产平台</p>
          <h1 className="mt-4 text-4xl font-bold leading-tight text-slate-900 sm:text-5xl">
            城市 · 企业 · 人物
            <br />
            <span className="bg-gradient-to-r from-orange-500 via-amber-500 to-purple-600 bg-clip-text text-transparent">
              AI自动生成品牌档案与传播报告
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
            批量输入名称，自动抓取公开报道，生成宣传主页、品牌分析报告与关系图谱。支持认领、修改、纠错。
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link
              href="/admin/batch"
              className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-orange-500 to-orange-600 px-6 py-3 font-semibold text-white shadow-md hover:from-orange-400 hover:to-orange-500"
            >
              <Sparkles className="h-5 w-5" />
              批量生成
            </Link>
            <Link
              href="/create"
              className="rounded-2xl border border-purple-200 bg-white px-6 py-3 text-purple-700 shadow-sm hover:border-purple-300 hover:bg-purple-50"
            >
              个人名片
            </Link>
          </div>
        </section>

        {/* 四库入口 */}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: MapPin, title: "城市品牌库", desc: "城市定位、产业、招商", href: "/library/city", color: "text-sky-600", border: "hover:border-sky-300" },
            { icon: Building2, title: "企业品牌库", desc: "企业档案、竞品分析", href: "/library/company", color: "text-orange-600", border: "hover:border-orange-300" },
            { icon: User, title: "人物IP库", desc: "企业家、专家、达人", href: "/library/person", color: "text-purple-600", border: "hover:border-purple-300" },
            { icon: FileText, title: "品牌报告库", desc: "传播分析、评分报告", href: "/library/company", color: "text-fuchsia-600", border: "hover:border-fuchsia-300" },
          ].map((item) => (
            <Link
              key={item.title}
              href={item.href}
              className={`rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md ${item.border}`}
            >
              <item.icon className={`h-8 w-8 ${item.color}`} />
              <h3 className="mt-3 font-semibold text-slate-900">{item.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{item.desc}</p>
            </Link>
          ))}
        </section>

        {batchDone && (
          <div className="mt-10 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800">
            批量生成完成，本次新增 <strong>{highlights.size}</strong> 个档案（下方列表已高亮标注「新」）。
          </div>
        )}

        {/* 官方推荐 — 仅 isFeatured */}
        <section className="mt-16">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">Featured</p>
              <h2 className="text-xl font-bold text-slate-900">官方推荐品牌档案</h2>
              <p className="mt-1 text-xs text-slate-500">用户公开内容请点各库「查看全部」</p>
            </div>
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            <HomeEntityColumn
              title="城市品牌"
              icon={MapPin}
              iconColor="text-sky-600"
              hrefPrefix="/city"
              libraryHref="/library/city"
              entities={cities}
              highlightIds={highlights}
              emptyHint="暂无官方推荐，管理员可在内容管理中设置"
            />
            <HomeEntityColumn
              title="企业品牌"
              icon={Building2}
              iconColor="text-orange-600"
              hrefPrefix="/company"
              libraryHref="/library/company"
              entities={companies}
              highlightIds={highlights}
              emptyHint="暂无官方推荐"
            />
            <HomeEntityColumn
              title="人物 IP"
              icon={User}
              iconColor="text-purple-600"
              hrefPrefix="/person"
              libraryHref="/library/person"
              entities={persons}
              highlightIds={highlights}
              emptyHint="暂无官方推荐"
            />
          </div>
        </section>

        <section className="mt-16 grid gap-4 sm:grid-cols-3">
          {[
            { icon: Newspaper, title: "新闻抓取", desc: "自动抓取公开新闻报道", color: "text-orange-500" },
            { icon: Shield, title: "合规风控", desc: "不编造联系方式，支持认领纠错", color: "text-purple-500" },
            { icon: Layers, title: "关系图谱", desc: "人物-企业-城市-品牌互联", color: "text-fuchsia-500" },
          ].map((item) => (
            <div key={item.title} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <item.icon className={`h-6 w-6 ${item.color}`} />
              <h3 className="mt-3 font-semibold text-slate-900">{item.title}</h3>
              <p className="mt-1 text-sm text-slate-500">{item.desc}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="relative border-t border-slate-200 bg-white/60 py-6 text-center text-sm text-slate-500">
        AI城市企业人物品牌网 · 超级品牌IP网 · ip.ms1001.com
      </footer>
    </div>
  );
}
