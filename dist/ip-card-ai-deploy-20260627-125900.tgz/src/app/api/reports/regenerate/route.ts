import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { generateReportContent } from "@/lib/ai/generate-entity";
import { fetchNewsForEntity, type NewsItem } from "@/lib/news/fetcher";
import type { EntityType } from "@/lib/schemas/entity";

const Schema = z.object({
  entityId: z.string().optional(),
  slug: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { entityId, slug } = Schema.parse(body);

    const entity = await prisma.entity.findFirst({
      where: entityId ? { id: entityId } : { slug },
      include: { profile: true, newsArticles: true },
    });

    if (!entity) {
      return NextResponse.json({ error: "实体不存在" }, { status: 404 });
    }

    const news: NewsItem[] = entity.newsArticles.map((n) => ({
      title: n.title,
      url: n.url,
      source: n.source || undefined,
      excerpt: n.excerpt || undefined,
    }));

    if (!news.length) {
      const fetched = await fetchNewsForEntity(entity.name, entity.type);
      news.push(...fetched);
    }

    const report = await generateReportContent(
      entity.name,
      entity.type as EntityType,
      entity.profile?.summary || undefined,
      news,
    );

    await prisma.entityReport.create({
      data: {
        entityId: entity.id,
        reportType: "brand_18steps",
        title: report.title,
        summary: report.summary,
        contentJson: JSON.stringify({
          steps: report.steps,
          recommendations: report.recommendations,
          training_points: report.training_points,
          brand_slogan_analysis: report.brand_slogan_analysis,
          one_line_positioning: report.one_line_positioning,
        }),
        scoreJson: JSON.stringify({
          scores: report.scores,
          overall: report.overall_score,
        }),
      },
    });

    return NextResponse.json({
      success: true,
      title: report.title,
      stepsCount: report.steps?.length || 0,
      overallScore: report.overall_score,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues[0]?.message }, { status: 400 });
    }
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "报告生成失败" },
      { status: 500 },
    );
  }
}
