import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { authErrorResponse, optionalAuth, requireAdmin } from "@/lib/auth/require-auth";
import { adminListCards, adminListContent, withdrawAllEntities } from "@/lib/services/content-visibility";

export async function GET(request: NextRequest) {
  try {
    await requireAdmin(request);
    const type = request.nextUrl.searchParams.get("type") || undefined;
    const [entities, cards] = await Promise.all([
      adminListContent(type || undefined),
      adminListCards(),
    ]);
    return NextResponse.json({ entities, cards });
  } catch (error) {
    return authErrorResponse(error);
  }
}

const PatchSchema = z.object({
  kind: z.enum(["entity", "card"]),
  id: z.string(),
  visibility: z.enum(["private", "public", "admin_hidden"]).optional(),
  isFeatured: z.boolean().optional(),
});

export async function PATCH(request: NextRequest) {
  try {
    await requireAdmin(request);
    const body = PatchSchema.parse(await request.json());

    if (body.kind === "entity") {
      const updated = await prisma.entity.update({
        where: { id: body.id },
        data: {
          ...(body.visibility !== undefined ? { visibility: body.visibility } : {}),
          ...(body.isFeatured !== undefined ? { isFeatured: body.isFeatured } : {}),
        },
      });
      return NextResponse.json({ success: true, item: updated });
    }

    const updated = await prisma.card.update({
      where: { id: body.id },
      data: {
        ...(body.visibility !== undefined ? { visibility: body.visibility } : {}),
        ...(body.isFeatured !== undefined ? { isFeatured: body.isFeatured } : {}),
      },
    });
    return NextResponse.json({ success: true, item: updated });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.issues[0]?.message }, { status: 400 });
    }
    return authErrorResponse(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    await requireAdmin(request);
    const action = request.nextUrl.searchParams.get("action");
    if (action === "withdraw-all") {
      const count = await withdrawAllEntities();
      return NextResponse.json({ success: true, withdrawn: count });
    }
    return NextResponse.json({ error: "未知操作" }, { status: 400 });
  } catch (error) {
    return authErrorResponse(error);
  }
}

/** 非管理员可探测是否 ADMIN（用于 UI） */
export async function HEAD(request: NextRequest) {
  const ctx = await optionalAuth(request);
  return new NextResponse(null, {
    status: ctx?.suatUser.role === "ADMIN" ? 200 : 403,
  });
}
