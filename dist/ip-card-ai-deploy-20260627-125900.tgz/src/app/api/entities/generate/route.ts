import { NextRequest, NextResponse } from "next/server";

import { z } from "zod";

import {

  generateAndSaveEntity,

  PersonDisambiguationRequiredError,

} from "@/lib/services/entity";



const Schema = z.object({

  name: z.string().min(1),

  entityType: z.string().optional(),

  subtype: z.string().optional(),

  fetchNews: z.boolean().default(true),

  generateReport: z.boolean().default(true),

  confirmedCandidateId: z.string().optional(),

});



export async function POST(request: NextRequest) {

  try {

    const body = await request.json();

    const input = Schema.parse(body);

    const entity = await generateAndSaveEntity(input.name, {

      entityType: input.entityType,

      subtype: input.subtype,

      fetchNews: input.fetchNews,

      generateReport: input.generateReport,

      confirmedCandidateId: input.confirmedCandidateId,

    });

    return NextResponse.json({

      id: entity.id,

      slug: entity.slug,

      type: entity.type,

    });

  } catch (error) {

    if (error instanceof PersonDisambiguationRequiredError) {

      return NextResponse.json(

        {

          status: "needs_confirmation",

          name: error.personName,

          reason: error.reason,

          candidates: error.candidates,

          allowCompare: error.allowCompare,

        },

        { status: 409 },

      );

    }

    if (error instanceof z.ZodError) {

      return NextResponse.json({ error: error.issues[0]?.message }, { status: 400 });

    }

    return NextResponse.json(

      { error: error instanceof Error ? error.message : "生成失败" },

      { status: 500 },

    );

  }

}

