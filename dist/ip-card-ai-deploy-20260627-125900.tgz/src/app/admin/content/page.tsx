"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Loader2, Shield, Star, EyeOff, Eye } from "lucide-react";
import { authFetch } from "@/lib/auth/client";
import { useAuth } from "@/components/auth/AuthProvider";

export default function AdminContentPage() {
  const { user, login, loading: authLoading } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [entities, setEntities] = useState<Array<Record<string, unknown>>>([]);
  const [cards, setCards] = useState<Array<Record<string, unknown>>>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (authLoading || !user) {
      setLoading(false);
      return;
    }
    fetch("/api/admin/content", { method: "HEAD", headers: { Authorization: `Bearer ${localStorage.getItem("suat_access_token") || ""}` } })
      .then((r) => setIsAdmin(r.status === 200))
      .finally(() => setLoading(false));
  }, [user, authLoading]);

  async function load() {
    setLoading(true);
    const res = await authFetch("/api/admin/content");
    const data = await res.json();
    if (res.ok) {
      setEntities(data.entities || []);
      setCards(data.cards || []);
    } else {
      setMsg(data.error || "加载失败");
    }
    setLoading(false);
  }

  useEffect(() => {
    if (isAdmin) load();
  }, [isAdmin]);

  async function patch(kind: "entity" | "card", id: string, patch: Record<string, unknown>) {
    const res = await authFetch("/api/admin/content", {
      method: "PATCH",
      body: JSON.stringify({ kind, id, ...patch }),
    });
    if (res.ok) await load();
    else {
      const data = await res.json();
      setMsg(data.error || "操作失败");
    }
  }

  async function withdrawAll() {
    if (!confirm("确定撤回全部实体档案？它们将从公开列表消失，需重新批量生成。")) return;
    const res = await authFetch("/api/admin/content?action=withdraw-all", { method: "POST" });
    const data = await res.json();
    setMsg(data.withdrawn != null ? `已撤回 ${data.withdrawn} 条档案` : data.error);
    await load();
  }

  if (authLoading || loading) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }

  if (!user) {
    return (
      <div className="p-8 text-center">
        <button type="button" onClick={() => login()} className="rounded-xl bg-zinc-900 px-6 py-3 text-white">管理员登录</button>
      </div>
    );
  }

  if (!isAdmin) {
    return <p className="p-8 text-center text-red-600">需要 ADMIN 角色</p>;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b bg-white px-6 py-4">
        <div className="mx-auto flex max-w-5xl items-center gap-3">
          <Link href="/">← 首页</Link>
          <h1 className="flex items-center gap-2 text-lg font-bold"><Shield className="h-5 w-5" /> 内容管理</h1>
          <button type="button" onClick={withdrawAll} className="ml-auto rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs text-red-700">
            撤回全部旧档案
          </button>
        </div>
      </header>
      <main className="mx-auto max-w-5xl space-y-8 px-6 py-8">
        {msg && <p className="text-sm text-green-700">{msg}</p>}
        <section>
          <h2 className="font-semibold">实体档案 ({entities.length})</h2>
          <ul className="mt-3 space-y-2">
            {entities.map((e) => (
              <li key={String(e.id)} className="flex flex-wrap items-center gap-2 rounded-xl border bg-white p-3 text-sm">
                <span className="font-medium">{String(e.name)}</span>
                <span className="text-slate-400">{String(e.type)} · {String(e.visibility)}</span>
                {Boolean(e.isFeatured) && <Star className="h-4 w-4 text-amber-500" />}
                <div className="ml-auto flex gap-1">
                  <button type="button" onClick={() => patch("entity", String(e.id), { isFeatured: !e.isFeatured })} className="rounded border px-2 py-1 text-xs">推荐</button>
                  <button type="button" onClick={() => patch("entity", String(e.id), { visibility: "public" })} className="rounded border px-2 py-1 text-xs"><Eye className="h-3 w-3 inline" /></button>
                  <button type="button" onClick={() => patch("entity", String(e.id), { visibility: "admin_hidden" })} className="rounded border px-2 py-1 text-xs"><EyeOff className="h-3 w-3 inline" /></button>
                </div>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h2 className="font-semibold">用户名片 ({cards.length})</h2>
          <ul className="mt-3 space-y-2">
            {cards.map((c) => (
              <li key={String(c.id)} className="flex flex-wrap items-center gap-2 rounded-xl border bg-white p-3 text-sm">
                <span className="font-medium">{String(c.name)}</span>
                <span className="text-slate-400">{String(c.visibility)}</span>
                <div className="ml-auto flex gap-1">
                  <button type="button" onClick={() => patch("card", String(c.id), { isFeatured: !c.isFeatured })} className="rounded border px-2 py-1 text-xs">推荐</button>
                  <button type="button" onClick={() => patch("card", String(c.id), { visibility: "admin_hidden" })} className="rounded border px-2 py-1 text-xs">隐藏</button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
