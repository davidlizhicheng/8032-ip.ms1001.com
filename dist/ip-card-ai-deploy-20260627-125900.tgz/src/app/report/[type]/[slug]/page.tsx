import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getEntityBySlug } from "@/lib/services/entity";
import { ReportPageView } from "@/components/entity/ReportPageView";

type Props = { params: Promise<{ type: string; slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const entity = await getEntityBySlug(slug);
  if (!entity) return { title: "报告未找到" };
  const report = entity.reports[0];
  return { title: report?.title || `${entity.name} 品牌报告` };
}

export default async function ReportPage({ params }: Props) {
  const { type, slug } = await params;
  const entity = await getEntityBySlug(slug);
  if (!entity || entity.type !== type) notFound();

  const report = entity.reports[0];
  if (!report) notFound();

  return <ReportPageView data={{ entity, report }} />;
}
