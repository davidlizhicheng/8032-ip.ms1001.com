import { callAIJson, getAIClient } from "@/lib/ai/client";
import {
  CARD_THEMES,
  ParsedCardInfoSchema,
  type CardTheme,
  type ParsedCardInfo,
} from "@/lib/schemas/card";
import type { PersonCandidate } from "@/lib/search/disambiguate-person";
import {
  resolveRegistryCandidate,
  type RegistryPersonCandidate,
} from "@/lib/search/person-disambiguation-registry";
import {
  buildSelfProvidedCandidate,
  lookupPersonCandidatesFromEncyclopedia,
  resolveEncyclopediaCandidate,
} from "@/lib/search/lookup-person-encyclopedia";
import { generatePersonComparison } from "@/lib/ai/generate-person-comparison";
import { gatherPersonResearchForCard } from "@/lib/search/gather-person-research";
import { gatherFamousPersonMedia } from "@/lib/search/famous-person-media";
import type { FamousPersonMedia } from "@/lib/search/famous-person-media";
import { isIncompleteContent } from "@/lib/search/research-excerpt";
import {
  buildPersonBioSystemPrompt,
  buildPersonResearchContextBlock,
} from "@/lib/ai/person-bio-prompt";
import { generatePersonBioFromBaike } from "@/lib/ai/generate-person-bio";
import { pickPersonResearchContext } from "@/lib/search/baike-context";

const VALID_THEMES = new Set<string>(CARD_THEMES);

export type ParseCardOptions = {
  rawText: string;
  enrichFromWeb?: boolean;
  confirmedCandidateId?: string;
  confirmedIdentityHint?: string;
  compareMode?: boolean;
  compareCandidateIds?: string[];
};

export type ParseCardResponse =
  | {
      status: "success";
      data: ParsedCardInfo;
      sourcesUsed?: number;
      researchSteps?: import("@/lib/search/research-types").ResearchStep[];
      famousMedia?: FamousPersonMedia | null;
      identityHint?: string;
    }
  | {
      status: "needs_confirmation";
      name: string;
      riskLevel: "high" | "low";
      reason: string;
      candidates: PersonCandidate[];
      allowCompare?: boolean;
    }
  | {
      status: "comparison";
      name: string;
      comparison: import("@/lib/ai/generate-person-comparison").PersonComparisonResult;
    };

function asString(value: unknown, fallback = ""): string {
  if (value == null) return fallback;
  return String(value).trim();
}

function asStringArray(value: unknown): string[] {
  if (value == null) return [];
  if (Array.isArray(value)) {
    return value.map((item) => asString(item)).filter(Boolean);
  }
  if (typeof value === "string" && value.trim()) {
    return [value.trim()];
  }
  return [];
}

function asSectionArray(value: unknown): Array<{ title: string; content: string }> {
  if (value == null) return [];
  if (!Array.isArray(value)) {
    if (typeof value === "string" && value.trim()) {
      return [{ title: "经历", content: value.trim() }];
    }
    return [];
  }

  return value
    .map((item) => {
      if (typeof item === "string") {
        return { title: "经历", content: item.trim() };
      }
      if (item && typeof item === "object") {
        const row = item as Record<string, unknown>;
        return {
          title: asString(row.title || row.name, "经历"),
          content: asString(row.content || row.description || row.text),
        };
      }
      return { title: "", content: "" };
    })
    .filter((item) => item.title || item.content);
}

function asProfileSections(
  value: unknown,
): Array<{ type: string; title: string; content: string }> {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => {
      if (!item || typeof item !== "object") return null;
      const row = item as Record<string, unknown>;
      const title = asString(row.title);
      const content = asString(row.content);
      if (!title && !content) return null;
      return {
        type: asString(row.type, "story"),
        title: title || "详细介绍",
        content,
      };
    })
    .filter(Boolean) as Array<{ type: string; title: string; content: string }>;
}

function splitResearchParagraphs(text: string): string[] {
  return text
    .split(/\n{2,}/)
    .map((p) => p.replace(/\s+/g, " ").trim())
    .filter((p) => p.length > 40);
}

/** 优先从百度百科正文块提取段落 */
function splitBaikeParagraphs(context: string): string[] {
  const baikeBlocks = [...context.matchAll(/\[权威资料 \d+\][\s\S]*?正文：\s*([\s\S]*?)(?=\n\[权威资料|\n【|$)/g)];
  if (!baikeBlocks.length) return splitResearchParagraphs(context);

  const paras: string[] = [];
  for (const m of baikeBlocks) {
    const body = m[1].trim();
    if (!body.includes("百度百科") && !m[0].includes("百度百科")) continue;
    for (const p of body.split(/\n+/).map((s) => s.trim()).filter((s) => s.length > 30)) {
      paras.push(p);
    }
  }
  return paras.length ? paras : splitResearchParagraphs(context);
}

/** 取 bio 概述：按完整句子截取，禁止 mid-char 截断 */
function summarizeBio(text: string, maxLen = 200): string {
  const trimmed = text.trim();
  if (!trimmed) return "";
  if (trimmed.length <= maxLen) return trimmed;

  const sentences = trimmed.match(/[^。！？.!?]+[。！？.!?]?/g) || [trimmed];
  let result = "";
  for (const s of sentences) {
    if (result && (result + s).length > maxLen) break;
    result += s;
  }
  return result || trimmed;
}

/** AI 输出偏短或在句中被截断时补全；百科模式下禁止拼接新闻/网页摘录 */
function ensureLongContent(
  parsed: ParsedCardInfo,
  rawText: string,
  researchContext?: string,
  options?: { baikeOnly?: boolean },
): ParsedCardInfo {
  const minLong = 1000;
  let longBio = parsed.long_bio.trim();
  const baikeOnly = options?.baikeOnly === true;
  const researchParas = baikeOnly ? splitBaikeParagraphs(researchContext || "") : [];

  if (isIncompleteContent(longBio, 80)) {
    longBio = "";
  }

  if (longBio.length < minLong && baikeOnly && researchParas.length >= 4) {
    longBio = researchParas.slice(0, 10).join("\n\n");
  } else if (longBio.length < minLong && !baikeOnly) {
    const allParas = splitResearchParagraphs(researchContext || "");
    const rawParas = splitResearchParagraphs(rawText);
    if (allParas.length) longBio = allParas.slice(0, 12).join("\n\n");
    else if (rawParas.length > 1) longBio = rawParas.join("\n\n");
    else if (rawText.length > longBio.length + 100) longBio = rawText.trim();
  }

  let bio = parsed.bio.trim();
  if (isIncompleteContent(bio, 60)) {
    bio = "";
  }
  if (bio.length > 280) {
    if (!longBio.includes(bio.slice(0, 80))) {
      longBio = bio + (longBio ? `\n\n${longBio}` : "");
    }
    bio = summarizeBio(bio);
  }
  if (!bio && longBio) {
    bio = summarizeBio(longBio);
  }

  const profileSections = parsed.profile_sections.map((section) => {
    if (!isIncompleteContent(section.content, 80)) return section;
    const filled = baikeOnly
      ? researchParas[0] || ""
      : researchParas[0] || splitResearchParagraphs(rawText)[0] || "";
    return filled ? { ...section, content: filled } : section;
  });

  return ParsedCardInfoSchema.parse({ ...parsed, bio, long_bio: longBio, profile_sections: profileSections });
}

function normalizeTheme(value: unknown): CardTheme {
  const theme = asString(value);
  if (VALID_THEMES.has(theme)) return theme as CardTheme;
  return "brand_orange";
}

function extractNameFromText(rawText: string): string {
  const patterns = [
    /我叫([\u4e00-\u9fff·]{2,8})/,
    /姓名[：:]\s*([\u4e00-\u9fff·]{2,8})/,
    /^([\u4e00-\u9fff·]{2,4})/m,
  ];
  for (const p of patterns) {
    const m = rawText.match(p);
    if (m?.[1]) return m[1].trim();
  }
  return rawText.match(/[\u4e00-\u9fff·]{2,4}/)?.[0] || "未命名";
}

function normalizeParsedCardRaw(raw: unknown, rawText: string): ParsedCardInfo {
  const data = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};

  const normalized = {
    name: asString(data.name) || extractNameFromText(rawText),
    title: asString(data.title),
    company: asString(data.company),
    brand_slogan: asString(data.brand_slogan),
    bio: asString(data.bio),
    phone: asString(data.phone),
    email: asString(data.email),
    wechat: asString(data.wechat),
    address: asString(data.address),
    services: asStringArray(data.services),
    experiences: asSectionArray(data.experiences),
    honors: asSectionArray(data.honors),
    cases: asSectionArray(data.cases),
    long_bio: asString(data.long_bio),
    profile_sections: asProfileSections(data.profile_sections),
    suggested_theme: normalizeTheme(data.suggested_theme),
    missing_fields: asStringArray(data.missing_fields),
  };

  return ParsedCardInfoSchema.parse(normalized);
}

const BASE_RULES = `规则：
1. 只提取资料中明确出现的信息；联系方式（手机/邮箱/微信/地址）绝不编造，没有则留空并在 missing_fields 标注
2. brand_slogan：15-30字，有品牌感
3. bio：150-200字精炼概述
4. long_bio：800-1200字深度个人介绍，有机整合经历、理念、业务、成就，段落清晰，禁止空话套话
5. profile_sections：3-6 个模块，每模块 150-350 字，如「成长经历」「专业领域」「服务理念」「代表成果」「社会影响力」等
6. experiences / honors / cases：每项 content 至少 150 字，写具体事实
7. services：具体服务项目列表
8. 全文（long_bio + profile_sections + experiences + cases 等）总字数目标 1000-2000 字
9. suggested_theme 必须是：professional_light / brand_orange / brand_purple / education_blue / creator_bold / poster_showcase 之一（默认 brand_orange，不要用深色主题）
10. 所有数组字段必须返回，无内容时用 []
11. **严禁截断**：任何字符串字段必须写到完整句落（以。！？结尾）再结束，绝不允许在句中或词中停止输出`;

const JSON_SCHEMA = `{
  "name": "",
  "title": "",
  "company": "",
  "brand_slogan": "",
  "bio": "",
  "long_bio": "",
  "phone": "",
  "email": "",
  "wechat": "",
  "address": "",
  "services": [],
  "experiences": [{"title":"","content":""}],
  "honors": [],
  "cases": [],
  "profile_sections": [{"type":"story","title":"","content":""}],
  "suggested_theme": "brand_orange",
  "missing_fields": []
}`;

export function mockParseCardInfo(rawText: string): ParsedCardInfo {
  const phoneMatch = rawText.match(/1[3-9]\d{9}/);
  const emailMatch = rawText.match(/[\w.-]+@[\w.-]+\.\w+/);
  const name = extractNameFromText(rawText);

  return ParsedCardInfoSchema.parse({
    name,
    title: "个人品牌顾问",
    company: rawText.includes("有限公司")
      ? rawText.match(/[\u4e00-\u9fff]+有限公司/)?.[0] || ""
      : "",
    brand_slogan: "用专业影响力，连接信任与增长",
    bio: summarizeBio(rawText) || "专注于个人品牌建设与业务增长。",
    long_bio: rawText.trim() || rawText,
    phone: phoneMatch?.[0] || "",
    email: emailMatch?.[0] || "",
    wechat: "",
    address: "",
    services: ["品牌咨询", "业务介绍", "客户对接"],
    experiences: [
      {
        title: "职业经历",
        content: rawText.slice(0, 400) || "丰富的行业实践经验。",
      },
    ],
    honors: [],
    cases: [],
    profile_sections: [
      {
        type: "expertise",
        title: "专业领域",
        content: rawText.slice(0, 500) || rawText.slice(0, 500),
      },
    ],
    suggested_theme: "brand_orange",
    missing_fields: [
      ...(!phoneMatch ? ["phone"] : []),
      ...(!emailMatch ? ["email"] : []),
      "wechat",
      "address",
    ],
  });
}

async function runAIParse(
  rawText: string,
  researchContext?: string,
  identityHint?: string,
  baikeOnly = false,
): Promise<ParsedCardInfo> {
  const webBlock = buildPersonResearchContextBlock(researchContext || "");
  const identityBlock = identityHint
    ? `\n\n用户已确认目标人物身份：${identityHint}`
    : "";

  const parsed = await callAIJson<unknown>(
    buildPersonBioSystemPrompt("card"),
    `请解析并深度扩写以下个人资料，生成 1000-2000 字的有机整合内容：\n\n${rawText}${webBlock}${identityBlock}

${BASE_RULES}

返回 JSON 格式：
${JSON_SCHEMA}`,
  );

  return ensureLongContent(
    normalizeParsedCardRaw(parsed, rawText),
    rawText,
    researchContext,
    { baikeOnly },
  );
}

async function runPersonEncyclopediaParse(
  name: string,
  rawText: string,
  baikeContext: string,
  identityHint?: string,
): Promise<ParsedCardInfo> {
  let parsed = await generatePersonBioFromBaike(name, baikeContext, rawText, identityHint);
  let normalized = normalizeParsedCardRaw(parsed, rawText);

  if (normalized.long_bio.trim().length < 900) {
    parsed = await generatePersonBioFromBaike(
      name,
      baikeContext,
      rawText,
      `${identityHint || ""}（请务必写满 long_bio 1000 字以上，只写已确认身份的人物，禁止无关内容）`.trim(),
    );
    normalized = normalizeParsedCardRaw(parsed, rawText);
  }

  return ensureLongContent(normalized, rawText, baikeContext, { baikeOnly: true });
}

export async function parseCardInfo(rawText: string): Promise<ParsedCardInfo> {
  const result = await parseCardWithOptions({ rawText });
  if (result.status === "needs_confirmation" || result.status === "comparison") {
    return mockParseCardInfo(rawText);
  }
  return result.data;
}

async function resolveCompareCandidate(
  name: string,
  candidateId: string,
  fallback?: PersonCandidate,
): Promise<RegistryPersonCandidate | null> {
  const registry = resolveRegistryCandidate(name, candidateId);
  if (registry) return registry;

  const resolved = await resolveEncyclopediaCandidate(name, candidateId);
  if (resolved.registryCandidate) return resolved.registryCandidate;

  const label = fallback?.label || name;
  const snippet = resolved.entry?.snippet || fallback?.snippet || label;
  return {
    id: candidateId,
    label,
    region: fallback?.region || "",
    title: fallback?.title,
    company: fallback?.company,
    snippet,
    identityHint: resolved.identityHint || label,
    searchQueries: [name, `${name} ${resolved.identityHint}`].filter(Boolean),
    excludeKeywords: [],
  };
}

export async function parseCardWithOptions(
  options: ParseCardOptions,
): Promise<ParseCardResponse> {
  const {
    rawText,
    enrichFromWeb,
    confirmedCandidateId,
    confirmedIdentityHint,
    compareMode,
    compareCandidateIds,
  } = options;
  const client = getAIClient();

  if (!client) {
    return { status: "success", data: mockParseCardInfo(rawText) };
  }

  const name = extractNameFromText(rawText);

  if (enrichFromWeb && compareMode) {
    const ids = compareCandidateIds?.filter(Boolean).slice(0, 2);
    if (ids?.length === 2) {
      const lookup = await lookupPersonCandidatesFromEncyclopedia(name);
      const picked = (
        await Promise.all(
          ids.map((id) => {
            const fallback = lookup.candidates.find((c) => c.id === id);
            return resolveCompareCandidate(name, id, fallback);
          }),
        )
      ).filter(Boolean) as RegistryPersonCandidate[];
      if (picked.length === 2) {
        try {
          const comparison = await generatePersonComparison(name, picked);
          return { status: "comparison", name, comparison };
        } catch (error) {
          console.error("[parse-card] comparison failed:", error);
        }
      }
    }
  }

  let researchContext = "";
  let baikeContext = "";
  let sourcesUsed = 0;
  let researchSteps: import("@/lib/search/research-types").ResearchStep[] = [];
  let identityHint = confirmedIdentityHint || "";
  let famousMedia: FamousPersonMedia | null = null;
  let researchBundle: import("@/lib/search/research-types").ResearchBundle | null = null;
  let registryCandidate: RegistryPersonCandidate | null = null;
  let confirmedBaikeUrl: string | undefined;
  let confirmedWikiUrl: string | undefined;

  if (enrichFromWeb && !confirmedCandidateId && !confirmedIdentityHint) {
    const lookup = await lookupPersonCandidatesFromEncyclopedia(name);
    return {
      status: "needs_confirmation",
      name,
      riskLevel: "high",
      reason: lookup.reason,
      candidates:
        lookup.candidates.length > 0
          ? lookup.candidates
          : [buildSelfProvidedCandidate(name, rawText)],
      allowCompare: lookup.allowCompare,
    };
  }

  if (enrichFromWeb) {
    try {
      if (confirmedCandidateId) {
        const resolved = await resolveEncyclopediaCandidate(name, confirmedCandidateId);
        identityHint = resolved.identityHint || confirmedIdentityHint || identityHint;
        registryCandidate = resolved.registryCandidate || resolveRegistryCandidate(name, confirmedCandidateId);
        confirmedBaikeUrl = resolved.baikeUrl;
        confirmedWikiUrl = resolved.wikiUrl;
      } else if (confirmedIdentityHint) {
        identityHint = confirmedIdentityHint;
      }

      const research = await gatherPersonResearchForCard(name, {
        candidate: registryCandidate,
        identityHint,
        confirmedBaikeUrl,
        confirmedWikiUrl,
      });
      researchContext = research.contextText;
      baikeContext = pickPersonResearchContext({
        baikeEntries: research.baikeEntries,
        wiki: research.wiki,
        contextText: research.contextText,
      });
      sourcesUsed = research.sourceCount;
      researchSteps = research.steps;
      researchBundle = {
        news: [],
        webResults: research.webResults,
        baikeEntries: research.baikeEntries,
        wiki: research.wiki,
        pageExcerpts: [],
        contextText: research.contextText,
        sourceCount: research.sourceCount,
        steps: research.steps,
      };

      famousMedia = await gatherFamousPersonMedia(name, researchBundle);
    } catch (error) {
      console.warn("[parse-card] web research failed:", error);
    }
  }

  try {
    const useEncyclopedia = enrichFromWeb && (baikeContext.trim().length >= 150 || Boolean(registryCandidate));
    const data = useEncyclopedia
      ? await runPersonEncyclopediaParse(name, rawText, baikeContext || researchContext, identityHint)
      : await runAIParse(rawText, baikeContext || researchContext, identityHint, useEncyclopedia);
    return { status: "success", data, sourcesUsed, researchSteps, famousMedia, identityHint };
  } catch (error) {
    console.error("AI parse card fallback:", error);
    return { status: "success", data: mockParseCardInfo(rawText) };
  }
}
