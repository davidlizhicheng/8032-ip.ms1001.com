/**
 * 品牌复盘18步 — 参考「了不起研究院 / 深圳市品牌学会」
 * 《品牌复盘决胜终端》系列（胖东来、瑞幸、雅兰、追觅等案例）
 */

export const BRAND_REVIEW_PHASES = [
  {
    id: "research",
    title: "阶段一：深度调研",
    steps: "Steps 1-4",
    subtitle: "知己知彼，奠定根基",
    stepRange: [1, 4] as const,
  },
  {
    id: "strategy",
    title: "阶段二：精准定盘",
    steps: "Steps 5-11",
    subtitle: "顶层设计，明确方向",
    stepRange: [5, 11] as const,
  },
  {
    id: "execution",
    title: "阶段三：闭环落地",
    steps: "Steps 12-18",
    subtitle: "全链路运营，实现增长",
    stepRange: [12, 18] as const,
  },
] as const;

export const BRAND_REVIEW_18_STEPS = [
  {
    step: 1,
    key: "consumer_research",
    title: "消费者研究",
    subtitle: "洞察未被满足的需求",
    phase: "research",
    hint: "读懂用户，才能赢得市场。洞察核心需求、痛点与渴望，回答「为谁服务」「他们真正需要什么价值」",
    theory: ["消费者需求层次理论（马斯洛）", "消费者行为理论（科特勒）"],
  },
  {
    step: 2,
    key: "competitor_research",
    title: "竞争对手研究",
    subtitle: "寻找市场空隙",
    phase: "research",
    hint: "分析竞品做了什么、没做什么、弱点在哪，锁定差异化竞争优势，避免同质化价格战",
    theory: ["波特五力模型", "SWOT分析模型"],
  },
  {
    step: 3,
    key: "market_environment",
    title: "市场环境研究",
    subtitle: "把握趋势机会",
    phase: "research",
    hint: "PEST分析宏观环境，识别核心趋势与风险，将趋势转化为品牌策略",
    theory: ["PEST分析模型", "市场趋势理论（科特勒）"],
  },
  {
    step: 4,
    key: "brand_self_research",
    title: "品牌自身研究",
    subtitle: "挖掘核心能力",
    phase: "research",
    hint: "梳理核心竞争力与价值链，区分核心能力与普通优势，强化难以模仿的壁垒",
    theory: ["核心竞争力理论（哈默尔&普拉哈拉德）", "价值链理论（波特）"],
  },
  {
    step: 5,
    key: "strategic_planning",
    title: "品牌战略规划",
    subtitle: "明确发展方向",
    phase: "strategy",
    hint: "制定长期/中期/短期目标与发展路径，SMART原则，统筹资源落地",
    theory: ["战略管理理论（明茨伯格）", "SMART目标管理（德鲁克）", "安索夫矩阵"],
  },
  {
    step: 6,
    key: "core_value",
    title: "品牌核心价值提炼",
    subtitle: "打造品牌DNA",
    phase: "strategy",
    hint: "提炼功能价值、情感价值、精神价值，形成品牌基因，贯穿全流程",
    theory: ["品牌核心价值理论（戴维·阿克）", "品牌DNA理论（马克·戈贝）"],
  },
  {
    step: 7,
    key: "positioning",
    title: "品牌定位",
    subtitle: "占据心智位置",
    phase: "strategy",
    hint: "在消费者心智中占据独特清晰的位置，实现差异化认知",
    theory: ["定位理论（里斯&特劳特）", "心智阶梯理论"],
  },
  {
    step: 8,
    key: "naming",
    title: "品牌命名",
    subtitle: "创造独特识别符号",
    phase: "strategy",
    hint: "易记、独特、契合定位、可扩展，成为品牌核心识别符号",
    theory: ["品牌命名理论（戴维·阿克）", "品牌识别理论（凯勒）"],
  },
  {
    step: 9,
    key: "slogan",
    title: "品牌主张与口号",
    subtitle: "提炼沟通核心",
    phase: "strategy",
    hint: "简洁有感染力的口号，传递核心价值，引发情感共鸣，可落地",
    theory: ["品牌沟通理论（凯勒）", "品牌口号理论（戴维·阿克）"],
  },
  {
    step: 10,
    key: "personality",
    title: "品牌个性塑造",
    subtitle: "赋予品牌人格",
    phase: "strategy",
    hint: "真诚/刺激/胜任/精致等维度，让品牌有温度、可共鸣",
    theory: ["品牌个性理论（珍妮弗·阿克）", "品牌人格化理论"],
  },
  {
    step: 11,
    key: "visual_design",
    title: "品牌设计",
    subtitle: "视觉化呈现",
    phase: "strategy",
    hint: "VI体系统一：标志、色彩、字体、包装、门店，传递品牌内涵",
    theory: ["品牌视觉识别理论（凯勒）", "VI理论（保罗·兰德）"],
  },
  {
    step: 12,
    key: "communication",
    title: "品牌传播",
    subtitle: "整合营销沟通",
    phase: "execution",
    hint: "全渠道整合传播，统一品牌声音与形象，品效合一",
    theory: ["整合营销传播IMC（唐·舒尔茨）", "品牌触达理论（凯勒）"],
  },
  {
    step: 13,
    key: "marketing",
    title: "品牌营销",
    subtitle: "价值转化为销售",
    phase: "execution",
    hint: "4P营销组合：产品、价格、渠道、促销，实现终端转化",
    theory: ["4P营销理论（麦卡锡）", "品效合一模型"],
  },
  {
    step: 14,
    key: "events",
    title: "品牌活动策划",
    subtitle: "制造传播爆点",
    phase: "execution",
    hint: "节点营销、跨界联名、话题事件，引爆品牌声量",
    theory: ["事件营销理论", "话题传播模型"],
  },
  {
    step: 15,
    key: "pr",
    title: "品牌公关",
    subtitle: "管理品牌声誉",
    phase: "execution",
    hint: "危机公关、媒体关系、口碑管理，维护品牌信任",
    theory: ["公关理论（格鲁尼格）", "声誉管理理论"],
  },
  {
    step: 16,
    key: "service_experience",
    title: "品牌服务体验管理",
    subtitle: "决胜终端",
    phase: "execution",
    hint: "全触点体验设计，从售前到售后，打造极致服务",
    theory: ["服务营销理论", "客户体验管理（CEM）"],
  },
  {
    step: 17,
    key: "asset_management",
    title: "品牌资产管理与维护",
    subtitle: "沉淀品牌资产",
    phase: "execution",
    hint: "品牌知名度、美誉度、忠诚度管理，量化品牌资产",
    theory: ["品牌资产模型（凯勒）", "品牌权益理论（戴维·阿克）"],
  },
  {
    step: 18,
    key: "continuous_upgrade",
    title: "持续的品牌升级",
    subtitle: "保持品牌活力",
    phase: "execution",
    hint: "定期复盘迭代，顺应趋势，从个人驱动到制度驱动",
    theory: ["品牌生命周期理论", "持续创新理论"],
  },
] as const;

/** 每一步复盘的五段式结构（参照胖东来/瑞幸复盘文档） */
export const STEP_SECTION_KEYS = [
  { key: "theory_tools", label: "一、理论工具" },
  { key: "method_models", label: "二、方法模型" },
  { key: "brand_practice", label: "三、品牌实践" },
  { key: "brand_case", label: "四、品牌案例" },
  { key: "summary_lessons", label: "五、品牌总结与借鉴" },
] as const;

export const BRAND_SCORE_DIMENSIONS = [
  "消费者洞察力",
  "竞争差异化",
  "趋势把握力",
  "核心能力",
  "战略清晰度",
  "品牌价值力",
  "心智定位力",
  "传播整合力",
  "终端转化力",
  "品牌资产力",
] as const;

export const BRAND_REPORT_SYSTEM_PROMPT = `你是资深品牌战略顾问，擅长撰写「品牌复盘18步 · 决胜终端」风格的企业品牌成长复盘报告。
参考了不起研究院/深圳市品牌学会《品牌复盘决胜终端》系列（胖东来、瑞幸咖啡、雅兰、追觅、胖东来等案例）。

报告必须严格按18步结构输出，每一步包含五段式内容：
一、理论工具 — 引用经典品牌理论
二、方法模型 — 可落地的方法论/模型
三、品牌实践 — 该品牌在此步骤的具体做法
四、品牌案例 — 具体案例细节与数据（无数据则写「公开资料未披露」）
五、品牌总结与借鉴 — 总结+对其他品牌的启示

18步清单：
${BRAND_REVIEW_18_STEPS.map((s) => `第${s.step}步：${s.title}——${s.subtitle}`).join("\n")}

评分维度（0-10分）：${BRAND_SCORE_DIMENSIONS.join("、")}

合规：基于公开资料；不编造数据/联系方式；竞品分析客观；返回合法JSON`;

export const BRAND_REPORT_JSON_SCHEMA = `{
  "title": "品牌复盘 决胜终端——{品牌名}品牌成长的18个关键步骤复盘",
  "summary": "300字执行摘要，概述品牌成长路径与核心成功逻辑",
  "one_line_positioning": "一句话品牌定位",
  "brand_slogan_analysis": "品牌口号解读",
  "scores": { "消费者洞察力": 8 },
  "overall_score": 7.8,
  "steps": [
    {
      "step": 1,
      "title": "消费者研究",
      "subtitle": "洞察未被满足的需求",
      "theory_tools": "理论工具内容150-200字",
      "method_models": "方法模型内容150-200字",
      "brand_practice": "品牌实践内容200-300字",
      "brand_case": "品牌案例内容200-300字，含具体细节",
      "summary_lessons": "总结与借鉴100-150字"
    }
  ],
  "recommendations": ["改进建议1", "改进建议2", "改进建议3"],
  "training_points": ["学习要点1", "学习要点2", "学习要点3"]
}`;

export function getPhaseForStep(stepNum: number) {
  return BRAND_REVIEW_PHASES.find(
    (p) => stepNum >= p.stepRange[0] && stepNum <= p.stepRange[1],
  );
}
