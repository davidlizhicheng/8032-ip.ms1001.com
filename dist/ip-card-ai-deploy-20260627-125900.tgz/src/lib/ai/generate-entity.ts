import {
  GeneratedEntitySchema,
  GeneratedReportSchema,
  type GeneratedEntity,
  type GeneratedReport,
  type ReportStep,
  type EntityType,
  PERSON_SUBTYPE_LABELS,
} from "@/lib/schemas/entity";
import { callAIJson } from "@/lib/ai/client";
import { entitySlug } from "@/lib/ai/detect-type";
import { getDefaultEntityTheme } from "@/lib/themes";
import {
  BRAND_REPORT_SYSTEM_PROMPT,
  BRAND_SCORE_DIMENSIONS,
  BRAND_REVIEW_18_STEPS,
} from "@/lib/ai/brand-report-template";
import type { NewsItem } from "@/lib/news/fetcher";
import type { SearchResult } from "@/lib/search/web-search";
import {
  excerptForSlot,
  fillReportStepFromResearch,
  fillSectionFromResearch,
  isIncompleteContent,
  isPlaceholderContent,
  splitResearchParagraphs,
} from "@/lib/search/research-excerpt";
import { sanitizeSections, sanitizeText } from "@/lib/content/sanitize-placeholder";
import {
  buildPersonBioSystemPrompt,
  buildPersonResearchContextBlock,
  PERSON_BIO_SOURCE_RULES,
} from "@/lib/ai/person-bio-prompt";

function buildResearchContext(
  news?: NewsItem[],
  researchContext?: string,
  options?: { baikeOnly?: boolean },
): string {
  if (researchContext?.trim()) {
    return buildPersonResearchContextBlock(researchContext);
  }

  if (options?.baikeOnly) return "";

  if (news?.length) {
    return `\n\n公开新闻报道摘要（仅作补充，不得替代百科正文）：\n${news.map((n) => `- ${n.title} (${n.source || "新闻"})`).join("\n")}`;
  }

  return "";
}

function mergeSources(
  news?: NewsItem[],
  webResults?: SearchResult[],
  aiSources?: GeneratedEntity["sources"],
): GeneratedEntity["sources"] {
  const fromNews =
    news?.map((n) => ({
      title: n.title,
      url: n.url,
      source_type: "news" as const,
      excerpt: n.excerpt,
      confidence_score: 0.75,
    })) || [];

  const fromWeb =
    webResults?.map((item) => ({
      title: item.title,
      url: item.url,
      source_type: (item.url.includes("baike.baidu.com") ? "wiki" : "web") as "wiki" | "web",
      excerpt: item.snippet,
      confidence_score: item.url.includes("baike.baidu.com") ? 0.95 : 0.8,
    })) || [];

  const merged = [...fromWeb, ...fromNews, ...(aiSources || [])];
  const seen = new Set<string>();

  const deduped = merged.filter((item) => {
    const key = (item.url || "").split("?")[0] || item.title.replace(/\s*[-_].*百度百科.*$/i, "").trim();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return deduped.slice(0, 8);
}

const QUALITY_RULES = `
内容质量规则（必须严格遵守）：
1. 严禁空话套话与占位语。禁止出现："待补充""资料不足""公开资料未明确提及""历史文化与现代都市风貌交融""集聚众多行业龙头"等
2. 人物档案 sections 合计 2000-4000 字；城市/企业 1000-2000 字；summary 250-400 字；每节 content 200-500 字，含可核对事实
3. 检索资料中有百度百科/维基百科/政府官网内容时，必须大段原文摘录关键段落，句末标注（据百度百科）或（据维基百科）
4. 找不到某维度资料时，从检索正文其他相关段落改写填充；**禁止**写占位句
5. 城市差异化：深圳勿写千年古城；每座城市写真实企业名、数据、政策、地标
6. 代表企业、高校、职务、公司名、年份、数据必须写真实名称
7. **严禁截断**：任何 content/summary 字段必须写到完整句落（。！？）再结束，绝不允许在句中或词中停止，不要自我压缩篇幅
${PERSON_BIO_SOURCE_RULES}`;

const BASE_RULES = `
合规规则（必须遵守）：
1. 绝不编造手机号、微信号、私人邮箱、家庭住址、身份证号
2. 只基于提供的公开资料和新闻摘要整理，优先采用百度百科等权威来源
3. 官员类不做商业背书、不做财富分析
4. 律师类不写"包赢""最强""百分百胜诉"
5. 未成年人不展示联系方式
6. 返回合法 JSON，不要 markdown
${QUALITY_RULES}`;

const CITY_SECTION_TITLES = [
  "城市定位",
  "产业优势",
  "代表企业",
  "高校与科研资源",
  "文旅资源",
  "营商环境",
  "城市品牌口号",
  "招商合作方向",
] as const;

const PERSON_SECTION_TITLES = [
  "个人简介",
  "早年经历",
  "职业生涯",
  "企业身份与职务",
  "创业历程",
  "商业成就",
  "关联企业与品牌",
  "行业影响力",
  "社会职务与荣誉",
  "公开报道摘录",
] as const;

const TYPE_PROMPTS: Record<EntityType, string> = {
  city: `生成中国城市品牌宣传档案。sections 必须恰好 8 节：城市定位、产业优势、代表企业、高校与科研资源、文旅资源、营商环境、城市品牌口号、招商合作方向。
全文 1000-2000 字。必须以百度百科/政府官网正文为骨架，按模块**用 AI 重新撰写**百科词条式内容；每节内容互不重复，禁止把同一段市情介绍复制到多个模块。禁止「待抓取」「待补充」等占位语。`,
  company: `生成中国企业品牌档案。sections 必须包含：企业简介、品牌定位、核心产品、创始人与高管、商业模式、增长路径、品牌优势、竞品分析、风险与挑战、合作方向。必须写真实产品名、创始人姓名、成立年份、总部城市、具体竞品公司名。`,
  person: `生成人物公开资料档案。sections 必须恰好 10 节：个人简介、早年经历、职业生涯、企业身份与职务、创业历程、商业成就、关联企业与品牌、行业影响力、社会职务与荣誉、公开报道摘录。
全文 2000-4000 字。必须以百度百科全文为骨架，前 9 节大段摘录/改写百科原文；第 10 节仅 1-2 条权威报道标题级摘要。禁止用财经快讯、身家涨跌、门户聚合页拼凑正文。必须写真实职务、公司名、年份、可查证的公开经历。必须生成 relations 关联企业和城市。`,
  brand: `生成品牌档案。sections 包含：品牌故事、品牌定位、核心产品、目标用户、传播记忆点、代表案例、竞品对比。必须写真实产品、价格带、竞品品牌名。`,
  profession: `生成职业群体介绍页。sections 包含：职业概述、核心能力、服务场景、行业价值、代表人物类型、合作方式。`,
};

function buildFallbackSections(
  name: string,
  type: EntityType,
  researchContext?: string,
): Array<{ type: string; title: string; content: string }> {
  const paragraphs = splitResearchParagraphs(researchContext || "");
  if (!paragraphs.length) {
    return [{
      type: "overview",
      title: `${name}概况`,
      content: `${name}公开品牌档案。`,
    }];
  }

  const titles: Record<EntityType, string[]> = {
    city: [...CITY_SECTION_TITLES],
    company: ["企业简介", "产品与业务", "发展历程", "公开资料摘录"],
    person: [...PERSON_SECTION_TITLES],
    brand: ["品牌概述", "产品线", "公开资料摘录"],
    profession: ["职业概述", "服务场景", "公开资料摘录"],
  };

  const sectionTitles = titles[type] || titles.city;
  return sanitizeSections(
    sectionTitles.map((title, i) => ({
      type: `section_${i}`,
      title,
      content:
        sanitizeText(fillSectionFromResearch(researchContext, title, i)) ||
        paragraphs[i % paragraphs.length],
    })),
  );
}

function normalizeSectionKey(title: string): string {
  return title.replace(/\s/g, "").replace(/与/g, "");
}

function ensureEntitySections(
  type: EntityType,
  sections: Array<{ type: string; title: string; content: string }>,
  researchContext?: string,
): Array<{ type: string; title: string; content: string }> {
  const required =
    type === "city"
      ? CITY_SECTION_TITLES.map((title) => ({ title, type: title }))
      : type === "person"
        ? PERSON_SECTION_TITLES.map((title) => ({ title, type: title }))
        : null;

  if (!required) return sections;

  const byKey = new Map<string, { type: string; title: string; content: string }>();
  for (const s of sections) {
    byKey.set(normalizeSectionKey(s.title), s);
  }

  return required.map(({ title, type: sectionType }, index) => {
    const existing =
      byKey.get(normalizeSectionKey(title)) ||
      [...byKey.values()].find((s) => normalizeSectionKey(s.title).includes(normalizeSectionKey(title).slice(0, 2)));

    let content = existing?.content?.trim() && !isPlaceholderContent(existing.content) && !isIncompleteContent(existing.content, 120)
      ? existing.content
      : fillSectionFromResearch(researchContext, title, index);

    if (!content || isPlaceholderContent(content) || isIncompleteContent(content, 120)) {
      content = excerptForSlot(researchContext || "", title, index, type === "person" ? 400 : 250);
    }

    return { type: sectionType, title, content: sanitizeText(content) };
  }).filter((s) => s.content.length >= 30);
}

function mockEntity(
  name: string,
  type: EntityType,
  subtype?: string,
  news?: NewsItem[],
  webResults?: SearchResult[],
  researchContext?: string,
): GeneratedEntity {
  const slug = entitySlug(name);
  const fallbackSections = buildFallbackSections(name, type, researchContext);
  const summaryExcerpt = excerptForSlot(researchContext || "", "概述", 0, 250);

  const templates: Record<EntityType, Partial<GeneratedEntity>> = {
    city: {
      title: `${name}城市品牌`,
      slogan: summaryExcerpt.slice(0, 80) || `${name}城市品牌`,
      summary: summaryExcerpt || fallbackSections[0]?.content?.slice(0, 300) || `${name}城市品牌档案。`,
      sections: fallbackSections,
      tags: ["城市品牌"],
      keywords: [name, "城市"],
    },
    company: {
      title: name,
      slogan: summaryExcerpt.slice(0, 80) || name,
      summary: summaryExcerpt || `${name}企业档案，来自公开检索资料。`,
      sections: fallbackSections,
      tags: ["企业品牌"],
      keywords: [name],
    },
    person: {
      title: name,
      subtitle: subtype ? PERSON_SUBTYPE_LABELS[subtype] : "企业家",
      slogan: summaryExcerpt.slice(0, 80) || name,
      summary: summaryExcerpt || `${name}公开资料，来自检索整理。`,
      sections: fallbackSections,
      tags: ["人物IP", subtype || "entrepreneur"],
      keywords: [name],
    },
    brand: {
      title: name,
      slogan: name,
      summary: summaryExcerpt || `${name}品牌档案。`,
      sections: fallbackSections,
      tags: ["品牌"],
      keywords: [name],
    },
    profession: {
      title: `${name}职业群体`,
      slogan: name,
      summary: summaryExcerpt || `${name}职业介绍。`,
      sections: fallbackSections,
      tags: ["职业"],
      keywords: [name],
    },
  };

  const t = templates[type];
  return GeneratedEntitySchema.parse({
    slug,
    name,
    type,
    subtype,
    title: t.title || name,
    subtitle: t.subtitle,
    slogan: t.slogan || "",
    summary: t.summary || "",
    sections: t.sections || [],
    tags: t.tags || [],
    keywords: t.keywords || [],
    seo_title: `${name} - AI${type === "city" ? "城市品牌" : type === "company" ? "企业品牌" : "人物"}档案`,
    seo_description: (t.summary || "").slice(0, 150),
    theme: getDefaultEntityTheme(type, slug, name),
    relations: t.relations,
    sources: mergeSources(news, webResults, news?.map((n) => ({
      title: n.title,
      url: n.url,
      source_type: "news",
      excerpt: n.excerpt,
      confidence_score: 0.7,
    }))),
  });
}

function mockReport(name: string, type: EntityType): GeneratedReport {
  const scores: Record<string, number> = {};
  BRAND_SCORE_DIMENSIONS.forEach((dim, i) => {
    scores[dim] = 6 + (i % 4);
  });

  const overall = Math.round(
    Object.values(scores).reduce((a, b) => a + b, 0) / Object.values(scores).length * 10,
  ) / 10;

  const steps = BRAND_REVIEW_18_STEPS.map((s) => ({
    step: s.step,
    title: s.title,
    subtitle: s.subtitle,
    theory_tools: `运用${s.theory.join("、")}等理论工具，分析${name}在「${s.title}」环节的战略选择与底层逻辑。${s.hint}`,
    method_models: `采用结构化复盘模型，从${s.hint.slice(0, 40)}…等维度进行系统拆解，形成可落地的方法论框架。`,
    brand_practice: `${name}在${s.title}方面的实践体现了其对${s.subtitle}的深度理解，将理论转化为可执行的品牌战略动作，贯穿产品、传播与终端体验。`,
    brand_case: `以${name}为例：在${s.title}环节，${name}通过差异化策略在市场中建立独特认知。具体做法包括聚焦核心客群、强化品牌记忆点、优化终端体验等（公开资料整理）。`,
    summary_lessons: `总结：${name}在${s.title}上的成功，核心在于将「${s.subtitle}」落到实处。借鉴：其他品牌应重视第${s.step}步，避免跳过基础调研直接做传播。`,
  }));

  return GeneratedReportSchema.parse({
    title: `品牌复盘 决胜终端——${name}品牌成长的18个关键步骤复盘`,
    summary: `本文围绕品牌复盘18步模型，以${name}为核心案例，结合专业理论与实战经验，全面复盘其品牌成长路径，拆解决胜终端的核心逻辑，为其他品牌提供可落地、可借鉴的实践指南。`,
    one_line_positioning: `${name}：在${type === "company" ? "行业" : "领域"}中建立差异化品牌认知`,
    brand_slogan_analysis: "品牌口号传递了核心价值主张，具备传播记忆点，可进一步强化场景化与用户共鸣。",
    scores,
    overall_score: overall,
    steps,
    recommendations: [
      "按18步模型系统复盘，不跳过深度调研阶段",
      "聚焦一句话定位，贯穿传播与终端",
      "强化品牌服务体验，决胜终端转化",
      "建立品牌资产量化与持续升级机制",
    ],
    training_points: [
      "学习18步模型三阶段：深度调研→精准定盘→闭环落地",
      `拆解${name}在消费者研究与竞品分析上的差异化做法`,
      "分析其品牌定位、口号与视觉如何形成统一识别",
      "研究其传播、营销与终端体验如何协同转化",
    ],
  });
}

const ENTITY_JSON_SCHEMA = `{
  "slug": "英文slug",
  "name": "名称",
  "type": "city|company|person|brand|profession",
  "subtype": "",
  "title": "标题",
  "subtitle": "副标题",
  "slogan": "一句话定位",
  "summary": "摘要250-400字",
  "sections": [{"type":"","title":"","content":""}],
  "tags": [],
  "keywords": [],
  "seo_title": "",
  "seo_description": "",
  "theme": "business_gold_dark",
  "relations": [{"target_name":"","target_type":"city|company|person|brand","relation_type":"","label":""}],
  "sources": [{"title":"","url":"","source_type":"news|wiki|official|web","excerpt":"","confidence_score":0.7}]
}`;

const ENTITY_META_SCHEMA = `{
  "slug": "英文slug",
  "name": "名称",
  "subtype": "",
  "title": "标题",
  "subtitle": "副标题",
  "slogan": "一句话定位",
  "summary": "摘要250-400字，必须完整句落",
  "tags": [],
  "keywords": [],
  "seo_title": "",
  "seo_description": "",
  "theme": "business_gold_dark",
  "relations": [{"target_name":"","target_type":"city|company|person|brand","relation_type":"","label":""}],
  "sources": [{"title":"","url":"","source_type":"news|wiki|official|web","excerpt":"","confidence_score":0.7}]
}`;

const ENTITY_SECTIONS_SCHEMA = `{
  "sections": [{"type":"","title":"","content":"200-500字完整段落"}]
}`;

async function generatePersonSectionsBatched(
  name: string,
  newsContext: string,
): Promise<Array<{ type: string; title: string; content: string }>> {
  const batches: Array<(typeof PERSON_SECTION_TITLES)[number][]> = [
    [...PERSON_SECTION_TITLES.slice(0, 5)],
    [...PERSON_SECTION_TITLES.slice(5, 10)],
  ];

  const chunks = await Promise.all(
    batches.map((titles) =>
      callAIJson<{ sections?: Array<{ type: string; title: string; content: string }> }>(
        `${buildPersonBioSystemPrompt("entity")}
${BASE_RULES}
只返回 JSON，格式：${ENTITY_SECTIONS_SCHEMA}`,
        `为「${name}」生成以下 ${titles.length} 个章节（title 必须与下列标题完全一致，每节 content 200-500 字，写到完整句落，严禁截断）：\n${titles.map((t, i) => `${i + 1}. ${t}`).join("\n")}${newsContext}`,
      ),
    ),
  );

  return chunks.flatMap((chunk) => chunk.sections || []);
}

function parseGeneratedEntity(
  ai: Partial<GeneratedEntity> & { sections?: Array<{ type: string; title: string; content: string }> },
  name: string,
  type: EntityType,
  subtype: string | undefined,
  news?: NewsItem[],
  researchContext?: string,
  webResults?: SearchResult[],
): GeneratedEntity {
  const rawSections = (ai.sections || []).map((s) => ({
    ...s,
    content: sanitizeText(s.content),
  }));

  let summary = sanitizeText(ai.summary) || excerptForSlot(researchContext || "", "概述", 0, 280);
  if (isIncompleteContent(summary, 150)) {
    summary = excerptForSlot(researchContext || "", "概述", 0, 300);
  }

  return GeneratedEntitySchema.parse({
    ...ai,
    name,
    type,
    slug: ai.slug || entitySlug(name),
    tags: ai.tags || [],
    keywords: ai.keywords || [],
    seo_title: ai.seo_title || `${name} - AI${type === "city" ? "城市品牌" : type === "company" ? "企业品牌" : "人物"}档案`,
    seo_description: ai.seo_description || (summary || "").slice(0, 150),
    theme: ai.theme || getDefaultEntityTheme(type, ai.slug || entitySlug(name), name),
    summary,
    sections: (() => {
      const secs = sanitizeSections(ensureEntitySections(type, rawSections, researchContext));
      if (secs.length > 0) return secs;
      const fallback = excerptForSlot(researchContext || "", name, 0, 500);
      return fallback
        ? [{ type: "overview", title: `${name}公开资料`, content: fallback }]
        : [];
    })(),
    relations: ai.relations || [],
    sources: mergeSources(news, webResults, ai.sources),
  });
}

export async function generateEntityContent(
  name: string,
  type: EntityType,
  subtype?: string,
  news?: NewsItem[],
  researchContext?: string,
  webResults?: SearchResult[],
  options?: { baikeOnly?: boolean; identityHint?: string },
): Promise<GeneratedEntity> {
  const baikeOnly = options?.baikeOnly === true;
  const identityHint = options?.identityHint || "";
  const identityBlock = identityHint ? `\n\n已确认人物身份（严禁写入其他同名者或无关内容）：${identityHint}` : "";
  const newsContext = buildResearchContext(baikeOnly ? [] : news, researchContext, { baikeOnly }) + identityBlock;

  try {
    if (type === "person") {
      const meta = await callAIJson<Partial<GeneratedEntity>>(
        `${buildPersonBioSystemPrompt("entity")}
生成人物档案的元信息（不含 sections，sections 另批生成）。
${BASE_RULES}
只返回 JSON，格式：${ENTITY_META_SCHEMA}`,
        `请为以下人物生成档案元信息：\n名称：${name}\n子类型：${subtype || "无"}${newsContext}`,
      );
      const sections = await generatePersonSectionsBatched(name, newsContext);
      return parseGeneratedEntity(
        { ...meta, sections, type, name },
        name,
        type,
        subtype,
        baikeOnly ? [] : news,
        researchContext,
        webResults,
      );
    }

    const raw = await callAIJson<unknown>(
      `你是AI城市企业人物品牌档案生成专家。${TYPE_PROMPTS[type]}
${BASE_RULES}
返回 JSON 格式：${ENTITY_JSON_SCHEMA}`,
      `请为以下对象生成品牌档案：\n名称：${name}\n类型：${type}\n子类型：${subtype || "无"}${newsContext}`,
    );
    return parseGeneratedEntity(raw as Partial<GeneratedEntity>, name, type, subtype, baikeOnly ? [] : news, researchContext, webResults);
  } catch {
    return mockEntity(name, type, subtype, baikeOnly ? [] : news, webResults, researchContext);
  }
}

const REPORT_META_SCHEMA = `{
  "title": "品牌复盘 决胜终端——{品牌名}品牌成长的18个关键步骤复盘",
  "summary": "300字执行摘要",
  "one_line_positioning": "一句话品牌定位",
  "brand_slogan_analysis": "品牌口号解读",
  "scores": { "消费者洞察力": 8 },
  "overall_score": 7.8,
  "recommendations": ["改进建议1", "改进建议2"],
  "training_points": ["学习要点1", "学习要点2"]
}`;

const REPORT_STEPS_BATCH_SCHEMA = `{
  "steps": [
    {
      "step": 1,
      "title": "消费者研究",
      "subtitle": "洞察未被满足的需求",
      "theory_tools": "150-200字",
      "method_models": "150-200字",
      "brand_practice": "200-300字，写该品牌具体做法",
      "brand_case": "200-300字，含可查证的细节与数据",
      "summary_lessons": "100-150字"
    }
  ]
}`;

function computeOverallScore(scores: Record<string, number>): number {
  const values = Object.values(scores);
  if (!values.length) return 0;
  return Math.round((values.reduce((a, b) => a + b, 0) / values.length) * 10) / 10;
}

function defaultScores(): Record<string, number> {
  const scores: Record<string, number> = {};
  BRAND_SCORE_DIMENSIONS.forEach((dim, i) => {
    scores[dim] = 6 + (i % 3);
  });
  return scores;
}

function normalizeScores(raw?: Record<string, number | null>): Record<string, number> {
  const base = defaultScores();
  if (!raw) return base;
  for (const dim of BRAND_SCORE_DIMENSIONS) {
    const v = raw[dim];
    if (typeof v === "number" && !Number.isNaN(v)) {
      base[dim] = Math.min(10, Math.max(0, v));
    }
  }
  return base;
}

function normalizeReportStep(
  def: (typeof BRAND_REVIEW_18_STEPS)[number],
  existing: Partial<ReportStep> | undefined,
  name: string,
  researchContext?: string,
): ReportStep {
  const isMockTemplate = isPlaceholderContent(existing?.brand_case);

  const pick = (
    field: keyof ReportStep,
    fallbackField: "theory_tools" | "method_models" | "brand_practice" | "brand_case" | "summary_lessons",
  ) => {
    const val = existing?.[field] as string | undefined;
    if (val?.trim() && !isPlaceholderContent(val)) return val;
    const fromResearch = fillReportStepFromResearch(
      researchContext,
      def.title,
      def.step,
      fallbackField,
    );
    if (fromResearch) return fromResearch;
    return "";
  };

  return {
    step: def.step,
    title: def.title,
    subtitle: def.subtitle,
    theory_tools: pick("theory_tools", "theory_tools"),
    method_models: pick("method_models", "method_models"),
    brand_practice: pick("brand_practice", "brand_practice"),
    brand_case: isMockTemplate
      ? pick("brand_case", "brand_case")
      : pick("brand_case", "brand_case"),
    summary_lessons: pick("summary_lessons", "summary_lessons"),
  };
}

function ensureReportSteps(
  aiSteps: ReportStep[],
  name: string,
  researchContext?: string,
): ReportStep[] {
  const byStep = new Map<number, Partial<ReportStep>>();
  for (const s of aiSteps) {
    if (s?.step) byStep.set(s.step, s);
  }

  return BRAND_REVIEW_18_STEPS.map((def) => {
    const step = normalizeReportStep(def, byStep.get(def.step), name, researchContext);
    return {
      ...step,
      theory_tools: sanitizeText(step.theory_tools),
      method_models: sanitizeText(step.method_models),
      brand_practice: sanitizeText(step.brand_practice),
      brand_case: sanitizeText(step.brand_case),
      summary_lessons: sanitizeText(step.summary_lessons),
    };
  });
}

async function generateReportStepsBatch(
  name: string,
  type: EntityType,
  context: string,
  from: number,
  to: number,
): Promise<ReportStep[]> {
  const defs = BRAND_REVIEW_18_STEPS.filter((s) => s.step >= from && s.step <= to);
  const raw = await callAIJson<{ steps?: ReportStep[] }>(
    `${BRAND_REPORT_SYSTEM_PROMPT}

只返回 JSON，格式：
${REPORT_STEPS_BATCH_SCHEMA}

严禁套话与占位语（禁止「待补充」「资料不足」「差异化策略在市场中建立独特认知」）。
必须写${name}的真实政策、企业、事件、数据；可原文摘录百科/政府网段落。`,
    `为「${name}」（${type}）撰写品牌复盘第 ${from}-${to} 步。

资料：
${context || "公开资料有限，谨慎分析"}

本批步骤（每步五段式：理论工具/方法模型/品牌实践/品牌案例/总结借鉴）：
${defs.map((s) => `第${s.step}步 ${s.title}——${s.subtitle}。提示：${s.hint}`).join("\n")}

参照胖东来、瑞幸咖啡复盘文档的写法：案例段要有具体场景、动作、结果；城市类写产业政策、龙头企业和地标。`,
  );
  return raw.steps || [];
}

async function generateReportMeta(
  name: string,
  type: EntityType,
  context: string,
): Promise<Partial<GeneratedReport>> {
  return callAIJson<Partial<GeneratedReport>>(
    `${BRAND_REPORT_SYSTEM_PROMPT}

只返回 JSON（不要 steps），格式：
${REPORT_META_SCHEMA}`,
    `为「${name}」（${type}）生成品牌复盘报告的摘要与评分部分。

资料：
${context || "公开资料有限"}`,
  );
}

export async function generateReportContent(
  name: string,
  type: EntityType,
  profileSummary?: string,
  news?: NewsItem[],
  researchContext?: string,
): Promise<GeneratedReport> {
  const context = [profileSummary, researchContext, news?.map((n) => n.title).join("\n")]
    .filter(Boolean)
    .join("\n\n");

  try {
    const meta = await generateReportMeta(name, type, context);
    const batches: Array<[number, number]> = [
      [1, 6],
      [7, 12],
      [13, 18],
    ];
    const stepChunks = await Promise.all(
      batches.map(([from, to]) => generateReportStepsBatch(name, type, context, from, to)),
    );
    const steps = ensureReportSteps(stepChunks.flat(), name, researchContext);
    const scores = normalizeScores(meta.scores as Record<string, number | null> | undefined);

    return GeneratedReportSchema.parse({
      title: meta.title || `品牌复盘 决胜终端——${name}品牌成长的18个关键步骤复盘`,
      summary: meta.summary || `${name}品牌成长18步复盘报告。`,
      one_line_positioning: meta.one_line_positioning,
      brand_slogan_analysis: meta.brand_slogan_analysis,
      scores,
      overall_score: meta.overall_score ?? computeOverallScore(scores),
      steps,
      recommendations: meta.recommendations?.length
        ? meta.recommendations
        : ["按18步模型系统复盘，强化终端体验与品牌资产沉淀"],
      training_points: meta.training_points,
    });
  } catch (error) {
    console.error("[generateReportContent] AI 生成失败，降级模板:", error);
    return mockReport(name, type);
  }
}
