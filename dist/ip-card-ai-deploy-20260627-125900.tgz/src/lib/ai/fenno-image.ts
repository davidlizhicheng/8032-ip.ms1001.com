import { mkdir, writeFile } from "fs/promises";
import path from "path";
import crypto from "crypto";
import {
  localUploadServePath,
  toPublicAssetUrl,
} from "@/lib/storage/public-url";

const DEFAULT_BASE = "https://api.fenno.ai/v1";
const DEFAULT_MODEL = "gpt-image-2";

function imageEndpoint(baseUrl: string) {
  const base = (baseUrl || DEFAULT_BASE).replace(/\/$/, "");
  if (base.endsWith("/images/generations")) return base;
  if (base.endsWith("/v1")) return `${base}/images/generations`;
  if (base.endsWith("/v1/images")) return `${base}/generations`;
  return `${base}/v1/images/generations`;
}

function buildIpPrompt(name: string, entityType: string, summary?: string) {
  const typeLabel =
    entityType === "city"
      ? "城市"
      : entityType === "company"
        ? "企业"
        : entityType === "person"
          ? "人物"
          : "品牌";
  const context = summary ? `背景：${summary.slice(0, 200)}。` : "";
  return [
    `为「${name}」设计一张${typeLabel}超级品牌 IP 形象海报。`,
    context,
    "竖版构图，现代商业视觉，主视觉突出，留白清晰，",
    "适合官网与社交媒体传播，不要文字水印，不要拼图，只输出一张完整海报。",
  ].join("");
}

async function saveImageBuffer(buffer: Buffer, ext = "png") {
  const filename = `${Date.now()}-${crypto.randomBytes(4).toString("hex")}.${ext}`;
  const uploadDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });
  const localPath = path.join(uploadDir, filename);
  await writeFile(localPath, buffer);
  return toPublicAssetUrl(localUploadServePath(filename));
}

export async function generateIpImage(options: {
  name: string;
  entityType: string;
  summary?: string;
}) {
  const apiKey = process.env.FENNO_API_KEY || process.env.POSTER_API_KEY;
  if (!apiKey) {
    throw new Error("未配置 FENNO_API_KEY，无法生成 IP 图");
  }

  const baseUrl = process.env.FENNO_BASE_URL || process.env.FENNO_IMAGE_BASE_URL || DEFAULT_BASE;
  const model = process.env.FENNO_IMAGE_MODEL || "gpt-image-2";
  const prompt = buildIpPrompt(options.name, options.entityType, options.summary);

  const payload = {
    model,
    prompt,
    size: process.env.FENNO_IMAGE_SIZE || "1024x1536",
    quality: process.env.FENNO_IMAGE_QUALITY || "medium",
    background: "opaque",
    output_format: "png",
    n: 1,
  };

  const res = await fetch(imageEndpoint(baseUrl), {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify(payload),
  });

  const raw = await res.text();
  if (!res.ok) {
    throw new Error(`Fenno 生图失败 (${res.status}): ${raw.slice(0, 300)}`);
  }

  const data = JSON.parse(raw) as {
    data?: Array<{ b64_json?: string; url?: string }>;
  };
  const imageData = data.data?.[0];
  if (!imageData) {
    throw new Error("Fenno 未返回图片数据");
  }

  if (imageData.b64_json) {
    const buffer = Buffer.from(imageData.b64_json, "base64");
    const url = await saveImageBuffer(buffer, "png");
    return { url, prompt };
  }

  if (imageData.url) {
    const imgRes = await fetch(imageData.url);
    if (!imgRes.ok) throw new Error("下载生成图片失败");
    const buffer = Buffer.from(await imgRes.arrayBuffer());
    const url = await saveImageBuffer(buffer, "png");
    return { url, prompt };
  }

  throw new Error("Fenno 响应缺少 b64_json 或 url");
}
