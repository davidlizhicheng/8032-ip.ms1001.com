/**
 * 人物公开资料 → 个人介绍 的专业提示词
 * 核心原则：百度百科/维基百科全文为骨架，新闻仅作补充，禁止碎新闻拼凑
 */

export const PERSON_BIO_SOURCE_RULES = `
资料选用规则（按优先级，必须严格遵守）：
1. **第一来源：百度百科/维基百科全文**。你必须基于百科正文 **用 AI 重新撰写** 百科词条式介绍，按时间线组织，禁止把新闻摘要、门户页、财经快讯直接拼接。
2. **第二来源：维基百科**。百科缺失时采用，标注（据维基百科）。
3. **第三来源：政府官网、官网、权威传记**。仅补充职务、荣誉等百科未覆盖的细节。
4. **禁止作为主要来源的内容**：
   - 财经快讯（身家涨跌、股价波动、是否万亿富豪等时效性报道）
   - 门户聚合页、标签页、自媒体评论（新浪标签页、36氪转述、凤凰网自媒体等）
   - 「待抓取」「公开检索」等占位摘要
   - 与人物生平无关的行业分析、太空经济市场规模等背景铺陈
5. 新闻仅可用于「近期动态」一句带过，不得占据个人介绍主体篇幅。
6. 写具体事实：出生/国籍、教育背景、创业时间线、代表公司、职务、代表作品、荣誉。禁止「行业领军人物」「极具影响力」等空泛套话。`;

export const PERSON_BIO_STRUCTURE_RULES = `
个人介绍结构要求：
1. **bio（150-200字）**：身份定位 + 核心标签 + 最重要 2-3 项成就，一句话抓住是谁、做什么、为何知名。
2. **long_bio（800-1200字）**：按时间线有机整合——早年与教育 → 创业/职业转折 → 代表企业与职务 → 核心成就与理念 → 社会影响力。段落清晰，每段有具体人名、公司名、年份。
3. **profile_sections（3-6 模块）**：从百科目录提炼，如「早年经历」「创业历程」「代表企业与职务」「商业成就」「个人理念」「社会荣誉」。每模块 150-350 字，必须含可核对事实。
4. **experiences**：按时间排列的关键经历，每项 content 至少 150 字，写公司名、职务、年份、具体事件。
5. 全文目标 1000-2000 字；所有字段写到完整句落（。！？），严禁句中截断。`;

export const PERSON_ENTITY_STRUCTURE_RULES = `
人物档案 sections 必须恰好 10 节：个人简介、早年经历、职业生涯、企业身份与职务、创业历程、商业成就、关联企业与品牌、行业影响力、社会职务与荣誉、公开报道摘录。
- 前 9 节：以百度百科正文为主，每节 200-500 字，大段忠实摘录或改写，标注（据百度百科）。
- 第 10 节「公开报道摘录」：最多 200 字，仅 1-2 条权威报道标题级摘要，禁止大段财经快讯。
- 全文 2000-4000 字；summary 250-400 字，概括身份与核心成就。`;

export function buildPersonBioSystemPrompt(mode: "card" | "entity"): string {
  const structure =
    mode === "card" ? PERSON_BIO_STRUCTURE_RULES : PERSON_ENTITY_STRUCTURE_RULES;
  const role =
    mode === "card"
      ? "你是个人品牌网页名片的内容专家，将公开资料整理成适合手机与电脑阅读的个人介绍 JSON。"
      : "你是 AI 人物公开资料档案生成专家，将百科正文整理成结构化人物档案 JSON。";

  return `${role}

${PERSON_BIO_SOURCE_RULES}

${structure}

合规：不编造手机号、微信、私人邮箱、住址；官员不做商业背书；律师不写「包赢」；未成年人不展示联系方式。
只返回合法 JSON，不要 markdown。`;
}

export function buildPersonResearchContextBlock(researchContext: string): string {
  if (!researchContext?.trim()) return "";

  const hasBaike = researchContext.includes("百度百科") && /正文：\s*\S{200,}/.test(researchContext);

  const header = hasBaike
    ? `公开资料检索结果（**必须优先采用百度百科全文**，按章节摘录/改写为个人介绍；忽略财经快讯与门户聚合页）：`
    : `公开资料检索结果（优先采用百科/权威来源，禁止用碎新闻拼凑）：`;

  return `\n\n${header}\n${researchContext}`;
}
