import { z } from "zod";

export const ENTITY_TYPES = [
  "city",
  "company",
  "person",
  "brand",
  "profession",
] as const;

export type EntityType = (typeof ENTITY_TYPES)[number];

export const PERSON_SUBTYPES = [
  "entrepreneur",
  "executive",
  "expert",
  "lawyer",
  "doctor",
  "teacher",
  "student",
  "youth_hero",
  "tech_talent",
  "founder",
  "investor",
  "influencer",
  "association_leader",
  "official",
] as const;

export type PersonSubtype = (typeof PERSON_SUBTYPES)[number];

export const ProfileSectionSchema = z.object({
  type: z.string(),
  title: z.string(),
  content: z.string(),
});

export const GeneratedEntitySchema = z.object({
  slug: z.string(),
  name: z.string(),
  type: z.enum(ENTITY_TYPES),
  subtype: z.string().optional(),
  title: z.string(),
  subtitle: z.string().optional(),
  slogan: z.string(),
  summary: z.string(),
  sections: z.array(ProfileSectionSchema),
  tags: z.array(z.string()),
  keywords: z.array(z.string()),
  seo_title: z.string(),
  seo_description: z.string(),
  theme: z.string().default("business_gold_dark"),
  relations: z
    .array(
      z.object({
        target_name: z.string(),
        target_type: z.enum(ENTITY_TYPES),
        relation_type: z.string(),
        label: z.string().optional(),
      }),
    )
    .optional(),
  sources: z
    .array(
      z.object({
        title: z.string(),
        url: z.string().optional(),
        source_type: z.string(),
        excerpt: z.string().optional(),
        confidence_score: z.number().min(0).max(1).default(0.5),
      }),
    )
    .optional(),
});

export type GeneratedEntity = z.infer<typeof GeneratedEntitySchema>;

export const ReportScoreSchema = z.record(z.string(), z.number().min(0).max(10));

export const ReportStepSchema = z.object({
  step: z.number().min(1).max(18),
  title: z.string(),
  subtitle: z.string().optional(),
  theory_tools: z.string(),
  method_models: z.string(),
  brand_practice: z.string(),
  brand_case: z.string(),
  summary_lessons: z.string(),
});

export type ReportStep = z.infer<typeof ReportStepSchema>;

export const GeneratedReportSchema = z.object({
  title: z.string(),
  summary: z.string(),
  scores: ReportScoreSchema,
  sections: z
    .array(z.object({ title: z.string(), content: z.string() }))
    .optional(),
  steps: z.array(ReportStepSchema).optional(),
  recommendations: z.array(z.string()),
  overall_score: z.number().min(0).max(10),
  training_points: z.array(z.string()).optional(),
  brand_slogan_analysis: z.string().optional(),
  one_line_positioning: z.string().optional(),
});

export type GeneratedReport = z.infer<typeof GeneratedReportSchema>;

export const BatchJobSchema = z.object({
  names: z.string().min(1),
  entityType: z.string().default("auto"),
  generatePage: z.boolean().default(true),
  generateReport: z.boolean().default(true),
  fetchNews: z.boolean().default(true),
  personSubtype: z.string().optional(),
  /** 重名人物确认：{ "李朝曙": "lichaoshu-shenzhen" } */
  personCandidates: z.record(z.string(), z.string()).optional(),
});

export const ClaimRequestSchema = z.object({
  entityId: z.string(),
  claimType: z.enum(["person", "company", "city", "brand"]),
  proofText: z.string().min(10, "请说明认领理由"),
  contactName: z.string().optional(),
  contactPhone: z.string().optional(),
  contactEmail: z.string().optional(),
});

export type EntityProfileContent = {
  sections: Array<{ type: string; title: string; content: string }>;
  tags: string[];
  keywords: string[];
};

export type EntityReportContent = {
  sections?: Array<{ title: string; content: string }>;
  steps?: ReportStep[];
  recommendations: string[];
  training_points?: string[];
  brand_slogan_analysis?: string;
  one_line_positioning?: string;
};

export type EntityReportScores = Record<string, number>;

export const ENTITY_TYPE_LABELS: Record<EntityType, string> = {
  city: "城市",
  company: "企业",
  person: "人物",
  brand: "品牌",
  profession: "职业",
};

export const PERSON_SUBTYPE_LABELS: Record<string, string> = {
  entrepreneur: "企业家",
  executive: "企业高管",
  expert: "讲师专家",
  lawyer: "律师",
  doctor: "医生",
  teacher: "教师",
  student: "学生",
  youth_hero: "少年榜样",
  tech_talent: "科技人才",
  founder: "创业者",
  investor: "投资人",
  influencer: "主播达人",
  association_leader: "协会负责人",
  official: "公职人员",
};
