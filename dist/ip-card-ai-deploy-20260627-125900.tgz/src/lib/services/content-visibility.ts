import { prisma } from "@/lib/prisma";
import { featuredWhere, listableWhere } from "@/lib/visibility";
import type { EntityType } from "@/lib/schemas/entity";

export async function getFeaturedEntitiesByType(type: EntityType, limit = 12) {
  return prisma.entity.findMany({
    where: featuredWhere(type),
    include: { profile: true },
    orderBy: { updatedAt: "desc" },
    take: limit,
  });
}

export async function getPublicEntitiesByType(type: EntityType, limit = 200) {
  return prisma.entity.findMany({
    where: listableWhere(type),
    include: { profile: true },
    orderBy: [{ isFeatured: "desc" }, { updatedAt: "desc" }],
    take: limit,
  });
}

export async function getPublicCards(limit = 200) {
  return prisma.card.findMany({
    where: { visibility: "public", status: "published" },
    orderBy: [{ isFeatured: "desc" }, { updatedAt: "desc" }],
    take: limit,
    select: {
      id: true,
      slug: true,
      name: true,
      title: true,
      company: true,
      brandSlogan: true,
      bio: true,
      avatarUrl: true,
      isFeatured: true,
      visibility: true,
      userId: true,
    },
  });
}

export async function getUserPages(userId: string) {
  const [cards, entities] = await Promise.all([
    prisma.card.findMany({
      where: { userId },
      orderBy: { updatedAt: "desc" },
      select: {
        id: true,
        slug: true,
        name: true,
        title: true,
        visibility: true,
        isFeatured: true,
        updatedAt: true,
      },
    }),
    prisma.entity.findMany({
      where: { ownerUserId: userId },
      include: { profile: { select: { summary: true, slogan: true } } },
      orderBy: { updatedAt: "desc" },
    }),
  ]);
  return { cards, entities };
}

/** 撤回全部旧档案，等待管理员批量重新生成 */
export async function withdrawAllEntities() {
  const result = await prisma.entity.updateMany({
    where: { visibility: { not: "admin_hidden" } },
    data: {
      visibility: "admin_hidden",
      status: "hidden",
      isFeatured: false,
    },
  });
  return result.count;
}

export async function adminListContent(type?: string) {
  return prisma.entity.findMany({
    where: type ? { type } : undefined,
    include: { profile: true },
    orderBy: { updatedAt: "desc" },
    take: 300,
  });
}

export async function adminListCards() {
  return prisma.card.findMany({
    orderBy: { updatedAt: "desc" },
    take: 300,
    include: { user: { select: { displayName: true, unifiedUsername: true } } },
  });
}
