import { prisma } from "@/lib/prisma";
import { generateAndSaveEntity } from "@/lib/services/entity";
import { detectEntityType } from "@/lib/ai/detect-type";
import type { ResearchStep } from "@/lib/search/research-types";

async function appendResearchLog(itemId: string, steps: ResearchStep[]) {
  await prisma.generationJobItem.update({
    where: { id: itemId },
    data: { researchLog: JSON.stringify(steps) },
  });
}

export async function processBatchJob(jobId: string) {
  const job = await prisma.generationJob.findUnique({ where: { id: jobId } });
  if (!job) throw new Error("任务不存在");

  await prisma.generationJob.update({
    where: { id: jobId },
    data: { status: "running" },
  });

  const names = job.inputText
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  let success = 0;
  let failed = 0;
  const errors: string[] = [];

  let personCandidates: Record<string, string> = {};
  if (job.optionsJson) {
    try {
      const options = JSON.parse(job.optionsJson) as { personCandidates?: Record<string, string> };
      personCandidates = options.personCandidates || {};
    } catch {
      personCandidates = {};
    }
  }

  for (const name of names) {
    const item = await prisma.generationJobItem.findFirst({
      where: { jobId, name },
    });

    if (!item) continue;

    const researchSteps: ResearchStep[] = [];

    await prisma.generationJobItem.update({
      where: { id: item.id },
      data: { status: "running", researchLog: JSON.stringify([]) },
    });

    try {
      const detected = detectEntityType(name, job.entityType || "auto");
      const entity = await generateAndSaveEntity(name, {
        entityType: detected.type,
        subtype: detected.subtype,
        fetchNews: job.fetchNews,
        generateReport: job.generateReport,
        publish: true,
        visibility: "public",
        isOfficial: true,
        isFeatured: false,
        confirmedCandidateId: personCandidates[name],
        onResearchProgress: (step) => {
          researchSteps.push(step);
          void appendResearchLog(item.id, [...researchSteps]);
        },
      });

      researchSteps.push({
        phase: "ai",
        label: `AI 生成完成：${entity.name}`,
        status: "done",
      });
      await appendResearchLog(item.id, researchSteps);

      await prisma.generationJobItem.update({
        where: { id: item.id },
        data: { status: "completed", entityId: entity.id, entityType: entity.type },
      });
      success++;
    } catch (err) {
      const msg = err instanceof Error ? err.message : "生成失败";
      errors.push(`${name}: ${msg}`);
      researchSteps.push({
        phase: "ai",
        label: `生成失败：${msg}`,
        status: "error",
      });
      await prisma.generationJobItem.update({
        where: { id: item.id },
        data: { status: "failed", error: msg, researchLog: JSON.stringify(researchSteps) },
      });
      failed++;
    }
  }

  await prisma.generationJob.update({
    where: { id: jobId },
    data: {
      status: failed === names.length ? "failed" : "completed",
      successCount: success,
      failedCount: failed,
      errorLog: errors.length ? errors.join("\n") : null,
    },
  });
}

export async function createBatchJob(input: {
  names: string;
  entityType?: string;
  generatePage?: boolean;
  generateReport?: boolean;
  fetchNews?: boolean;
  personCandidates?: Record<string, string>;
}) {
  const nameList = input.names
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const job = await prisma.generationJob.create({
    data: {
      jobType: `batch_${input.entityType || "mixed"}`,
      inputText: input.names,
      entityType: input.entityType || "auto",
      generatePage: input.generatePage ?? true,
      generateReport: input.generateReport ?? true,
      fetchNews: input.fetchNews ?? true,
      optionsJson: input.personCandidates
        ? JSON.stringify({ personCandidates: input.personCandidates })
        : null,
      totalCount: nameList.length,
      items: {
        create: nameList.map((name) => ({ name })),
      },
    },
    include: { items: true },
  });

  return job;
}
