import { prisma } from "@/lib/prisma";
import type { CreateCardInput } from "@/lib/schemas/card";
import { slugify, ensureUniqueSlug } from "@/lib/utils/slug";

export async function createCard(input: CreateCardInput, ownerUserId?: string) {
  const baseSlug = input.slug || slugify(input.name);
  const slug = await ensureUniqueSlug(baseSlug, async (s) => {
    const existing = await prisma.card.findUnique({ where: { slug: s } });
    return !!existing;
  });

  const sections: Array<{
    type: string;
    title: string;
    content: string;
    sortOrder: number;
  }> = [];

  let order = 0;

  if (input.bio && !input.longBio) {
    sections.push({
      type: "business",
      title: "个人简介",
      content: input.bio,
      sortOrder: order++,
    });
  }

  if (input.longBio) {
    sections.push({
      type: "story",
      title: "详细介绍",
      content: input.longBio,
      sortOrder: order++,
    });
  }

  input.profileSections?.forEach((sec) => {
    sections.push({
      type: sec.type || "story",
      title: sec.title,
      content: sec.content,
      sortOrder: order++,
    });
  });

  if (input.services?.length) {
    sections.push({
      type: "service",
      title: "服务项目",
      content: input.services.join("、"),
      sortOrder: order++,
    });
  }

  input.experiences?.forEach((exp) => {
    sections.push({
      type: "experience",
      title: exp.title || "过往经历",
      content: exp.content,
      sortOrder: order++,
    });
  });

  input.honors?.forEach((honor) => {
    sections.push({
      type: "honor",
      title: honor.title || "荣誉资质",
      content: honor.content,
      sortOrder: order++,
    });
  });

  input.cases?.forEach((item) => {
    sections.push({
      type: "case",
      title: item.title || "客户案例",
      content: item.content,
      sortOrder: order++,
    });
  });

  const card = await prisma.card.create({
    data: {
      slug,
      userId: ownerUserId,
      name: input.name,
      title: input.title,
      company: input.company,
      avatarUrl: input.avatarUrl,
      coverUrl: input.coverUrl,
      brandSlogan: input.brandSlogan,
      bio: input.bio,
      phone: input.phone,
      email: input.email,
      wechat: input.wechat,
      address: input.address,
      theme: input.theme,
      visibility: "private",
      isFeatured: false,
      sections: { create: sections },
      mediaAssets: {
        create: [
          ...(input.avatarUrl
            ? [{ url: input.avatarUrl, type: "avatar", sortOrder: 0 }]
            : []),
          ...(input.coverUrl
            ? [{ url: input.coverUrl, type: "cover", sortOrder: 1 }]
            : []),
          ...(input.galleryImages?.map((img, i) => ({
            url: img.url,
            type: img.type,
            title: img.title,
            sortOrder: i + 2,
          })) || []),
        ],
      },
      videoLinks: {
        create:
          input.videos?.map((video, i) => ({
            platform: video.platform,
            url: video.url,
            title: video.title,
            coverUrl: video.coverUrl,
            embedUrl: video.embedUrl,
            description: video.description,
            canEmbed: video.canEmbed,
            sortOrder: i,
          })) || [],
      },
    },
    include: {
      sections: true,
      mediaAssets: true,
      videoLinks: true,
    },
  });

  return card;
}

export async function getCardBySlug(slug: string, options?: { includePrivate?: boolean }) {
  const card = await prisma.card.findUnique({
    where: { slug },
    include: {
      sections: { orderBy: { sortOrder: "asc" } },
      mediaAssets: { orderBy: { sortOrder: "asc" } },
      videoLinks: { orderBy: { sortOrder: "asc" } },
    },
  });
  if (!card) return null;
  if (card.visibility === "admin_hidden") return null;
  if (!options?.includePrivate && card.visibility !== "public") return null;
  return card;
}

export async function getCardForViewer(
  slug: string,
  viewerUserId?: string | null,
  isAdmin?: boolean,
) {
  const card = await prisma.card.findUnique({
    where: { slug },
    include: {
      sections: { orderBy: { sortOrder: "asc" } },
      mediaAssets: { orderBy: { sortOrder: "asc" } },
      videoLinks: { orderBy: { sortOrder: "asc" } },
    },
  });
  if (!card || card.visibility === "admin_hidden") return null;
  const { canViewContent } = await import("@/lib/visibility");
  if (!canViewContent({
    visibility: card.visibility,
    ownerUserId: card.userId,
    viewerUserId,
    isAdmin,
  })) {
    return null;
  }
  return card;
}

export async function getCardById(id: string) {
  return prisma.card.findUnique({
    where: { id },
    include: {
      sections: { orderBy: { sortOrder: "asc" } },
      mediaAssets: { orderBy: { sortOrder: "asc" } },
      videoLinks: { orderBy: { sortOrder: "asc" } },
    },
  });
}
