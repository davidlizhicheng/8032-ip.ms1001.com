import { prisma } from "@/lib/prisma";
import { detectEntityType, entitySlug } from "@/lib/ai/detect-type";
import {
  generateEntityContent,
  generateReportContent,
} from "@/lib/ai/generate-entity";
import { gatherEntityResearch } from "@/lib/search/gather-research";
import { pickPersonResearchContext, buildBaikeOnlyContext } from "@/lib/search/baike-context";
import { dedupeSources } from "@/lib/search/source-dedupe";
import { filterRealNews } from "@/lib/news/filter-news";
import { gatherFamousPersonMedia } from "@/lib/search/famous-person-media";
import { gatherPersonResearchForCard } from "@/lib/search/gather-person-research";
import {
  resolveRegistryCandidate,
} from "@/lib/search/person-disambiguation-registry";
import {
  buildSelfProvidedCandidate,
  lookupPersonCandidatesFromEncyclopedia,
  resolveEncyclopediaCandidate,
} from "@/lib/search/lookup-person-encyclopedia";
import type { ResearchProgressCallback, ResearchBundle } from "@/lib/search/research-types";
import { checkContentRisk } from "@/lib/compliance/risk-check";
import type { EntityType, EntityProfileContent } from "@/lib/schemas/entity";

export async function ensureUniqueEntitySlug(baseSlug: string): Promise<string> {
  let slug = baseSlug;
  let i = 1;
  while (await prisma.entity.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${i}`;
    i++;
  }
  return slug;
}

export class PersonDisambiguationRequiredError extends Error {
  personName: string;
  reason: string;
  candidates: Array<{
    id: string;
    label: string;
    title?: string;
    company?: string;
    snippet: string;
    region?: string;
  }>;
  allowCompare: boolean;

  constructor(
    personName: string,
    reason: string,
    candidates: PersonDisambiguationRequiredError["candidates"],
    allowCompare: boolean,
  ) {
    super(reason);
    this.personName = personName;
    this.reason = reason;
    this.candidates = candidates;
    this.allowCompare = allowCompare;
  }
}

export async function generateAndSaveEntity(
  name: string,
  options: {
    entityType?: string;
    subtype?: string;
    fetchNews?: boolean;
    generateReport?: boolean;
    publish?: boolean;
    onResearchProgress?: ResearchProgressCallback;
    visibility?: string;
    isFeatured?: boolean;
    isOfficial?: boolean;
    confirmedCandidateId?: string;
  } = {},
) {
  const detected = detectEntityType(name, options.entityType);
  const type = detected.type;
  const subtype = options.subtype || detected.subtype;

  if (type === "person" && !options.confirmedCandidateId) {
    const lookup = await lookupPersonCandidatesFromEncyclopedia(name);
    throw new PersonDisambiguationRequiredError(
      name,
      lookup.reason,
      lookup.candidates.length > 0
        ? lookup.candidates.map(({ id, label, title, company, snippet, url, region }) => ({
            id,
            label,
            title,
            company,
            snippet,
            url,
            region,
          }))
        : [buildSelfProvidedCandidate(name)],
      lookup.allowCompare,
    );
  }

  const resolved = options.confirmedCandidateId
    ? await resolveEncyclopediaCandidate(name, options.confirmedCandidateId)
    : null;
  const registryCandidate =
    resolved?.registryCandidate ||
    (options.confirmedCandidateId
      ? resolveRegistryCandidate(name, options.confirmedCandidateId)
      : null);

  let research: ResearchBundle & { baike?: import("@/lib/search/baike-fetcher").EnrichedSource | null };
  if (type === "person") {
    const personResearch = await gatherPersonResearchForCard(name, {
      candidate: registryCandidate,
      identityHint: resolved?.identityHint,
      confirmedBaikeUrl: resolved?.baikeUrl,
      confirmedWikiUrl: resolved?.wikiUrl,
    });
    research = {
      news: [],
      webResults: personResearch.webResults,
      baikeEntries: personResearch.baikeEntries,
      wiki: personResearch.wiki,
      pageExcerpts: [],
      contextText: personResearch.contextText,
      sourceCount: personResearch.sourceCount,
      steps: personResearch.steps,
      baike: personResearch.baikeEntries[0] || null,
    };
  } else {
    research = await gatherEntityResearch(name, type, {
      fetchNews: options.fetchNews !== false,
      webSearch: true,
      onProgress: options.onResearchProgress,
    });
  }

  const personBaikeOnly =
    type === "person" &&
    (research.baikeEntries.length > 0 || Boolean(research.wiki?.fullText));
  const cityBaikeOnly =
    type === "city" &&
    (research.baikeEntries.length > 0 || Boolean(research.wiki?.fullText));
  const baikeOnly = personBaikeOnly || cityBaikeOnly;
  const aiContext =
    type === "person"
      ? pickPersonResearchContext({
          baikeEntries: research.baikeEntries,
          wiki: research.wiki,
          contextText: research.contextText,
        })
      : type === "city" && cityBaikeOnly
        ? buildBaikeOnlyContext(research.baikeEntries, research.wiki)
        : research.contextText;

  const realNews = filterRealNews(research.news);

  const generated = await generateEntityContent(
    name,
    type,
    subtype,
    baikeOnly ? [] : realNews,
    aiContext,
    research.webResults,
    {
      baikeOnly,
      identityHint: registryCandidate?.identityHint,
    },
  );
  const slug = await ensureUniqueEntitySlug(generated.slug || entitySlug(name));

  const fullContent = JSON.stringify({
    sections: generated.sections,
    tags: generated.tags,
    keywords: generated.keywords,
  } satisfies EntityProfileContent);

  const risk = checkContentRisk(
    fullContent + generated.summary,
    type,
    subtype,
  );

  const sourcesToSave = dedupeSources([
    ...(generated.sources || []),
    ...research.baikeEntries.map((baike) => ({
      title: baike.title,
      url: baike.url,
      source_type: "wiki" as const,
      excerpt: baike.fullText?.slice(0, 800) || baike.snippet,
      confidence_score: 0.95,
    })),
    ...(research.wiki
      ? [{
          title: research.wiki.title,
          url: research.wiki.url,
          source_type: "wiki" as const,
          excerpt: research.wiki.fullText?.slice(0, 800) || research.wiki.snippet,
          confidence_score: 0.92,
        }]
      : []),
    ...(research.pageExcerpts || []).map((page) => ({
      title: page.title,
      url: page.url,
      source_type: page.sourceType === "gov" ? "official" as const : "web" as const,
      excerpt: page.fullText?.slice(0, 500) || page.snippet,
      confidence_score: page.confidenceScore,
    })),
  ]).slice(0, 8);

  let famousMedia: Awaited<ReturnType<typeof gatherFamousPersonMedia>> = null;
  if (type === "person") {
    famousMedia = await gatherFamousPersonMedia(name, research);
  }

  const entity = await prisma.entity.create({
    data: {
      type,
      name: generated.name,
      slug,
      subtype: subtype || generated.subtype,
      status: risk.passed
        ? options.publish !== false
          ? "published"
          : "pending_review"
        : "pending_review",
      isAiGenerated: true,
      isOfficial: options.isOfficial !== false,
      visibility: options.visibility || "public",
      isFeatured: options.isFeatured ?? false,
      profile: {
        create: {
          title: generated.title,
          subtitle: generated.subtitle,
          summary: generated.summary,
          slogan: generated.slogan,
          contentJson: fullContent,
          seoTitle: generated.seo_title,
          seoDescription: generated.seo_description,
          theme: generated.theme,
          avatarUrl: famousMedia?.avatarUrl,
          coverUrl: famousMedia?.coverUrl,
        },
      },
      mediaAssets: famousMedia?.galleryImages.length
        ? {
            create: famousMedia.galleryImages.map((img, i) => ({
              url: img.url,
              type: img.type,
              title: img.title,
              sortOrder: i,
            })),
          }
        : undefined,
      videoLinks: famousMedia?.videos.length
        ? {
            create: famousMedia.videos.map((video, i) => ({
              platform: video.platform,
              url: video.url,
              title: video.title,
              coverUrl: video.coverUrl,
              embedUrl: video.embedUrl,
              canEmbed: video.canEmbed,
              sortOrder: i,
            })),
          }
        : undefined,
      sources: {
        create: sourcesToSave.map((s) => ({
          sourceType: s.source_type,
          title: s.title,
          url: s.url,
          excerpt: s.excerpt,
          confidenceScore: s.confidence_score,
        })),
      },
      newsArticles: {
        create: realNews.slice(0, 6).map((n) => ({
          title: n.title,
          url: n.url,
          source: n.source,
          publishedAt: n.publishedAt,
          excerpt: n.excerpt,
        })),
      },
      auditLogs: {
        create: {
          action: "ai_generated",
          details: `AI生成${type}档案`,
          riskFlags: risk.flags.length ? JSON.stringify(risk.flags) : null,
        },
      },
    },
    include: { profile: true },
  });

  if (generated.relations?.length) {
    for (const rel of generated.relations) {
      const targetSlug = entitySlug(rel.target_name);
      let target = await prisma.entity.findFirst({
        where: { OR: [{ slug: targetSlug }, { name: rel.target_name }] },
      });

      if (!target) {
        target = await prisma.entity.create({
          data: {
            type: rel.target_type,
            name: rel.target_name,
            slug: await ensureUniqueEntitySlug(targetSlug),
            status: "draft",
            isAiGenerated: true,
            profile: {
              create: {
                title: rel.target_name,
                summary: "关联实体，待完善",
                contentJson: JSON.stringify({ sections: [], tags: [], keywords: [] }),
              },
            },
          },
        });
      }

      await prisma.entityRelation.create({
        data: {
          fromEntityId: entity.id,
          toEntityId: target.id,
          relationType: rel.relation_type,
          label: rel.label,
        },
      }).catch(() => {});
    }
  }

  if (options.generateReport !== false) {
    const report = await generateReportContent(
      name,
      type,
      generated.summary,
      research.news,
      research.contextText,
    );

    await prisma.entityReport.create({
      data: {
        entityId: entity.id,
        reportType: type === "city" ? "city" : type === "person" ? "person_ip" : "brand",
        title: report.title,
        summary: report.summary,
        contentJson: JSON.stringify({
          steps: report.steps,
          sections: report.sections,
          recommendations: report.recommendations,
          training_points: report.training_points,
          brand_slogan_analysis: report.brand_slogan_analysis,
          one_line_positioning: report.one_line_positioning,
        }),
        scoreJson: JSON.stringify({
          scores: report.scores,
          overall: report.overall_score,
        }),
      },
    });
  }

  return entity;
}

export type { ResearchProgressCallback };

export async function getEntityBySlug(slug: string) {
  return prisma.entity.findUnique({
    where: { slug },
    include: {
      profile: true,
      reports: { orderBy: { createdAt: "desc" } },
      sources: { orderBy: { createdAt: "desc" } },
      newsArticles: { orderBy: { createdAt: "desc" }, take: 10 },
      mediaAssets: { orderBy: { sortOrder: "asc" } },
      videoLinks: { orderBy: { sortOrder: "asc" } },
      relationsFrom: {
        include: { toEntity: { include: { profile: true } } },
      },
      relationsTo: {
        include: { fromEntity: { include: { profile: true } } },
      },
    },
  });
}

export async function getEntitiesByType(type: EntityType, limit = 100) {
  const { getPublicEntitiesByType } = await import("@/lib/services/content-visibility");
  return getPublicEntitiesByType(type, limit);
}

/** @deprecated use getFeaturedEntitiesByType on homepage */
export async function getFeaturedByType(type: EntityType, limit = 12) {
  const { getFeaturedEntitiesByType } = await import("@/lib/services/content-visibility");
  return getFeaturedEntitiesByType(type, limit);
}

export async function getNewEntityIdsFromBatchJob(jobId: string): Promise<string[]> {
  const items = await prisma.generationJobItem.findMany({
    where: { jobId, status: "completed", entityId: { not: null } },
    select: { entityId: true },
  });
  return items.map((i) => i.entityId!).filter(Boolean);
}

export async function getEntityReport(entityId: string, reportType?: string) {
  return prisma.entityReport.findFirst({
    where: { entityId, ...(reportType ? { reportType } : {}) },
    orderBy: { createdAt: "desc" },
  });
}
