/** 站点公网根 URL，用于把 /uploads/... 转为可访问的绝对地址 */
export function getSiteBaseUrl(): string {
  const base =
    process.env.SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    "";
  return base.replace(/\/$/, "");
}

/** 本地 /uploads 走 API 路由，避免生产环境静态目录不可读 */
export function localUploadServePath(filename: string): string {
  return `/api/uploads/${filename}`;
}

export function toPublicAssetUrl(urlPath: string): string {
  const trimmed = urlPath.trim();
  if (!trimmed) return trimmed;
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  const base = getSiteBaseUrl();
  const path = trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
  if (!base) return path;
  return `${base}${path}`;
}

/** 兼容旧 /uploads/ 路径，并可选补全站点域名 */
export function resolveAssetUrl(url?: string | null): string {
  if (!url?.trim()) return "";
  let path = url.trim();
  if (path.startsWith("/uploads/") && !path.startsWith("/api/uploads/")) {
    path = path.replace(/^\/uploads\//, "/api/uploads/");
  }
  return toPublicAssetUrl(path);
}

export function normalizeStoredAssetUrl(url?: string | null): string | undefined {
  if (!url?.trim()) return undefined;
  return resolveAssetUrl(url);
}
