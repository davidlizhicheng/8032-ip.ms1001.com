import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import {
  localUploadServePath,
  toPublicAssetUrl,
} from "@/lib/storage/public-url";

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_SIZE = 5 * 1024 * 1024;

function cosFullyConfigured(): boolean {
  return Boolean(
    process.env.COS_REGION &&
      process.env.COS_ENDPOINT &&
      process.env.COS_SECRET_ID &&
      process.env.COS_SECRET_KEY &&
      process.env.COS_BUCKET &&
      process.env.COS_PUBLIC_URL,
  );
}

function getS3Client() {
  if (!cosFullyConfigured()) return null;

  return new S3Client({
    region: process.env.COS_REGION!,
    endpoint: process.env.COS_ENDPOINT!,
    credentials: {
      accessKeyId: process.env.COS_SECRET_ID!,
      secretAccessKey: process.env.COS_SECRET_KEY!,
    },
    forcePathStyle: true,
  });
}

export function validateImageFile(file: File) {
  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new Error("仅支持 jpg、png、webp 格式");
  }
  if (file.size > MAX_SIZE) {
    throw new Error("图片大小不能超过 5MB");
  }
}

export async function uploadImage(file: File): Promise<string> {
  validateImageFile(file);

  const buffer = Buffer.from(await file.arrayBuffer());
  const ext = file.type.split("/")[1] === "jpeg" ? "jpg" : file.type.split("/")[1];
  const filename = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;

  const s3 = getS3Client();
  const bucket = process.env.COS_BUCKET;

  if (s3 && bucket) {
    const key = `uploads/${filename}`;
    await s3.send(
      new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        Body: buffer,
        ContentType: file.type,
        ACL: "public-read",
      }),
    );

    const publicBase = process.env.COS_PUBLIC_URL!.replace(/\/$/, "");
    return `${publicBase}/${key}`;
  }

  const uploadDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });
  const localPath = path.join(uploadDir, filename);
  await writeFile(localPath, buffer);
  return toPublicAssetUrl(localUploadServePath(filename));
}
