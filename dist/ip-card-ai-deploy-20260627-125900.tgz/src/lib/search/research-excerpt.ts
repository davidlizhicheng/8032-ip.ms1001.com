/** 从检索上下文中切分可用段落，用于填充 AI 未生成的章节 */

import {
  isPlaceholderContent,
} from "@/lib/content/sanitize-placeholder";

export { isPlaceholderContent } from "@/lib/content/sanitize-placeholder";

/** 文本是否在句中被截断（常见于 AI 输出不完整） */
export function isIncompleteContent(text?: string | null, minComplete = 120): boolean {
  const t = text?.trim() || "";
  if (!t) return true;
  if (t.length < minComplete) return true;
  if (/[。！？.!?…]$/.test(t)) return false;
  if (t.length >= 350) return false;
  return true;
}

export function splitResearchParagraphs(context: string): string[] {
  if (!context?.trim()) return [];

  const baikeParas: string[] = [];
  for (const m of context.matchAll(/\[权威资料 \d+\][\s\S]*?正文：\s*([\s\S]*?)(?=\n\[权威资料|\n【|$)/g)) {
    if (!m[0].includes("百度百科") && !m[0].includes("维基百科")) continue;
    for (const p of m[1].split(/\n+/).map((s) => s.trim()).filter((s) => s.length >= 40)) {
      baikeParas.push(p);
    }
  }
  if (baikeParas.length >= 3) return baikeParas;

  const cleaned = context
    .replace(/\[权威资料 \d+\]/g, "\n")
    .replace(/来源：[^\n]+/g, "")
    .replace(/可信度：[^\n]+/g, "")
    .replace(/正文：/g, "")
    .replace(/【[^】]+】/g, "\n");

  return cleaned
    .split(/\n+/)
    .map((p) => p.replace(/^[-·•]\s*/, "").trim())
    .filter((p) => p.length >= 40);
}

export function excerptForSlot(
  context: string,
  slotLabel: string,
  slotIndex: number,
  minLength = 180,
): string {
  const paragraphs = splitResearchParagraphs(context);
  if (!paragraphs.length) return "";

  const keywords = slotLabel.replace(/[^\u4e00-\u9fffA-Za-z0-9]/g, " ").split(/\s+/).filter(Boolean);
  const scored = paragraphs.map((p, i) => {
    let score = 0;
    for (const kw of keywords) {
      if (kw.length >= 2 && p.includes(kw)) score += 2;
    }
    score += (i + slotIndex) % 3 === 0 ? 1 : 0;
    return { p, score, i };
  });

  scored.sort((a, b) => b.score - a.score || a.i - b.i);

  const chunks: string[] = [];
  let total = 0;
  for (const { p } of scored) {
    if (chunks.includes(p)) continue;
    chunks.push(p);
    total += p.length;
    if (total >= minLength) break;
  }

  if (!chunks.length) {
    const start = (slotIndex * 2) % Math.max(paragraphs.length, 1);
    for (let i = 0; i < 3 && start + i < paragraphs.length; i++) {
      chunks.push(paragraphs[start + i]);
    }
  }

  const body = chunks.join("\n\n");
  if (!body) return "";

  const sourceNote = context.includes("baike.baidu.com")
    ? "（摘自百度百科等公开资料）"
    : context.includes("gov.cn")
      ? "（摘自政府公开信息）"
      : "（摘自公开资料）";

  return `${body}${sourceNote}`;
}

export function fillSectionFromResearch(
  context: string | undefined,
  sectionTitle: string,
  sectionIndex: number,
): string {
  if (!context?.trim()) return "";
  return excerptForSlot(context, sectionTitle, sectionIndex, 200);
}

export function fillReportStepFromResearch(
  context: string | undefined,
  stepTitle: string,
  stepIndex: number,
  field: "theory_tools" | "method_models" | "brand_practice" | "brand_case" | "summary_lessons",
): string {
  if (!context?.trim()) return "";

  const excerpt = excerptForSlot(context, `${stepTitle} ${field}`, stepIndex + field.length, 220);
  if (!excerpt) return "";

  const labels: Record<string, string> = {
    theory_tools: "理论参照",
    method_models: "方法参照",
    brand_practice: "公开资料所示实践",
    brand_case: "公开资料案例摘录",
    summary_lessons: "资料要点",
  };

  return `【${labels[field]}】${excerpt}`;
}
