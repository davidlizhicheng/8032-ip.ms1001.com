import {
  getRegistryDisambiguation,
  registryCandidatesAsPersonCandidates,
  resolveRegistryCandidate,
  type RegistryPersonCandidate,
} from "@/lib/search/person-disambiguation-registry";
import type { SearchResult } from "@/lib/search/web-search";

export type PersonCandidate = {
  id: string;
  label: string;
  title?: string;
  company?: string;
  snippet: string;
  url?: string;
  region?: string;
};

export type PersonDisambiguationResult = {
  needsConfirmation: boolean;
  riskLevel: "low" | "high";
  candidates: PersonCandidate[];
  reason?: string;
  allowCompare?: boolean;
  fromRegistry?: boolean;
};

/** 高频重名姓名（2-3 字常见名） */
const COMMON_NAMES = new Set([
  "张伟", "王伟", "李娜", "王芳", "刘伟", "李强", "王静", "李军", "王磊", "李杰",
  "张敏", "王涛", "李洋", "张磊", "王超", "李勇", "张军", "王勇", "李艳", "张涛",
  "王娟", "张超", "李敏", "王秀", "张丽", "李霞", "王玲", "张艳", "李丽", "王丹",
  "陈静", "陈明", "陈强", "刘洋", "刘敏", "赵敏", "赵强", "黄伟", "周杰", "吴磊",
]);

const IDENTITY_KEYWORDS = [
  "企业家", "创始人", "CEO", "董事长", "总裁", "教授", "博士", "律师", "医生",
  "演员", "歌手", "作家", "记者", "官员", "市长", "局长", "院士", "工程师",
  "设计师", "顾问", "主播", "网红", "运动员", "教练",
];

function extractIdentityHint(text: string): string | null {
  for (const kw of IDENTITY_KEYWORDS) {
    if (text.includes(kw)) return kw;
  }
  return null;
}

function buildCandidateFromResult(result: SearchResult, index: number): PersonCandidate {
  const combined = `${result.title} ${result.snippet}`;
  const titleMatch = combined.match(
    /(?:担任|任|为|是)([^，。；\n]{2,24}(?:董事长|CEO|总裁|创始人|教授|律师|医生|经理|总监|市长|秘书长))/,
  );
  const companyMatch = combined.match(
    /([\u4e00-\u9fffA-Za-z0-9（）()·]{2,20}(?:公司|集团|大学|学院|医院|研究所|基金会|市政府|人民政府))/,
  );

  return {
    id: `web-c${index}`,
    label: result.title.replace(/\s*[-_|].*$/, "").slice(0, 40) || `候选 ${index + 1}`,
    title: titleMatch?.[1],
    company: companyMatch?.[1],
    snippet: result.snippet.slice(0, 160),
    url: result.url,
  };
}

export function isCommonName(name: string): boolean {
  const trimmed = name.trim();
  return COMMON_NAMES.has(trimmed) || (trimmed.length === 2 && !trimmed.includes("·"));
}

/** 优先查注册表；注册表人物必须确认身份 */
export function analyzePersonDisambiguation(
  name: string,
  results: SearchResult[] = [],
): PersonDisambiguationResult {
  const registry = getRegistryDisambiguation(name);
  if (registry) {
    return {
      needsConfirmation: true,
      riskLevel: "high",
      candidates: registryCandidatesAsPersonCandidates(registry),
      reason: registry.question,
      allowCompare: registry.allowCompare,
      fromRegistry: true,
    };
  }

  return analyzePersonAmbiguityFromWeb(name, results);
}

export function analyzePersonAmbiguity(
  name: string,
  results: SearchResult[],
): PersonDisambiguationResult {
  return analyzePersonDisambiguation(name, results);
}

function analyzePersonAmbiguityFromWeb(
  name: string,
  results: SearchResult[],
): PersonDisambiguationResult {
  const candidates = results
    .slice(0, 8)
    .map((r, i) => buildCandidateFromResult(r, i))
    .filter((c) => c.snippet.length > 10);

  const identityHints = new Set<string>();
  for (const r of results.slice(0, 12)) {
    const hint = extractIdentityHint(`${r.title} ${r.snippet}`);
    if (hint) identityHints.add(hint);
  }

  const hasBaike = results.some((r) => r.url.includes("baike.baidu.com"));
  const common = isCommonName(name);
  const multiIdentity = identityHints.size >= 3;

  if (common && !hasBaike) {
    return {
      needsConfirmation: true,
      riskLevel: "high",
      candidates: dedupeCandidates(candidates),
      reason: `「${name}」是常见姓名，且未找到权威百科条目，请确认是以下哪一位。`,
    };
  }

  if (common && multiIdentity) {
    return {
      needsConfirmation: true,
      riskLevel: "high",
      candidates: dedupeCandidates(candidates),
      reason: `「${name}」检索到多种不同身份（${[...identityHints].slice(0, 4).join("、")}），请确认目标人物。`,
    };
  }

  if (multiIdentity && candidates.length >= 4) {
    return {
      needsConfirmation: true,
      riskLevel: "high",
      candidates: dedupeCandidates(candidates),
      reason: `网上关于「${name}」的信息指向多个不同人物，请确认后再生成。`,
    };
  }

  return { needsConfirmation: false, riskLevel: "low", candidates: [] };
}

export function resolvePersonCandidate(
  name: string,
  candidateId: string,
  webResults: SearchResult[] = [],
): { identityHint: string; candidate?: RegistryPersonCandidate } {
  const registryCandidate = resolveRegistryCandidate(name, candidateId);
  if (registryCandidate) {
    return { identityHint: registryCandidate.identityHint, candidate: registryCandidate };
  }

  const webCandidate = analyzePersonAmbiguityFromWeb(name, webResults).candidates.find(
    (c) => c.id === candidateId,
  );
  if (webCandidate) {
    return {
      identityHint: [webCandidate.label, webCandidate.title, webCandidate.company]
        .filter(Boolean)
        .join(" · "),
    };
  }

  return { identityHint: "" };
}

function dedupeCandidates(candidates: PersonCandidate[]): PersonCandidate[] {
  const seen = new Set<string>();
  return candidates.filter((c) => {
    const key = `${c.label}|${c.company || ""}|${c.title || ""}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
