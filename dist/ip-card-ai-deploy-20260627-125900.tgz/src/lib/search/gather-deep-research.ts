import { fetchNewsForEntity } from "@/lib/news/fetcher";
import {
  extractBaikeUrlsFromResults,
  fetchAllBaikeEntries,
  fetchBaikeFromUrl,
  fetchZhWikiEntry,
  formatEnrichedSource,
  rankBaikeEntries,
  type EnrichedSource,
} from "@/lib/search/baike-fetcher";
import { expandPersonSearchNames, getDirectBaikeUrls, isKnownFamousName } from "@/lib/search/person-name-aliases";
import {
  isWrongPersonBaikeEntry,
  sanitizeEnrichedSource,
} from "@/lib/search/baike-entry-filter";
import { decodeHtmlEntities } from "@/lib/content/decode-html";
import { fetchPageExcerpt } from "@/lib/search/page-fetcher";
import {
  formatSearchContext,
  searchWebMulti,
  type SearchResult,
} from "@/lib/search/web-search";
import type {
  ResearchBundle,
  ResearchProgressCallback,
  ResearchStep,
} from "@/lib/search/research-types";

function emit(onProgress: ResearchProgressCallback | undefined, step: ResearchStep) {
  onProgress?.(step);
}

function dedupeResults(results: SearchResult[]): SearchResult[] {
  const seen = new Set<string>();
  return results.filter((item) => {
    const key = item.url || item.title;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function authorityScore(url: string): number {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    if (host === "baike.baidu.com") return 100;
    if (host.includes("wikipedia.org")) return 95;
    if (host.endsWith(".gov.cn")) return 90;
    if (host.includes("people.com.cn") || host.includes("xinhuanet.com")) return 80;
    return 10;
  } catch {
    return 0;
  }
}

function buildSearchQueries(
  name: string,
  type: string,
  extraQueries: string[] = [],
): string[] {
  const base = [name, `${name} 简介`, `${name} 是谁`, `${name} 个人资料`];

  if (type === "person") {
    const aliasQueries = expandPersonSearchNames(name).flatMap((n) => [
      `${n} site:baike.baidu.com`,
      `${n} 百度百科`,
    ]);
    return [
      ...extraQueries,
      ...base,
      ...aliasQueries,
      `${name} site:zh.wikipedia.org`,
      `${name} 企业家 创业经历 简介`,
      `${name} 公司 职务 创始人`,
      `"${name}" 人物 简历`,
    ];
  }

  if (type === "city") {
    return [
      `${name} 城市 产业 定位`,
      `${name} 人民政府 site:gov.cn`,
      `${name} site:baike.baidu.com`,
      `${name} 招商引资 营商环境`,
      `${name} 代表企业`,
    ];
  }

  if (type === "company") {
    return [
      `${name} 公司 企业`,
      `${name} site:baike.baidu.com`,
      `${name} 创始人 产品`,
      `${name} 官网 品牌`,
      `${name} 新闻`,
    ];
  }

  return [
    ...base,
    `${name} site:baike.baidu.com`,
    `${name} 品牌`,
    `${name} 新闻`,
  ];
}

const LOW_QUALITY_PAGE_HOSTS = [
  "tags.sina.com.cn",
  "k.sina.cn",
  "36kr.com",
  "tech.ifeng.com",
  "news.qq.com",
  "baijiahao.baidu.com",
  "toutiao.com",
  "sohu.com",
];

function isGovPageUrl(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    return host.endsWith(".gov.cn");
  } catch {
    return false;
  }
}

function matchesExcludeKeywords(text: string, excludeKeywords: string[]): boolean {
  if (!excludeKeywords.length) return false;
  const lower = text.toLowerCase();
  return excludeKeywords.some((kw) => lower.includes(kw.toLowerCase()));
}

function isLowQualityPageUrl(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    return LOW_QUALITY_PAGE_HOSTS.some((h) => host === h || host.endsWith(`.${h}`));
  } catch {
    return false;
  }
}

function isPlaceholderNews(news: { title: string; excerpt?: string }): boolean {
  return (
    news.title.includes("待抓取") ||
    news.title.includes("相关人物动态") ||
    news.excerpt?.includes("待抓取") === true
  );
}

function baikeCharCount(entries: EnrichedSource[]): number {
  return entries.reduce((n, e) => n + (e.fullText?.length || 0), 0);
}

function hasRichBaike(entries: EnrichedSource[], wiki: EnrichedSource | null): boolean {
  return baikeCharCount(entries) >= 800 || (wiki?.fullText?.length || 0) >= 1200;
}

function shouldPreferBaikeOnly(
  name: string,
  entries: EnrichedSource[],
  wiki: EnrichedSource | null,
): boolean {
  return hasRichBaike(entries, wiki) || (isKnownFamousName(name) && entries.length > 0);
}

function capContext(parts: string[], maxChars = 38000): string {
  let text = parts.filter(Boolean).join("\n\n");
  if (text.length <= maxChars) return text;
  return `${text.slice(0, maxChars)}\n\n（资料已截断，优先保留百科与权威来源）`;
}

export async function gatherDeepResearch(
  name: string,
  type: string,
  options: {
    fetchNews?: boolean;
    onProgress?: ResearchProgressCallback;
    extraQueries?: string[];
    excludeKeywords?: string[];
    /** 人物检索时不抓政府门户首页 */
    skipGovPages?: boolean;
  } = {},
): Promise<ResearchBundle> {
  const steps: ResearchStep[] = [];
  const onProgress = (step: ResearchStep) => {
    steps.push(step);
    emit(options.onProgress, step);
  };

  const fetchNews = options.fetchNews !== false;
  const extraQueries = options.extraQueries || [];
  const excludeKeywords = options.excludeKeywords || [];
  const skipGovPages = options.skipGovPages ?? type === "person";

  onProgress({
    phase: "search",
    label: `开始检索「${name}」公开资料`,
    status: "running",
  });

  const queries = buildSearchQueries(name, type, extraQueries);
  onProgress({
    phase: "search",
    label: `联网检索 ${queries.length} 组关键词`,
    detail: queries.slice(0, 4).join(" · "),
    status: "running",
  });

  const [news, webResults, baikeEntries, wiki] = await Promise.all([
    fetchNews
      ? fetchNewsForEntity(name, type).then((items) => {
          onProgress({
            phase: "news",
            label: `新闻 RSS ${items.length} 条`,
            status: items.length ? "done" : "skipped",
          });
          return items;
        })
      : Promise.resolve([]),
    searchWebMulti(queries, 8, 45).then((items) => {
      onProgress({
        phase: "search",
        label: `网页检索完成，${items.length} 条结果`,
        status: "done",
      });
      return items;
    }),
    fetchAllBaikeEntries(name).then((entries) => {
      if (entries.length) {
        for (const entry of entries) {
          onProgress({
            phase: "baike",
            label: `百度百科：${entry.title.replace(/ - 百度百科$/, "")}`,
            url: entry.url,
            detail: `${entry.fullText?.length || 0} 字`,
            status: "done",
          });
        }
      } else {
        onProgress({
          phase: "baike",
          label: "未找到百度百科词条",
          status: "skipped",
        });
      }
      return entries;
    }),
    fetchZhWikiEntry(name).then((entry) => {
      if (entry) {
        onProgress({
          phase: "wiki",
          label: `维基百科：${name}`,
          url: entry.url,
          detail: `${entry.fullText?.length || 0} 字`,
          status: "done",
        });
      } else {
        onProgress({
          phase: "wiki",
          label: "未找到维基百科词条",
          status: "skipped",
        });
      }
      return entry;
    }),
  ]);

  onProgress({ phase: "merge", label: "合并检索结果", status: "running" });

  const baikeUrls = new Set(baikeEntries.map((e) => e.url));
  for (const url of extractBaikeUrlsFromResults(webResults)) {
    if (baikeUrls.has(url)) continue;
    const entry = await fetchBaikeFromUrl(url, name);
    if (entry) {
      baikeEntries.push(entry);
      baikeUrls.add(entry.url);
      onProgress({
        phase: "baike",
        label: `百度百科（检索补抓）：${entry.title.replace(/ - 百度百科$/, "")}`,
        url: entry.url,
        detail: `${entry.fullText?.length || 0} 字`,
        status: "done",
      });
      continue;
    }

    const snippetResult = webResults.find((r) => r.url.split("?")[0] === url.split("?")[0]);
    const directUrls = new Set(getDirectBaikeUrls(name));
    const isDirect = [...directUrls].some((u) => u.split("?")[0] === url.split("?")[0]);
    if (snippetResult?.snippet && snippetResult.snippet.length >= 80 && isDirect) {
      const fallbackEntry: EnrichedSource = sanitizeEnrichedSource({
        title: `${decodeHtmlEntities(snippetResult.title || name)} - 百度百科`,
        url: snippetResult.url,
        snippet: decodeHtmlEntities(snippetResult.snippet),
        fullText: decodeHtmlEntities(snippetResult.snippet),
        source: "baike.baidu.com",
        provider: "baike-snippet",
        sourceType: "baike",
        confidenceScore: 0.85,
      });
      if (isWrongPersonBaikeEntry(fallbackEntry, name)) continue;
      baikeEntries.push(fallbackEntry);
      baikeUrls.add(fallbackEntry.url);
      onProgress({
        phase: "baike",
        label: `百度百科（摘要兜底）：${name}`,
        url: fallbackEntry.url,
        detail: `${fallbackEntry.fullText?.length || 0} 字`,
        status: "done",
      });
    }
  }

  baikeEntries.splice(0, baikeEntries.length, ...rankBaikeEntries(baikeEntries, name));

  const richBaike = shouldPreferBaikeOnly(name, baikeEntries, wiki);
  const filteredWeb = webResults
    .filter((r) => !r.url.includes("baike.baidu.com") || !baikeUrls.has(r.url))
    .filter((r) => !skipGovPages || !isGovPageUrl(r.url))
    .filter(
      (r) => !matchesExcludeKeywords(`${r.title} ${r.snippet}`, excludeKeywords),
    );

  const fetchCandidates = [...filteredWeb]
    .sort((a, b) => authorityScore(b.url) - authorityScore(a.url))
    .filter((r) => authorityScore(r.url) >= 10)
    .filter((r) => !richBaike || !isLowQualityPageUrl(r.url))
    .filter((r) => !skipGovPages || !isGovPageUrl(r.url))
    .slice(0, richBaike ? 3 : 8);

  const pageExcerpts: EnrichedSource[] = [];
  const pageFetchLimit = richBaike ? 2 : 6;
  for (const candidate of fetchCandidates.slice(0, pageFetchLimit)) {
    onProgress({
      phase: "page",
      label: `抓取正文：${candidate.title.slice(0, 40)}`,
      url: candidate.url,
      status: "running",
    });
    const excerpt = await fetchPageExcerpt(candidate.url, candidate.title);
    if (excerpt) {
      if (skipGovPages && isGovPageUrl(excerpt.url)) continue;
      if (
        matchesExcludeKeywords(
          `${excerpt.title} ${excerpt.fullText || excerpt.snippet}`,
          excludeKeywords,
        )
      ) {
        continue;
      }
      pageExcerpts.push(excerpt);
      onProgress({
        phase: "page",
        label: `已抓取：${excerpt.title.slice(0, 40)}`,
        url: excerpt.url,
        detail: `${excerpt.fullText?.length || 0} 字`,
        status: "done",
      });
    } else {
      onProgress({
        phase: "page",
        label: `跳过（无法解析）：${candidate.title.slice(0, 30)}`,
        url: candidate.url,
        status: "skipped",
      });
    }
  }

  const baikeBlocks = baikeEntries.map((e, i) => formatEnrichedSource(e, i + 1));
  const wikiBlock = wiki ? formatEnrichedSource(wiki, baikeEntries.length + 1) : "";

  const realNews = news.filter((n) => !isPlaceholderNews(n));
  const newsBlock =
    !richBaike && realNews.length
      ? `【新闻报道 ${realNews.length} 条（仅作近期动态参考，不得替代百科正文）】\n${realNews
          .map(
            (n, i) =>
              `[新闻 ${i + 1}] ${n.title}\n来源：${n.source || "新闻"}\n链接：${n.url}${n.excerpt ? `\n摘要：${n.excerpt}` : ""}`,
          )
          .join("\n\n")}`
      : "";

  const webBlock =
    !richBaike && filteredWeb.length
      ? `【联网检索 ${filteredWeb.length} 条】\n${formatSearchContext(filteredWeb.slice(0, 12))}`
      : "";

  const pageBlock =
    !richBaike && pageExcerpts.length
      ? `【网页正文摘录 ${pageExcerpts.length} 篇】\n${pageExcerpts
          .map((p, i) => formatEnrichedSource(p, i + 1))
          .join("\n\n")}`
      : "";

  const personHasBaike = type === "person" && (baikeEntries.length > 0 || Boolean(wiki?.fullText));
  const cityHasBaike = type === "city" && (baikeEntries.length > 0 || Boolean(wiki?.fullText));
  const contextText = personHasBaike || cityHasBaike
    ? capContext([baikeBlocks.join("\n\n"), wikiBlock])
    : capContext([baikeBlocks.join("\n\n"), wikiBlock, newsBlock, pageBlock, webBlock]);

  const mergedWeb: SearchResult[] = dedupeResults([
    ...baikeEntries.map((e) => ({
      title: e.title,
      url: e.url,
      snippet: e.snippet,
      source: e.source,
      provider: e.provider,
    })),
    ...(wiki
      ? [{ title: wiki.title, url: wiki.url, snippet: wiki.snippet, source: wiki.source, provider: wiki.provider }]
      : []),
    ...filteredWeb,
  ]);

  onProgress({
    phase: "merge",
    label: `资料合并完成，共 ${baikeEntries.length + (wiki ? 1 : 0) + news.length + mergedWeb.length} 条来源`,
    detail: `上下文 ${contextText.length} 字`,
    status: "done",
  });

  return {
    news,
    webResults: mergedWeb,
    baikeEntries,
    wiki,
    pageExcerpts,
    contextText,
    sourceCount: news.length + mergedWeb.length + pageExcerpts.length,
    steps,
  };
}
