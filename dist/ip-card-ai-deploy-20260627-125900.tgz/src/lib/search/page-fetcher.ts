import type { EnrichedSource } from "@/lib/search/baike-fetcher";

const USER_AGENT = "Mozilla/5.0 (compatible; BrandNet/1.0; +https://brandnet.local)";

function stripHtml(value: string): string {
  return value
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim();
}

function trimText(value: string, limit: number): string {
  if (value.length <= limit) return value;
  return `${value.slice(0, limit)}…`;
}

export async function fetchPageExcerpt(
  url: string,
  titleHint: string,
): Promise<EnrichedSource | null> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": USER_AGENT, Accept: "text/html" },
      cache: "no-store",
      redirect: "follow",
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return null;

    const html = await res.text();
    const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const title = stripHtml(titleMatch?.[1] || titleHint).slice(0, 120) || titleHint;

    const paragraphs = [...html.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)]
      .map((m) => stripHtml(m[1]))
      .filter((t) => t.length > 30 && !t.includes("cookie") && !t.includes("javascript"))
      .slice(0, 20);

    const body = trimText(paragraphs.join("\n"), 6000);
    if (body.length < 80) return null;

    let host = "web";
    try {
      host = new URL(url).hostname.replace(/^www\./, "");
    } catch {
      /* ignore */
    }

    return {
      title,
      url,
      snippet: trimText(body, 300),
      fullText: body,
      source: host,
      provider: "page-fetch",
      sourceType: host.endsWith(".gov.cn") ? "gov" : "web",
      confidenceScore: host.endsWith(".gov.cn") ? 0.9 : 0.65,
    };
  } catch {
    return null;
  }
}
