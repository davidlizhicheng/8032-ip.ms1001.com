import { decodeHtmlEntities } from "@/lib/content/decode-html";

export type SearchResult = {
  title: string;
  url: string;
  snippet: string;
  source?: string;
  provider: string;
};

export type WebSearchOptions = {
  limit?: number;
  type?: string;
  includeBaikeQuery?: boolean;
  /** 直接使用原始检索词，不拼接类型提示 */
  rawQuery?: string;
};

const USER_AGENT = "Mozilla/5.0 (compatible; BrandNet/1.0; +https://brandnet.local)";

function buildQuery(name: string, type?: string): string {
  const typeHint =
    type === "city"
      ? "城市 产业 定位"
      : type === "company"
        ? "企业 公司 品牌"
        : type === "person"
          ? "人物 企业家 简介"
          : type === "brand"
            ? "品牌 产品"
            : "";
  return [name, typeHint].filter(Boolean).join(" ").trim();
}

export async function searchWeb(
  name: string,
  options: WebSearchOptions = {},
): Promise<SearchResult[]> {
  const query = options.rawQuery || buildQuery(name, options.type);
  const limit = options.limit ?? 12;
  const includeBaike = options.includeBaikeQuery !== false && !options.rawQuery;

  const baikeQuery = `${name} site:baike.baidu.com`;
  const govQuery =
    options.type === "city"
      ? `${name} 人民政府 site:gov.cn`
      : options.type === "company"
        ? `${name} 官网`
        : `${name} 简介`;

  const searchTasks: Array<() => Promise<SearchResult[]>> = [
    () => searchWithSerper(query, limit),
    () => searchWithTavily(query, limit),
    () => searchWithBingCn(query, limit),
    () => searchWithDuckDuckGo(query, limit),
  ];

  if (includeBaike) {
    searchTasks.unshift(
      () => searchWithBingCn(baikeQuery, 5),
      () => searchWithBingCn(govQuery, 4),
    );
  }

  const merged: SearchResult[] = [];
  const seen = new Set<string>();

  for (const task of searchTasks) {
    if (merged.length >= limit) break;
    try {
      const results = await task();
      for (const item of results) {
        const key = item.url || item.title;
        if (seen.has(key)) continue;
        seen.add(key);
        merged.push(item);
      }
    } catch (error) {
      console.warn("[web-search] provider failed:", error);
    }
  }

  return rankByAuthority(merged).slice(0, limit);
}

/** 多路检索：并行执行多条 query 并去重合并 */
export async function searchWebMulti(
  queries: string[],
  limitPerQuery = 8,
  totalLimit = 40,
): Promise<SearchResult[]> {
  const merged: SearchResult[] = [];
  const seen = new Set<string>();

  const results = await Promise.all(
    queries.map((q) =>
      searchWeb(q, { rawQuery: q, limit: limitPerQuery, includeBaikeQuery: false }).catch(
        () => [] as SearchResult[],
      ),
    ),
  );

  for (const list of results) {
    for (const item of list) {
      const key = item.url || item.title;
      if (seen.has(key)) continue;
      seen.add(key);
      merged.push(item);
      if (merged.length >= totalLimit) break;
    }
    if (merged.length >= totalLimit) break;
  }

  return rankByAuthority(merged).slice(0, totalLimit);
}

function rankByAuthority(results: SearchResult[]): SearchResult[] {
  return [...results].sort((a, b) => scoreUrl(b.url) - scoreUrl(a.url));
}

function scoreUrl(url: string): number {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    if (host === "baike.baidu.com") return 100;
    if (host.endsWith(".gov.cn")) return 90;
    if (host.includes("people.com.cn") || host.includes("xinhuanet.com")) return 80;
    if (host.includes("wikipedia.org")) return 75;
    return 0;
  } catch {
    return 0;
  }
}

export function isWebSearchConfigured(): boolean {
  return Boolean(
    process.env.SERPER_API_KEY ||
      process.env.TAVILY_API_KEY ||
      process.env.JINA_API_KEY,
  );
}

async function searchWithSerper(query: string, limit: number): Promise<SearchResult[]> {
  const apiKey = process.env.SERPER_API_KEY;
  if (!apiKey) return [];

  const res = await fetch("https://google.serper.dev/search", {
    method: "POST",
    headers: {
      "X-API-KEY": apiKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ q: query, gl: "cn", hl: "zh-cn", num: limit }),
  });

  if (!res.ok) throw new Error(`Serper ${res.status}`);

  const data = (await res.json()) as {
    organic?: Array<{ title?: string; link?: string; snippet?: string }>;
  };

  return (data.organic || [])
    .filter((item) => item.title && item.link)
    .map((item) => ({
      title: item.title!,
      url: item.link!,
      snippet: item.snippet || "",
      source: extractDomain(item.link!),
      provider: "serper",
    }));
}

async function searchWithTavily(query: string, limit: number): Promise<SearchResult[]> {
  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) return [];

  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: apiKey,
      query,
      search_depth: "basic",
      max_results: limit,
      include_answer: false,
    }),
  });

  if (!res.ok) throw new Error(`Tavily ${res.status}`);

  const data = (await res.json()) as {
    results?: Array<{ title?: string; url?: string; content?: string }>;
  };

  return (data.results || [])
    .filter((item) => item.title && item.url)
    .map((item) => ({
      title: item.title!,
      url: item.url!,
      snippet: (item.content || "").slice(0, 300),
      source: extractDomain(item.url!),
      provider: "tavily",
    }));
}

async function searchWithBingCn(query: string, limit: number): Promise<SearchResult[]> {
  const url = `https://cn.bing.com/search?q=${encodeURIComponent(query)}&setlang=zh-Hans`;

  const res = await fetch(url, {
    headers: {
      "User-Agent": USER_AGENT,
      Accept: "text/html,application/xhtml+xml",
    },
    cache: "no-store",
  });

  if (!res.ok) throw new Error(`Bing CN ${res.status}`);

  const html = await res.text();
  return parseBingHtml(html, limit);
}

function parseBingHtml(html: string, limit: number): SearchResult[] {
  const results: SearchResult[] = [];
  const seen = new Set<string>();

  const resultRegex =
    /<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a><\/h2>\s*<div class="b_caption"><p[^>]*>([\s\S]*?)<\/p>/g;

  let match;
  while ((match = resultRegex.exec(html)) !== null && results.length < limit) {
    const url = match[1];
    const title = stripHtml(match[2]);
    const snippet = stripHtml(match[3]);

    if (!url.startsWith("http") || !title || seen.has(url)) continue;
    seen.add(url);

    results.push({
      title,
      url,
      snippet: snippet || title,
      source: extractDomain(url),
      provider: "bing-cn",
    });
  }

  return results;
}

async function searchWithDuckDuckGo(query: string, limit: number): Promise<SearchResult[]> {
  const body = new URLSearchParams({ q: query, kl: "cn-zh" });

  const res = await fetch("https://html.duckduckgo.com/html/", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent": USER_AGENT,
    },
    body: body.toString(),
    cache: "no-store",
  });

  if (!res.ok) throw new Error(`DuckDuckGo ${res.status}`);

  const html = await res.text();
  return parseDuckDuckGoHtml(html, limit);
}

function parseDuckDuckGoHtml(html: string, limit: number): SearchResult[] {
  const results: SearchResult[] = [];
  const blockRegex = /<a rel="nofollow" class="result__a" href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  const snippetRegex = /<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;

  const links: Array<{ url: string; title: string }> = [];
  let match;
  while ((match = blockRegex.exec(html)) !== null) {
    links.push({
      url: decodeDuckDuckGoUrl(match[1]),
      title: stripHtml(match[2]),
    });
  }

  const snippets: string[] = [];
  while ((match = snippetRegex.exec(html)) !== null) {
    snippets.push(stripHtml(match[1]));
  }

  for (let i = 0; i < Math.min(links.length, limit); i++) {
    const link = links[i];
    if (!link.url || !link.title) continue;
    results.push({
      title: link.title,
      url: link.url,
      snippet: snippets[i] || link.title,
      source: extractDomain(link.url),
      provider: "duckduckgo",
    });
  }

  return results;
}

function decodeDuckDuckGoUrl(raw: string): string {
  try {
    const uddg = raw.match(/uddg=([^&]+)/)?.[1];
    if (uddg) return decodeURIComponent(uddg);
    if (raw.startsWith("http")) return raw;
  } catch {
    // fall through
  }
  return raw;
}

function stripHtml(value: string): string {
  return decodeHtmlEntities(
    value
      .replace(/<[^>]+>/g, "")
      .replace(/\s+/g, " ")
      .trim(),
  );
}

function extractDomain(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "web";
  }
}

export function formatSearchContext(results: SearchResult[]): string {
  if (!results.length) return "";

  return results
    .map(
      (item, index) =>
        `[资料 ${index + 1}] ${item.title}\n来源：${item.source || item.provider}\n链接：${item.url}\n摘要：${item.snippet}`,
    )
    .join("\n\n");
}
