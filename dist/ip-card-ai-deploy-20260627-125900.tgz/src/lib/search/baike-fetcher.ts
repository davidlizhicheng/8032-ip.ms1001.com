import type { SearchResult } from "@/lib/search/web-search";
import { decodeHtmlEntities } from "@/lib/content/decode-html";
import {
  isWrongPersonBaikeEntry,
  sanitizeEnrichedSource,
} from "@/lib/search/baike-entry-filter";
import { expandPersonSearchNames, getDirectBaikeUrls } from "@/lib/search/person-name-aliases";

const USER_AGENT = "Mozilla/5.0 (compatible; BrandNet/1.0; +https://brandnet.local)";

export type EnrichedSource = SearchResult & {
  fullText?: string;
  sourceType: "baike" | "gov" | "wiki" | "web";
  confidenceScore: number;
};

function stripHtml(value: string): string {
  return decodeHtmlEntities(
    value
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<[^>]+>/g, "")
      .replace(/\s+/g, " ")
      .trim(),
  );
}

function trimText(value: string, limit: number): string {
  if (value.length <= limit) return value;
  return `${value.slice(0, limit)}…`;
}

async function fetchPageText(url: string): Promise<string> {
  const res = await fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
      Referer: "https://www.baidu.com/",
    },
    cache: "no-store",
    redirect: "follow",
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) return "";
  return res.text();
}

function parseBaikeHtml(html: string, url: string, title: string): EnrichedSource | null {
  const summaryMatch =
    html.match(/class="lemmaSummary[^"]*"[^>]*>([\s\S]*?)<\/div>/i) ||
    html.match(/data-tag="summary"[^>]*>([\s\S]*?)<\/div>/i);

  const paraMatches = [
    ...html.matchAll(/data-tag="paragraph"[^>]*>([\s\S]*?)<\/div>/gi),
    ...html.matchAll(/class="para[^"]*"[^>]*>([\s\S]*?)<\/div>/gi),
  ]
    .map((m) => stripHtml(m[1]))
    .filter((t) => t.length > 15)
    .slice(0, 40);

  const summary = summaryMatch ? stripHtml(summaryMatch[1]) : "";
  const body = paraMatches.join("\n");
  const fullText = trimText([summary, body].filter(Boolean).join("\n\n"), 20000);

  if (!fullText || fullText.length < 40) return null;

  const pageTitle =
    html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.replace(/_百度百科.*$/, "").trim() ||
    title;

  return sanitizeEnrichedSource({
    title: `${decodeHtmlEntities(pageTitle)} - 百度百科`,
    url,
    snippet: trimText(summary || fullText, 400),
    fullText,
    source: "baike.baidu.com",
    provider: "baike",
    sourceType: "baike",
    confidenceScore: 0.95,
  });
}

function parseWikiHtml(html: string, url: string, title: string): EnrichedSource | null {
  const paras = [...html.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)]
    .map((m) => stripHtml(m[1]))
    .filter((t) => t.length > 30)
    .slice(0, 35);
  const body = trimText(paras.join("\n"), 18000);
  if (body.length < 60) return null;

  return {
    title: `${title} - 维基百科`,
    url,
    snippet: trimText(body, 400),
    fullText: body,
    source: "zh.wikipedia.org",
    provider: "wikipedia",
    sourceType: "wiki",
    confidenceScore: 0.92,
  };
}

async function findBaikeUrlsViaBing(name: string): Promise<string[]> {
  const queries = [
    `${name} site:baike.baidu.com`,
    `"${name}" site:baike.baidu.com`,
    `${name} 百度百科`,
  ];
  const urls = new Set<string>();

  for (const query of queries) {
    try {
      const searchUrl = `https://cn.bing.com/search?q=${encodeURIComponent(query)}&setlang=zh-Hans`;
      const res = await fetch(searchUrl, {
        headers: { "User-Agent": USER_AGENT, Accept: "text/html" },
        cache: "no-store",
      });
      if (!res.ok) continue;
      const html = await res.text();
      const matches = [...html.matchAll(/https:\/\/baike\.baidu\.com\/item\/[^"&\s]+/g)];
      for (const m of matches) {
        urls.add(m[0].replace(/&amp;/g, "&").split("?")[0]);
      }
    } catch {
      /* try next */
    }
  }

  return [...urls].slice(0, 6);
}

/** 直接访问百度百科词条页 */
export async function fetchBaikeEntry(name: string): Promise<EnrichedSource | null> {
  const candidates = [
    `https://baike.baidu.com/item/${encodeURIComponent(name)}`,
    `https://baike.baidu.com/item/${encodeURIComponent(`${name}（人物）`)}`,
    `https://baike.baidu.com/item/${encodeURIComponent(`${name}（企业家）`)}`,
    `https://baike.baidu.com/item/${encodeURIComponent(`${name}（公司）`)}`,
  ];

  let best: EnrichedSource | null = null;
  let bestScore = -1;

  for (const url of candidates) {
    try {
      const entry = await fetchBaikeFromUrl(url, name);
      if (!entry) continue;
      const score = baikeEntryScore(entry, name, expandPersonSearchNames(name));
      if (score > bestScore) {
        bestScore = score;
        best = entry;
      }
    } catch {
      /* try next */
    }
  }

  return best;
}

function extractLemmaId(url: string): string | null {
  return url.match(/\/(\d+)\/?(?:\?|$)/)?.[1] || null;
}

async function fetchBaikeViaOpenApi(lemmaTitle: string, lemmaId?: string): Promise<EnrichedSource | null> {
  const params = lemmaId
    ? `lemmaId=${lemmaId}`
    : `lemmaTitle=${encodeURIComponent(lemmaTitle)}`;
  const apiUrl = `https://baike.baidu.com/api/openapi/BkItemCard?${params}`;

  try {
    const res = await fetch(apiUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
        Referer: "https://baike.baidu.com/",
        Accept: "application/json",
      },
      cache: "no-store",
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      data?: {
        lemmaTitle?: string;
        lemmaDesc?: string;
        url?: string;
        summary?: string;
        abstract?: string;
      };
    };
    const card = data?.data;
    const body = [card?.lemmaDesc, card?.summary, card?.abstract].filter(Boolean).join("\n\n");
    if (!body || body.length < 40) return null;

    const title = card?.lemmaTitle || lemmaTitle;
    const url =
      card?.url ||
      (lemmaId
        ? `https://baike.baidu.com/item/${encodeURIComponent(title)}/${lemmaId}`
        : `https://baike.baidu.com/item/${encodeURIComponent(title)}`);

    return sanitizeEnrichedSource({
      title: `${title} - 百度百科`,
      url,
      snippet: trimText(body, 400),
      fullText: trimText(body, 20000),
      source: "baike.baidu.com",
      provider: "baike-api",
      sourceType: "baike",
      confidenceScore: 0.93,
    });
  } catch {
    return null;
  }
}

export async function fetchBaikeFromUrl(url: string, name: string): Promise<EnrichedSource | null> {
  try {
    const html = await fetchPageText(url);
    if (html.includes("lemmaSummary") || html.includes("data-tag=\"paragraph\"")) {
      const entry = parseBaikeHtml(html, url, name);
      if (entry && !isWrongPersonBaikeEntry(entry, name)) return entry;
    }

    const mobileUrl = url.replace("baike.baidu.com/item/", "m.baike.baidu.com/item/");
    if (mobileUrl !== url) {
      const mobileHtml = await fetchPageText(mobileUrl);
      if (mobileHtml.includes("lemmaSummary") || mobileHtml.includes("data-tag=\"paragraph\"")) {
        const entry = parseBaikeHtml(mobileHtml, url, name);
        if (entry && !isWrongPersonBaikeEntry(entry, name)) return entry;
      }
    }

    const lemmaId = extractLemmaId(url);
    const searchNames = expandPersonSearchNames(name);
    for (const candidate of searchNames) {
      const apiEntry = await fetchBaikeViaOpenApi(candidate, lemmaId || undefined);
      if (apiEntry && !isWrongPersonBaikeEntry(apiEntry, name)) return apiEntry;
    }
  } catch {
    /* fall through */
  }
  return null;
}

export function extractBaikeUrlsFromResults(results: SearchResult[]): string[] {
  const urls = new Set<string>();
  for (const item of results) {
    const match = item.url.match(/https:\/\/baike\.baidu\.com\/item\/[^?\s#]+/);
    if (match) urls.add(match[0].replace(/&amp;/g, "&"));
  }
  return [...urls];
}

export function rankBaikeEntries(entries: EnrichedSource[], name: string): EnrichedSource[] {
  const searchNames = expandPersonSearchNames(name);
  const scored = entries
    .filter((entry) => !isWrongPersonBaikeEntry(entry, name))
    .map((entry) => ({
      entry: sanitizeEnrichedSource(entry),
      score: baikeEntryScore(entry, name, searchNames),
    }))
    .sort((a, b) => b.score - a.score);

  const qualified = scored.filter(({ score }) => score >= 30);
  const picked = (qualified.length ? qualified : scored.slice(0, 1)).slice(0, 2);
  return picked.map(({ entry }) => entry);
}

function decodeTitle(title: string): string {
  return decodeHtmlEntities(title);
}

function baikeEntryScore(entry: EnrichedSource, name: string, searchNames: string[]): number {
  const title = decodeTitle(entry.title.replace(/ - 百度百科$/, ""));
  const textLen = entry.fullText?.length || 0;
  let score = Math.min(textLen / 50, 80);

  for (const n of searchNames) {
    if (title === n || title.startsWith(`${n}（`)) score += 120;
    else if (title.includes(n)) score += 40;
  }

  const titleMatchesName = searchNames.some(
    (n) => title === n || title.startsWith(`${n}（`) || title.includes(n),
  );
  if (!titleMatchesName) score -= 100;

  if (/（\d{4}年.*出版|出版的图书|传记作家|人物传记|小说|电影|歌曲|专辑|游戏|公司$|集团$|有限公司$/.test(title)) {
    score -= 80;
  }
  if (/（人物）|（企业家）|（.*?家）|（.*?员）/.test(title)) {
    score += 30;
  }

  return score;
}

export async function fetchAllBaikeEntries(name: string): Promise<EnrichedSource[]> {
  const entries: EnrichedSource[] = [];
  const seen = new Set<string>();
  const searchNames = expandPersonSearchNames(name);

  const push = (entry: EnrichedSource | null) => {
    if (!entry || seen.has(entry.url)) return;
    seen.add(entry.url);
    entries.push(entry);
  };

  for (const candidate of searchNames) {
    push(await fetchBaikeEntry(candidate));
  }

  for (const url of getDirectBaikeUrls(name)) {
    if (seen.has(url)) continue;
    push(await fetchBaikeFromUrl(url, name));
  }

  for (const candidate of searchNames) {
    if (!entries.length) {
      push(await fetchBaikeViaOpenApi(candidate));
    }
  }

  for (const candidate of searchNames) {
    const urls = await findBaikeUrlsViaBing(candidate);
    for (const url of urls) {
      if (seen.has(url)) continue;
      push(await fetchBaikeFromUrl(url, name));
    }
  }

  if (!entries.length) {
    push(await fetchBaikeViaSearch(name));
  }

  return entries
    .filter((e) => !isWrongPersonBaikeEntry(e, name))
    .map((e) => sanitizeEnrichedSource(e))
    .sort(
      (a, b) => baikeEntryScore(b, name, searchNames) - baikeEntryScore(a, name, searchNames),
    );
}

/** 从 Bing 找到百科链接并抓取正文 */
export async function fetchBaikeViaSearch(name: string): Promise<EnrichedSource | null> {
  const urls = await findBaikeUrlsViaBing(name);
  for (const baikeUrl of urls) {
    try {
      const pageHtml = await fetchPageText(baikeUrl);
      const entry = parseBaikeHtml(pageHtml, baikeUrl, name);
      if (entry) return entry;
    } catch {
      /* try next */
    }
  }
  return null;
}

export async function fetchZhWikiEntry(name: string): Promise<EnrichedSource | null> {
  const candidates = [
    `https://zh.wikipedia.org/wiki/${encodeURIComponent(name.replace(/ /g, "_"))}`,
    `https://zh.wikipedia.org/wiki/${encodeURIComponent(name)}`,
  ];

  for (const url of candidates) {
    try {
      const html = await fetchPageText(url);
      if (!html.includes("mw-parser-output")) continue;
      const entry = parseWikiHtml(html, url, name);
      if (entry) return entry;
    } catch {
      /* try next */
    }
  }

  try {
    const searchUrl = `https://cn.bing.com/search?q=${encodeURIComponent(`${name} site:zh.wikipedia.org`)}`;
    const res = await fetch(searchUrl, {
      headers: { "User-Agent": USER_AGENT },
      cache: "no-store",
    });
    if (res.ok) {
      const html = await res.text();
      const link = html.match(/https:\/\/zh\.wikipedia\.org\/wiki\/[^"&\s]+/)?.[0];
      if (link) {
        const pageHtml = await fetchPageText(link.replace(/&amp;/g, "&"));
        return parseWikiHtml(pageHtml, link, name);
      }
    }
  } catch {
    /* ignore */
  }

  return null;
}

export async function fetchWikiFromUrl(url: string, fallbackTitle: string): Promise<EnrichedSource | null> {
  try {
    const html = await fetchPageText(url);
    if (!html.includes("mw-parser-output")) return null;
    const title = decodeURIComponent(url.split("/wiki/")[1] || fallbackTitle).replace(/_/g, " ");
    return parseWikiHtml(html, url, title);
  } catch {
    return null;
  }
}

export async function getBaikeResearch(name: string): Promise<EnrichedSource | null> {
  const all = await fetchAllBaikeEntries(name);
  return all[0] || null;
}

export function formatEnrichedSource(source: EnrichedSource, index: number): string {
  const clean = sanitizeEnrichedSource(source);
  const body = clean.fullText || clean.snippet;
  const sourceLabel =
    source.sourceType === "baike"
      ? "百度百科"
      : source.sourceType === "wiki"
        ? "维基百科"
        : source.sourceType === "gov"
          ? "政府官网"
          : source.source || "网页";
  return `[权威资料 ${index}] ${clean.title}
来源：${sourceLabel}（${clean.url}）
可信度：${(source.confidenceScore * 100).toFixed(0)}%
正文：
${body}`;
}

export function formatWikiSource(source: EnrichedSource, index: number): string {
  return formatEnrichedSource(source, index).replace("百度百科", "维基百科");
}
