import { decodeHtmlEntities } from "@/lib/content/decode-html";
import {
  fetchAllBaikeEntries,
  fetchBaikeFromUrl,
  fetchZhWikiEntry,
  type EnrichedSource,
} from "@/lib/search/baike-fetcher";
import type { PersonCandidate } from "@/lib/search/disambiguate-person";
import {
  getRegistryDisambiguation,
  resolveRegistryCandidate,
  type RegistryPersonCandidate,
} from "@/lib/search/person-disambiguation-registry";

const USER_AGENT = "Mozilla/5.0 (compatible; BrandNet/1.0; +https://brandnet.local)";

export type EncyclopediaLookupResult = {
  name: string;
  candidates: PersonCandidate[];
  reason: string;
  allowCompare: boolean;
  sourcesSearched: string[];
  /** 人物检索后必须先确认，再进入生成步骤 */
  needsConfirmation: true;
};

function extractCoreFields(text: string) {
  const region =
    text.match(/(?:籍贯|出生地|生于|出生于)[：:\s]*([\u4e00-\u9fff]{2,12})/)?.[1] ||
    text.match(/([\u4e00-\u9fff]{2,6}(?:省|市|自治区|特别行政区))/)?.[1] ||
    text.match(/(深圳|广州|北京|上海|杭州|成都|武汉|合肥|南京|西安|重庆|天津|苏州|东莞)/)?.[1];
  const occupation =
    text.match(
      /([^，。；\n]{2,24}(?:家|员|士|长|官|教授|博士|工程师|顾问|创始人|董事长|CEO|总裁|秘书长|市长|局长|院士|律师|医生|演员|歌手|作家|记者|教练|运动员))/,
    )?.[1];
  const org =
    text.match(
      /([\u4e00-\u9fffA-Za-z0-9（）()·]{2,28}(?:公司|集团|大学|学院|政府|学会|协会|研究院|基金会|委员会|人民政府|特区政府))/,
    )?.[1];
  return { region, occupation, org };
}

function candidateIdForEntry(entry: EnrichedSource): string {
  return `${entry.sourceType}:${encodeURIComponent(entry.url.split("?")[0])}`;
}

function entryToCandidate(entry: EnrichedSource, name: string): PersonCandidate {
  const pageTitle = decodeHtmlEntities(
    entry.title.replace(/ - (百度百科|维基百科)$/, "").trim(),
  );
  const text = entry.fullText || entry.snippet;
  const { region, occupation, org } = extractCoreFields(text);
  const baseName = name.trim();

  let label = pageTitle;
  if (pageTitle === baseName || pageTitle.startsWith(`${baseName}（`)) {
    const parts = [pageTitle.startsWith(`${baseName}（`) ? pageTitle : baseName];
    if (region) parts.push(region);
    if (occupation && !pageTitle.includes(occupation)) parts.push(occupation);
    label = parts.join(" · ");
  }

  const sourceLabel = entry.sourceType === "wiki" ? "维基百科" : "百度百科";

  return {
    id: candidateIdForEntry(entry),
    label,
    title: occupation,
    company: org,
    region,
    snippet: `[${sourceLabel}] ${entry.snippet.slice(0, 180)}`,
    url: entry.url,
  };
}

function dedupeCandidates(candidates: PersonCandidate[]): PersonCandidate[] {
  const seen = new Set<string>();
  return candidates.filter((c) => {
    const key = `${c.label}|${c.url || ""}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function findWikiEntriesViaBing(name: string): Promise<EnrichedSource[]> {
  const queries = [`${name} site:zh.wikipedia.org`, `"${name}" site:zh.wikipedia.org`];
  const urls = new Set<string>();
  const entries: EnrichedSource[] = [];

  for (const query of queries) {
    try {
      const searchUrl = `https://cn.bing.com/search?q=${encodeURIComponent(query)}&setlang=zh-Hans`;
      const res = await fetch(searchUrl, {
        headers: { "User-Agent": USER_AGENT, Accept: "text/html" },
        cache: "no-store",
      });
      if (!res.ok) continue;
      const html = await res.text();
      for (const m of html.matchAll(/https:\/\/zh\.wikipedia\.org\/wiki\/[^"&\s#]+/g)) {
        urls.add(m[0].replace(/&amp;/g, "&").split("#")[0]);
      }
    } catch {
      /* try next */
    }
  }

  for (const url of [...urls].slice(0, 4)) {
    try {
      const res = await fetch(url, {
        headers: { "User-Agent": USER_AGENT },
        cache: "no-store",
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) continue;
      const html = await res.text();
      if (!html.includes("mw-parser-output")) continue;
      const paras = [...html.matchAll(/<p[^>]*>([\s\S]*?)<\/p>/gi)]
        .map((match) =>
          decodeHtmlEntities(
            match[1]
              .replace(/<[^>]+>/g, "")
              .replace(/\s+/g, " ")
              .trim(),
          ),
        )
        .filter((t) => t.length > 30)
        .slice(0, 20);
      const body = paras.join("\n");
      if (body.length < 60) continue;
      const title = decodeURIComponent(url.split("/wiki/")[1] || name).replace(/_/g, " ");
      entries.push({
        title: `${title} - 维基百科`,
        url,
        snippet: body.slice(0, 400),
        fullText: body.slice(0, 18000),
        source: "zh.wikipedia.org",
        provider: "wikipedia",
        sourceType: "wiki",
        confidenceScore: 0.92,
      });
    } catch {
      /* try next */
    }
  }

  return entries;
}

/** 从百度百科 + 维基百科检索人物条目，用于第一步身份确认 */
export async function lookupPersonCandidatesFromEncyclopedia(
  name: string,
): Promise<EncyclopediaLookupResult> {
  const trimmed = name.trim();
  const sourcesSearched: string[] = [];
  const entries: EnrichedSource[] = [];
  const seenUrls = new Set<string>();

  const pushEntry = (entry: EnrichedSource | null) => {
    if (!entry) return;
    const url = entry.url.split("?")[0];
    if (seenUrls.has(url)) return;
    seenUrls.add(url);
    entries.push(entry);
  };

  const baikeEntries = await fetchAllBaikeEntries(trimmed);
  sourcesSearched.push("百度百科");
  for (const entry of baikeEntries) pushEntry(entry);

  pushEntry(await fetchZhWikiEntry(trimmed));
  sourcesSearched.push("维基百科");

  for (const entry of await findWikiEntriesViaBing(trimmed)) pushEntry(entry);

  let candidates = dedupeCandidates(entries.map((e) => entryToCandidate(e, trimmed))).slice(0, 8);

  // 注册表仅作补充（定向检索关键词），不替代百科检索
  const registry = getRegistryDisambiguation(trimmed);
  if (registry && candidates.length === 0) {
    candidates = registry.candidates.map(({ id, label, title, company, snippet, url, region }) => ({
      id,
      label,
      title,
      company,
      snippet,
      url,
      region,
    }));
  }

  const allowCompare = candidates.length >= 2;
  const reason =
    candidates.length > 1
      ? `已在${sourcesSearched.join("、")}检索到 ${candidates.length} 个「${trimmed}」相关条目，请先确认是哪位，再开始生成内容。`
      : candidates.length === 1
        ? `已在百科检索到 1 条「${trimmed}」相关条目，请确认是否为该人物后再继续。`
        : `百度百科/维基百科暂未收录「${trimmed}」，请确认是否继续按您提供的资料生成。`;

  return {
    name: trimmed,
    candidates,
    reason,
    allowCompare,
    sourcesSearched,
    needsConfirmation: true,
  };
}

export function parseCandidateUrl(candidateId: string): { type: string; url: string } | null {
  const sep = candidateId.indexOf(":");
  if (sep <= 0) return null;
  const type = candidateId.slice(0, sep);
  const encoded = candidateId.slice(sep + 1);
  if (type !== "baike" && type !== "wiki") return null;
  try {
    return { type, url: decodeURIComponent(encoded) };
  } catch {
    return null;
  }
}

/** 用户确认候选后，解析定向检索参数 */
export async function resolveEncyclopediaCandidate(
  name: string,
  candidateId: string,
): Promise<{
  identityHint: string;
  baikeUrl?: string;
  wikiUrl?: string;
  entry?: EnrichedSource;
  registryCandidate?: RegistryPersonCandidate | null;
}> {
  if (candidateId === "self-provided") {
    return { identityHint: name.trim() };
  }

  const registryCandidate = resolveRegistryCandidate(name, candidateId);
  if (registryCandidate) {
    return {
      identityHint: registryCandidate.identityHint,
      registryCandidate,
    };
  }

  const parsed = parseCandidateUrl(candidateId);
  if (!parsed) {
    return { identityHint: name.trim() };
  }

  if (parsed.type === "baike") {
    const entry = await fetchBaikeFromUrl(parsed.url, name);
    const hint = entry
      ? [entry.title.replace(/ - 百度百科$/, ""), entry.snippet.slice(0, 120)].filter(Boolean).join(" · ")
      : parsed.url;
    return { identityHint: hint, baikeUrl: parsed.url, entry: entry || undefined };
  }

  if (parsed.type === "wiki") {
    return {
      identityHint: `维基百科条目：${parsed.url}`,
      wikiUrl: parsed.url,
    };
  }

  return { identityHint: name.trim() };
}

export function buildSelfProvidedCandidate(name: string, rawText?: string): PersonCandidate {
  return {
    id: "self-provided",
    label: `按您提供的资料生成（${name.trim()}）`,
    snippet: rawText?.trim().slice(0, 200) || "百科暂无收录，将依据您粘贴的资料生成",
  };
}
