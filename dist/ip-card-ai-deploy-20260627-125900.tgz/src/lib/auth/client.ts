"use client";

declare global {
  interface Window {
    suatAccessToken?: () => string;
    suatAppendTokenToUrl?: (url: string, token: string) => string;
    suatCaptureTokenFromUrl?: () => string;
  }
}

export function getAccessToken() {
  if (typeof window === "undefined") return "";
  return window.suatAccessToken?.() || localStorage.getItem("suat_access_token") || "";
}

export async function authFetch(input: RequestInfo | URL, init: RequestInit = {}) {
  const token = getAccessToken();
  const headers = new Headers(init.headers || {});
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (!headers.has("Content-Type") && init.body && !(init.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  return fetch(input, { ...init, headers, credentials: "include" });
}

export function ensureSuatScript() {
  if (typeof window === "undefined") return Promise.resolve();
  if (window.suatAccessToken) return Promise.resolve();
  return new Promise<void>((resolve, reject) => {
    const existing = document.querySelector('script[data-suat="1"]');
    if (existing) {
      existing.addEventListener("load", () => resolve(), { once: true });
      existing.addEventListener("error", () => reject(new Error("认证脚本加载失败")), {
        once: true,
      });
      return;
    }
    const script = document.createElement("script");
    script.src = "/suat_auth_redirect.js?v=1";
    script.dataset.suat = "1";
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("认证脚本加载失败"));
    document.head.appendChild(script);
  });
}
