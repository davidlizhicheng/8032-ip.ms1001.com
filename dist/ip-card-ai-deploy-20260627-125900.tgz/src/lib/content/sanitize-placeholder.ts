import { decodeHtmlEntities } from "@/lib/content/decode-html";

/** 禁止出现在用户可见内容中的占位话术 */

export const PLACEHOLDER_PATTERNS = [
  /待补充/,
  /待认证方/,
  /待完善/,
  /公开资料未明确提及/,
  /公开资料不足/,
  /资料待完善/,
  /资料不足/,
  /认领后可上传/,
  /差异化策略在市场中建立独特认知/,
  /聚焦核心客群.*强化品牌记忆点/,
  /集聚众多行业龙头/,
  /历史文化与现代都市风貌交融/,
  /待抓取/,
  /相关.*动态（待/,
];

export function isPlaceholderContent(text?: string | null): boolean {
  if (!text?.trim()) return true;
  return PLACEHOLDER_PATTERNS.some((p) => p.test(text));
}

export function sanitizeText(text?: string | null): string {
  if (!text?.trim()) return "";
  const decoded = decodeHtmlEntities(text);
  if (isPlaceholderContent(decoded)) return "";
  return decoded.trim();
}

export function sanitizeSections<T extends { title: string; content: string; type?: string }>(
  sections: T[],
): T[] {
  return sections.filter(
    (s) => s.content.trim().length >= 30 && !isPlaceholderContent(s.content),
  );
}
