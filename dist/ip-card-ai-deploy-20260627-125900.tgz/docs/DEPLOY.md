# 服务器部署指南

项目路径：`ip-card-ai/`（Next.js 16 + Prisma + SQLite）

## 需要上传什么？

**推荐：用 Git 在服务器拉代码，不要手工挑文件上传。**

若必须打包上传，上传整个 `ip-card-ai` 目录，**排除**以下项：

| 排除 | 原因 |
|------|------|
| `node_modules/` | 在服务器 `npm install` 重新安装 |
| `.next/` | 在服务器 `npm run build` 重新构建 |
| `.env` | 含密钥，在服务器单独创建 |
| `*.db` / `prisma/dev.db` | 数据库在服务器初始化 |
| `.git/` | 可选，不影响运行 |

**必须包含：**

- `src/` — 全部源码
- `prisma/` — schema、migrations、seed
- `public/` — 静态资源
- `package.json` / `package-lock.json`
- `next.config.ts` / `tsconfig.json` / `postcss.config.mjs` 等配置

---

## 服务器要求

- **Node.js 20+**（LTS）
- **Linux x64**（推荐 Ubuntu 22.04；`better-sqlite3` 需在目标机器编译）
- 可访问外网（AI API、百度百科、Bing/Serper 检索）
- 磁盘 ≥ 2GB

---

## 部署步骤（Linux + PM2）

### 1. 上传代码并安装依赖

```bash
cd /var/www
git clone <你的仓库地址> brand
cd brand/ip-card-ai

npm install
```

### 2. 配置环境变量

```bash
cp .env.example .env
nano .env
```

**生产最少配置：**

```env
DATABASE_URL="file:./prod.db"
AI_PROVIDER=deepseek
DEEPSEEK_API_KEY=sk-xxx
DEEPSEEK_BASE_URL=https://api.deepseek.com/v1
DEEPSEEK_MODEL=deepseek-chat

# 联网检索（国内服务器强烈建议配置 Serper，百科抓取更稳）
SERPER_API_KEY=xxx

NODE_ENV=production
```

可选：COS 图床、统一登录（见 `.env.example`）。

### 3. 初始化数据库

```bash
npx prisma migrate deploy
npx tsx prisma/seed.ts
```

### 4. 构建并启动

```bash
npm run build
npm run start
# 默认端口 3000
```

### 5. 用 PM2 守护进程

```bash
npm install -g pm2
pm2 start npm --name ip-card-ai -- start
pm2 save
pm2 startup
```

### 6. Nginx 反向代理（宝塔 ip.ms1001.com）

项目内已提供完整配置：`docs/nginx-ip.ms1001.com.conf`

**操作步骤：**

1. 代码放到服务器，例如 `/www/wwwroot/ip.ms1001.com`（或任意目录）
2. PM2 启动（在该目录下）：

```bash
cd /www/wwwroot/ip.ms1001.com
npm install
cp .env.example .env && nano .env
npx prisma migrate deploy
npm run build
pm2 start npm --name ip-card-ai -- start
pm2 save
```

3. 备份原 Nginx 配置后，用 `docs/nginx-ip.ms1001.com.conf` 替换：
   `/www/server/panel/vhost/nginx/ip.ms1001.com.conf`

4. WebSocket 支持：在主配置 `/www/server/nginx/conf/nginx.conf` 的 `http { }` 内加入（若还没有）：

```nginx
map $http_upgrade $connection_upgrade {
    default upgrade;
    ''      close;
}
```

（见 `docs/nginx-http-upgrade-map.conf`）

5. 测试并重载：

```bash
nginx -t && nginx -s reload
```

**相对原配置的主要改动：**

| 原配置 | 新配置 |
|--------|--------|
| `root` + PHP | 注释 PHP，改为反代 `127.0.0.1:3000` |
| `include enable-php-82.conf` | 已注释 |
| 静态 js/css 缓存 location | 已删除（由 Next.js 处理 `_next/static`） |
| `error_page 404 /404.html` | 已注释（避免盖过 Next 路由） |
| — | 新增 `client_max_body_size 20m`、AI 超时 300s |

HTTPS / HTTP3 / SSL 证书段保持不变。

---

## 更新代码后如何发布

```bash
cd /www/wwwroot/ip.ms1001.com
git pull   # 或重新上传整个 ip-card-ai 目录
bash scripts/deploy-server.sh
```

手动步骤等价于：

```bash
npm install
npm run fix-db
npx prisma migrate deploy
npm run build
pm2 delete ip-card-ai 2>/dev/null || true
pm2 start npm --name ip-card-ai -- start
pm2 save
```

**若 migrate 报 P3009 或 visibility 列仍缺失：**

```bash
npm run fix-db
npx prisma migrate resolve --applied 20260627180000_add_visibility_featured
npm run build
pm2 restart ip-card-ai
```

> 注意：必须先 `npm install`，再用 `npm run fix-db`。**不要**单独 `npx tsx`（会找不到项目依赖）。

---

## 部署后自检

```bash
# 百科检索是否正常（国内服务器应能抓到 5000+ 字正文）
npx tsx scripts/test-research.ts 马斯克 person

# AI 生成是否正常
npx tsx scripts/test-generate.ts 马斯克 person
```

浏览器访问：

- `https://你的域名/admin/batch` — 批量生成
- `https://你的域名/person/xxx` — 人物页

---

## 常见问题

**Q：curl 127.0.0.1:3000 失败 / 502？**  
A：同机 `ai-ms1001` 可能已占用 3000。本项目默认用 **3002**：

```bash
# 查看谁占用了 3000
ss -tlnp | grep 3000

# 项目目录内重启（ecosystem.config.cjs 里 PORT=3002）
cd /www/wwwroot/ip.ms1001.com
pm2 delete ip-card-ai
pm2 start ecosystem.config.cjs
pm2 save
sleep 3
curl -I http://127.0.0.1:3002
```

Nginx 反代也要改成 `proxy_pass http://127.0.0.1:3002;` 后 `nginx -s reload`。

**Q：在 ~ 目录执行 npm 报 package.json not found？**  
A：必须先 `cd /www/wwwroot/ip.ms1001.com`，所有 npm/pm2 命令都在项目目录内执行。

**Q：502 / `next: command not found` / 缺少 `.next/prerender-manifest.json`？**  
A：`npm install` 或 `npm run build` 未成功。在项目目录执行：

```bash
cd /www/wwwroot/ip.ms1001.com
npm install
ls node_modules/next/dist/bin/next    # 必须存在
npm run fix-db
npm run db:deploy
npm run build
ls .next/prerender-manifest.json      # 必须存在
pm2 delete ip-card-ai
pm2 start ecosystem.config.cjs
pm2 save
```

**Q：`prisma: command not found`？**  
A：不要直接敲 `prisma`，用 `npx prisma` 或 `npm run db:deploy`。

**Q：502 Bad Gateway？**  
A：通常是 `npm run build` 失败或 PM2 进程挂了。执行 `pm2 logs ip-card-ai` 查看日志。构建失败时 Nginx 反代到 3000 端口会 502。

**Q：构建报错 `entities.visibility does not exist`？**  
A：数据库缺迁移。拉最新代码后执行：

```bash
cd /www/wwwroot/ip.ms1001.com
git pull   # 或上传含 scripts/fix-database.ts 的最新代码
npm install
npm run fix-db
npx prisma migrate deploy
npm run build
pm2 delete ip-card-ai   # 若有多条重复进程，先删干净
pm2 start npm --name ip-card-ai -- start
pm2 save
```

**Q：PM2 里有两个 ip-card-ai，一个 errored？**  
A：`pm2 delete ip-card-ai` 后只保留一条：`pm2 start npm --name ip-card-ai -- start`

**Q：浏览器控制台 content-script.js / KaTeX 警告？**  
A：来自浏览器插件（如 AI 写作助手），与本站无关，可忽略。

**Q：百科只抓到 100 字摘要，没有全文？**  
A：服务器需能访问 `baike.baidu.com`。海外机器常被限速，建议用国内 VPS，或配置 `SERPER_API_KEY` 提高检索质量。

**Q：SQLite 数据如何备份？**  
A：定期复制 `prod.db` 文件即可；高并发场景可后续换 PostgreSQL。

**Q：端口被占用？**  
A：`PORT=3001 npm run start` 或在 PM2 里加 `env: { PORT: 3001 }`。
